# Gallerfix keeps its database classes as they are (Room reads them by name).
-keep class com.gallerfix.app.data.db.** { *; }

# Optional annotation libraries that some dependencies mention but never need at runtime.
-dontwarn org.checkerframework.**
-dontwarn javax.annotation.**
-dontwarn com.google.errorprone.annotations.**
-dontwarn org.jspecify.annotations.**
-dontwarn kotlin.Unit
