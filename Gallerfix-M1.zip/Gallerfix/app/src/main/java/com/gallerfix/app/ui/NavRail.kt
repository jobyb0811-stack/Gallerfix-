package com.gallerfix.app.ui

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlin.math.abs

/** All rail tuning lives here. */
object RailSpec {
    val CollapsedWidth: Dp = 56.dp
    val ExpandedWidth: Dp = 176.dp
    val ItemHeight: Dp = 56.dp
    val TopPad: Dp = 12.dp
    val BottomPad: Dp = 12.dp
    val EdgeTolerance: Dp = 28.dp
    const val HOLD_MS: Long = 400L
}

private fun itemTop(index: Int, railHeight: Dp): Dp =
    if (index < Dest.entries.size - 1) {
        RailSpec.TopPad + RailSpec.ItemHeight * index
    } else {
        railHeight - RailSpec.BottomPad - RailSpec.ItemHeight
    }

private fun magnify(centerPx: Float, fingerY: Float, itemPx: Float): Float {
    if (fingerY < 0f) return 1f
    val d = abs(centerPx - fingerY) / (itemPx * 1.6f)
    return 1f + 0.3f * (1f - d).coerceIn(0f, 1f)
}

@Composable
fun NavRail(
    current: Dest,
    onSelect: (Dest) -> Unit,
    rightSide: Boolean,
    modifier: Modifier = Modifier,
) {
    val haptics = LocalHapticFeedback.current
    val density = LocalDensity.current
    val onSelectState by rememberUpdatedState(onSelect)

    var expanded by remember { mutableStateOf(false) }
    var hovered by remember { mutableStateOf(-1) }
    var fingerY by remember { mutableFloatStateOf(-1f) }

    val width by animateDpAsState(
        targetValue = if (expanded) RailSpec.ExpandedWidth else RailSpec.CollapsedWidth,
        animationSpec = spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessMediumLow),
        label = "railWidth",
    )
    val labelAlpha by animateFloatAsState(
        targetValue = if (expanded) 1f else 0f,
        animationSpec = tween(160),
        label = "labelAlpha",
    )
    val shape = if (rightSide) {
        RoundedCornerShape(topStart = 28.dp, bottomStart = 28.dp)
    } else {
        RoundedCornerShape(topEnd = 28.dp, bottomEnd = 28.dp)
    }

    Surface(
        modifier = modifier.fillMaxHeight().width(width),
        shape = shape,
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        shadowElevation = if (expanded) 12.dp else 0.dp,
    ) {
        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    val itemPx = RailSpec.ItemHeight.toPx()
                    val topPad = RailSpec.TopPad.toPx()
                    val bottomPad = RailSpec.BottomPad.toPx()
                    val tolerance = RailSpec.EdgeTolerance.toPx()
                    val count = Dest.entries.size

                    fun topOf(i: Int): Float =
                        if (i < count - 1) topPad + itemPx * i else size.height - bottomPad - itemPx

                    fun hit(p: Offset): Int {
                        if (p.x < -tolerance || p.x > size.width + tolerance) return -1
                        for (i in 0 until count) {
                            val t = topOf(i)
                            if (p.y >= t && p.y < t + itemPx) return i
                        }
                        return -1
                    }

                    awaitEachGesture {
                        val down = awaitFirstDown(requireUnconsumed = false)

                        // Phase 1: wait up to HOLD_MS. 0 = still holding, 1 = moved away, 2 = released (tap)
                        val outcome: Int? = withTimeoutOrNull(RailSpec.HOLD_MS) {
                            var r = 0
                            while (r == 0) {
                                val event = awaitPointerEvent()
                                val c = event.changes.firstOrNull { it.id == down.id }
                                r = when {
                                    c == null -> 1
                                    !c.pressed -> 2
                                    (c.position - down.position).getDistance() > viewConfiguration.touchSlop -> 1
                                    else -> 0
                                }
                            }
                            r
                        }

                        if (outcome == 2) {
                            // Quick tap: navigate
                            val idx = hit(down.position)
                            if (idx >= 0) onSelectState(Dest.entries[idx])
                        } else if (outcome == null) {
                            // Held for HOLD_MS: expand, then track the finger
                            expanded = true
                            haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                            hovered = hit(down.position)
                            fingerY = down.position.y
                            try {
                                while (true) {
                                    val event = awaitPointerEvent()
                                    val c = event.changes.firstOrNull { it.id == down.id } ?: break
                                    c.consume()
                                    if (!c.pressed) {
                                        val idx = hit(c.position)
                                        if (idx >= 0) onSelectState(Dest.entries[idx])
                                        break
                                    }
                                    fingerY = c.position.y
                                    val h = hit(c.position)
                                    if (h != hovered) {
                                        hovered = h
                                        if (h >= 0) {
                                            haptics.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                        }
                                    }
                                }
                            } finally {
                                expanded = false
                                hovered = -1
                                fingerY = -1f
                            }
                        }
                    }
                },
        ) {
            val railHeight = maxHeight

            // Sliding selection pill
            val pillTop by animateDpAsState(
                targetValue = itemTop(current.ordinal, railHeight),
                animationSpec = spring(dampingRatio = 0.62f, stiffness = Spring.StiffnessMedium),
                label = "pill",
            )
            Box(
                Modifier
                    .offset(y = pillTop)
                    .fillMaxWidth()
                    .height(RailSpec.ItemHeight)
                    .padding(horizontal = 6.dp, vertical = 4.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(MaterialTheme.colorScheme.secondaryContainer)
            )

            Dest.entries.forEachIndexed { index, dest ->
                val top = itemTop(index, railHeight)
                val centerPx = with(density) { (top + RailSpec.ItemHeight / 2).toPx() }
                RailItem(
                    dest = dest,
                    top = top,
                    centerPx = centerPx,
                    selected = dest == current,
                    hovered = hovered == index,
                    rightSide = rightSide,
                    labelAlpha = labelAlpha,
                    fingerY = { fingerY },
                )
            }
        }
    }
}

@Composable
private fun RailItem(
    dest: Dest,
    top: Dp,
    centerPx: Float,
    selected: Boolean,
    hovered: Boolean,
    rightSide: Boolean,
    labelAlpha: Float,
    fingerY: () -> Float,
) {
    val itemPx = with(LocalDensity.current) { RailSpec.ItemHeight.toPx() }
    val contentColor = if (selected) {
        MaterialTheme.colorScheme.onSecondaryContainer
    } else {
        MaterialTheme.colorScheme.onSurfaceVariant
    }

    Box(
        Modifier
            .offset(y = top)
            .fillMaxWidth()
            .height(RailSpec.ItemHeight)
            .graphicsLayer {
                val s = magnify(centerPx, fingerY(), itemPx)
                scaleX = s
                scaleY = s
                transformOrigin = TransformOrigin(if (rightSide) 1f else 0f, 0.5f)
            }
    ) {
        if (hovered && !selected) {
            Box(
                Modifier
                    .fillMaxSize()
                    .padding(horizontal = 6.dp, vertical = 4.dp)
                    .clip(RoundedCornerShape(18.dp))
                    .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.10f))
            )
        }
        Box(
            Modifier
                .width(RailSpec.CollapsedWidth)
                .fillMaxHeight()
                .align(if (rightSide) Alignment.CenterEnd else Alignment.CenterStart),
            contentAlignment = Alignment.Center,
        ) {
            NavIcon(dest, contentColor)
        }
        Text(
            text = dest.label,
            color = contentColor,
            style = MaterialTheme.typography.labelLarge,
            maxLines = 1,
            softWrap = false,
            modifier = Modifier
                .align(if (rightSide) Alignment.CenterEnd else Alignment.CenterStart)
                .padding(
                    start = if (rightSide) 0.dp else RailSpec.CollapsedWidth,
                    end = if (rightSide) RailSpec.CollapsedWidth else 0.dp,
                )
                .alpha(labelAlpha),
        )
    }
}
