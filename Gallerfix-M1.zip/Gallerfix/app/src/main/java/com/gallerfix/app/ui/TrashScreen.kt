package com.gallerfix.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.ImageLoader
import com.gallerfix.app.data.MediaItem

@Composable
fun TrashScreen(
    state: GalleryState,
    imageLoader: ImageLoader,
    minSize: Dp,
    selected: List<Long>,
    onToggle: (MediaItem) -> Unit,
    onRestore: (List<MediaItem>) -> Unit,
    onDeleteForever: (List<MediaItem>) -> Unit,
    onBack: () -> Unit,
) {
    Column(Modifier.fillMaxSize()) {
        HeaderBar("Trash") {
            TextButton(onClick = onBack) { Text("Back") }
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (state) {
                GalleryState.Loading ->
                    CircularProgressIndicator(Modifier.align(Alignment.Center))
                GalleryState.NoPermission ->
                    MessageState(
                        title = "Allow access first",
                        body = "Go back and grant access to your photos to see the trash.",
                    ) {}
                GalleryState.Empty ->
                    MessageState(
                        title = "Trash is empty",
                        body = "Items you trash stay here for about 30 days before Android removes them for good.",
                    ) {}
                is GalleryState.Content -> Column(Modifier.fillMaxSize()) {
                    Text(
                        text = "Tap items to select. With nothing selected, the buttons below apply to everything.",
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                    )
                    MediaGrid(
                        items = state.items,
                        imageLoader = imageLoader,
                        minSize = minSize,
                        selectedIds = selected.toSet(),
                        onItemClick = onToggle,
                        onItemLongClick = onToggle,
                    )
                }
            }
        }
        if (state is GalleryState.Content) {
            val targets = if (selected.isEmpty()) {
                state.items
            } else {
                state.items.filter { it.id in selected }
            }
            val label = if (selected.isEmpty()) "all ${targets.size}" else "${targets.size}"
            Row(
                Modifier.fillMaxWidth().padding(12.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                OutlinedButton(onClick = { onRestore(targets) }, enabled = targets.isNotEmpty()) {
                    Text("Restore $label")
                }
                Button(onClick = { onDeleteForever(targets) }, enabled = targets.isNotEmpty()) {
                    Text("Delete $label")
                }
            }
        }
    }
}
