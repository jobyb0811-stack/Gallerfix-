package com.gallerfix.app.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.produceState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.gallerfix.app.data.MediaDetails
import com.gallerfix.app.data.MediaItem
import com.gallerfix.app.data.SmartAlbumBuilder
import java.text.DateFormat
import java.util.Date

@Composable
fun NameDialog(
    title: String,
    initial: String,
    confirmLabel: String,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it.take(40) },
                singleLine = true,
                label = { Text("Name") },
            )
        },
        confirmButton = {
            TextButton(
                onClick = { onConfirm(text.trim()) },
                enabled = text.isNotBlank(),
            ) { Text(confirmLabel) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
fun AddToAlbumDialog(
    albums: List<AlbumUi>,
    onPick: (AlbumUi) -> Unit,
    onCreate: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var creating by remember { mutableStateOf(false) }
    if (creating) {
        NameDialog(
            title = "New album",
            initial = "",
            confirmLabel = "Create",
            onConfirm = onCreate,
            onDismiss = { creating = false },
        )
    } else {
        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text("Add to album") },
            text = {
                if (albums.isEmpty()) {
                    Text("You have no albums yet. Create one to get started.")
                } else {
                    LazyColumn {
                        items(albums, key = { it.id }) { album ->
                            TextButton(
                                onClick = { onPick(album) },
                                modifier = Modifier.fillMaxWidth(),
                            ) { Text("${album.name} (${album.items.size})") }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { creating = true }) { Text("New album") } },
            dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
        )
    }
}

@Composable
fun DetailsDialog(
    item: MediaItem,
    load: suspend (MediaItem) -> MediaDetails,
    onDismiss: () -> Unit,
) {
    val details by produceState<MediaDetails?>(initialValue = null, item.id) {
        value = load(item)
    }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Details") },
        text = {
            val d = details
            if (d == null) {
                Text("Loading…")
            } else {
                Column {
                    DetailRow("Name", d.name)
                    DetailRow("Type", if (d.mime.isNotEmpty()) d.mime else if (d.isVideo) "Video" else "Photo")
                    DetailRow("Size", SmartAlbumBuilder.formatSize(d.sizeBytes))
                    if (d.width > 0 && d.height > 0) DetailRow("Dimensions", "${d.width} × ${d.height}")
                    if (d.isVideo && d.durationMs > 0) {
                        val total = d.durationMs / 1000
                        DetailRow("Length", "%d:%02d".format(total / 60, total % 60))
                    }
                    if (d.takenMs > 0) {
                        DetailRow(
                            "Taken",
                            DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(d.takenMs)),
                        )
                    }
                    if (d.path.isNotEmpty()) DetailRow("Folder", d.path)
                    DetailRow("Storage", if (d.onSd) "Memory card (SD)" else "Phone")
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close") } },
    )
}

@Composable
private fun DetailRow(label: String, value: String) {
    Column(Modifier.padding(vertical = 4.dp)) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
        Text(value, style = MaterialTheme.typography.bodyMedium)
    }
}
