package com.gallerfix.app.ui

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier

@Composable
fun NameDialog(
    title: String,
    initial: String,
    confirmLabel: String,
    onConfirm: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                value = text,
                onValueChange = { text = it.take(40) },
                singleLine = true,
                label = { Text("Name") },
            )
        },
        confirmButton = {
            TextButton(
                onClick = { onConfirm(text.trim()) },
                enabled = text.isNotBlank(),
            ) { Text(confirmLabel) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
fun AddToAlbumDialog(
    albums: List<AlbumUi>,
    onPick: (AlbumUi) -> Unit,
    onCreate: (String) -> Unit,
    onDismiss: () -> Unit,
) {
    var creating by remember { mutableStateOf(false) }
    if (creating) {
        NameDialog(
            title = "New album",
            initial = "",
            confirmLabel = "Create",
            onConfirm = onCreate,
            onDismiss = { creating = false },
        )
    } else {
        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text("Add to album") },
            text = {
                if (albums.isEmpty()) {
                    Text("You have no albums yet. Create one to get started.")
                } else {
                    LazyColumn {
                        items(albums, key = { it.id }) { album ->
                            TextButton(
                                onClick = { onPick(album) },
                                modifier = Modifier.fillMaxWidth(),
                            ) { Text("${album.name} (${album.items.size})") }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { creating = true }) { Text("New album") } },
            dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
        )
    }
}
