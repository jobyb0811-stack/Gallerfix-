package com.gallerfix.app.data

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ImageDecoder
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.net.Uri
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** A rectangle in 0..1 canvas coordinates. */
data class NormRect(val l: Float, val t: Float, val r: Float, val b: Float)

class CollageLayout(val rects: List<NormRect>)

/** A cell in pixels. */
data class CellRect(val x: Float, val y: Float, val w: Float, val h: Float)

/**
 * Shared by the on-screen preview and the saved image so they always match.
 * [gapFrac] is the spacing as a fraction of the canvas width; it is used for the outer margin and
 * the gap between photos.
 */
fun cellRect(r: NormRect, canvasW: Float, canvasH: Float, gapFrac: Float): CellRect {
    val gap = canvasW * gapFrac
    val areaW = canvasW - gap
    val areaH = canvasH - gap
    return CellRect(
        x = areaW * r.l + gap,
        y = areaH * r.t + gap,
        w = max(1f, areaW * (r.r - r.l) - gap),
        h = max(1f, areaH * (r.b - r.t) - gap),
    )
}

private fun byRows(vararg counts: Int): CollageLayout {
    val rects = ArrayList<NormRect>()
    val rows = counts.size
    counts.forEachIndexed { ri, n ->
        for (ci in 0 until n) {
            rects.add(
                NormRect(
                    ci / n.toFloat(), ri / rows.toFloat(),
                    (ci + 1) / n.toFloat(), (ri + 1) / rows.toFloat(),
                )
            )
        }
    }
    return CollageLayout(rects)
}

private fun byCols(vararg counts: Int): CollageLayout {
    val rects = ArrayList<NormRect>()
    val cols = counts.size
    counts.forEachIndexed { ci, n ->
        for (ri in 0 until n) {
            rects.add(
                NormRect(
                    ci / cols.toFloat(), ri / n.toFloat(),
                    (ci + 1) / cols.toFloat(), (ri + 1) / n.toFloat(),
                )
            )
        }
    }
    return CollageLayout(rects)
}

/** Layout choices for [n] photos (2..6). */
fun layoutsFor(n: Int): List<CollageLayout> = when (n) {
    2 -> listOf(byRows(1, 1), byCols(1, 1))
    3 -> listOf(byRows(1, 2), byRows(2, 1), byCols(1, 2), byCols(2, 1), byRows(1, 1, 1))
    4 -> listOf(byRows(2, 2), byRows(1, 3), byRows(3, 1), byCols(1, 3), byCols(3, 1))
    5 -> listOf(byRows(2, 3), byRows(3, 2), byRows(1, 2, 2), byCols(2, 3))
    6 -> listOf(byRows(3, 3), byRows(2, 2, 2), byRows(2, 4), byRows(1, 2, 3))
    else -> listOf(byRows(*IntArray(max(1, n)) { 1 }))
}

object CollageRenderer {

    private const val OUT_WIDTH = 1440

    /**
     * Renders the collage and saves it to Pictures/Gallerfix. Any failure (low storage, unreadable
     * photo, out of memory) leaves no half-written file behind and the original photos untouched.
     */
    suspend fun render(
        context: Context,
        items: List<MediaItem>,
        layout: CollageLayout,
        gapFrac: Float,
        radiusFrac: Float,
        background: Int,
        aspect: Float,
    ): Result<Uri> = withContext(Dispatchers.IO) {
        try {
            val outW = OUT_WIDTH
            val outH = (outW / aspect).roundToInt()
            val bitmap = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
            try {
                draw(context, bitmap, items, layout, gapFrac, radiusFrac, background)
                Result.success(save(context, bitmap))
            } finally {
                bitmap.recycle()
            }
        } catch (e: Throwable) {
            Result.failure(e)
        }
    }

    private fun draw(
        context: Context,
        bitmap: Bitmap,
        items: List<MediaItem>,
        layout: CollageLayout,
        gapFrac: Float,
        radiusFrac: Float,
        background: Int,
    ) {
        val canvas = Canvas(bitmap)
        canvas.drawColor(background)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
        val outW = bitmap.width.toFloat()
        val outH = bitmap.height.toFloat()
        val radius = outW * radiusFrac

        items.forEachIndexed { i, item ->
            val cell = cellRect(layout.rects[i], outW, outH, gapFrac)
            val photo = decode(context, item.uri, cell.w.toInt(), cell.h.toInt())
                ?: throw IOException("Could not read ${item.displayName}")
            try {
                // Centre-crop the photo to fill the cell
                val scale = max(cell.w / photo.width, cell.h / photo.height)
                val srcW = cell.w / scale
                val srcH = cell.h / scale
                val srcL = (photo.width - srcW) / 2f
                val srcT = (photo.height - srcH) / 2f
                val src = Rect(
                    srcL.toInt(), srcT.toInt(),
                    (srcL + srcW).toInt(), (srcT + srcH).toInt(),
                )
                val dst = RectF(cell.x, cell.y, cell.x + cell.w, cell.y + cell.h)
                canvas.save()
                val clip = Path()
                clip.addRoundRect(dst, radius, radius, Path.Direction.CW)
                canvas.clipPath(clip)
                canvas.drawBitmap(photo, src, dst, paint)
                canvas.restore()
            } finally {
                photo.recycle()
            }
        }
    }

    private fun decode(context: Context, uri: Uri, cellW: Int, cellH: Int): Bitmap? = try {
        val source = ImageDecoder.createSource(context.contentResolver, uri)
        ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            val sample = max(
                1,
                min(info.size.width / max(cellW, 1), info.size.height / max(cellH, 1)),
            )
            decoder.setTargetSampleSize(sample)
        }
    } catch (e: Exception) {
        null
    }

    private fun save(context: Context, bitmap: Bitmap): Uri {
        val resolver = context.contentResolver
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "Collage_$stamp.jpg")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/Gallerfix")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val collection = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        val uri = resolver.insert(collection, values) ?: throw IOException("Could not create the file")
        try {
            val out = resolver.openOutputStream(uri) ?: throw IOException("Could not open the file")
            out.use {
                if (!bitmap.compress(Bitmap.CompressFormat.JPEG, 92, it)) {
                    throw IOException("Could not write the image")
                }
            }
            values.clear()
            values.put(MediaStore.MediaColumns.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            return uri
        } catch (e: Exception) {
            // Abort cleanly: remove the half-written file.
            resolver.delete(uri, null, null)
            throw e
        }
    }
}
