package com.gallerfix.app

/** Hidden entrance to the private library: tap the Collage item this many times, this fast. */
object VaultSpec {
    const val TAP_COUNT = 4
    const val TAP_WINDOW_MS = 1_500L
}

/** App-lock tuning, including the secret tap code. */
object LockSpec {
    /** How long you must stop tapping before the tap code is checked. */
    const val TAP_PAUSE_MS = 1_200L
    const val MIN_TAPS = 2
    const val MAX_TAPS = 50
    const val DEFAULT_TAPS = 17
    /** After this many wrong tap codes in a row, taps are ignored for LOCKOUT_MS. */
    const val MAX_FAILURES = 5
    const val LOCKOUT_MS = 30_000L
    const val DEFAULT_GRACE_SECONDS = 30
}
