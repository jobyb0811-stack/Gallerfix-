package com.gallerfix.app.data

import android.content.Context
import android.content.IntentSender
import android.net.Uri
import android.provider.MediaStore

/** Builds the system confirmation dialogs (Android 11+). Nothing changes unless the user approves. */
object MediaRequests {
    fun trash(context: Context, items: List<MediaItem>, trashed: Boolean): IntentSender =
        MediaStore.createTrashRequest(context.contentResolver, items.map { it.uri }, trashed).intentSender

    fun deleteForever(context: Context, items: List<MediaItem>): IntentSender =
        deleteUris(context, items.map { it.uri })

    fun deleteUris(context: Context, uris: List<Uri>): IntentSender =
        MediaStore.createDeleteRequest(context.contentResolver, uris).intentSender
}
