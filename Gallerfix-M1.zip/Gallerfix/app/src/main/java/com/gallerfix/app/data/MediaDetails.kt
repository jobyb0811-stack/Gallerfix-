package com.gallerfix.app.data

data class MediaDetails(
    val name: String,
    val mime: String,
    val sizeBytes: Long,
    val width: Int,
    val height: Int,
    val takenMs: Long,
    val path: String,
    val onSd: Boolean,
    val isVideo: Boolean,
    val durationMs: Long,
)
