package com.gallerfix.app.ui.editor

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.RectF
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gallerfix.app.data.MediaItem
import com.gallerfix.app.ui.BackIcon
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

private const val MODE_CROP = 0
private const val MODE_ADJUST = 1
private const val MODE_FILTER = 2
private const val MODE_TEXT = 3
private const val MODE_DRAW = 4
private const val MODE_STICKER = 5
private const val MODE_CUTOUT = 6
private const val MODE_STORY = 7

private val MODE_NAMES = listOf("Crop", "Adjust", "Filters", "Text", "Draw", "Stickers", "Cutout", "Story")

private val PALETTE = listOf(
    0xFFFFFFFF, 0xFF000000, 0xFFE53935, 0xFFFB8C00, 0xFFFDD835,
    0xFF43A047, 0xFF00ACC1, 0xFF1E88E5, 0xFF8E24AA, 0xFFEC407A,
).map { it.toInt() }

private val EMOJIS = listOf(
    "😀", "😂", "😍", "🥰", "😎", "🤩", "😭", "😡", "👍", "🙏", "👏", "🔥", "✨", "💖", "💯",
    "🎉", "🎂", "🌟", "⭐", "🌈", "☀️", "🌙", "🌸", "🌹", "🍕", "🍔", "🍦", "☕", "⚽", "🎵",
    "📸", "✈️", "🏖️", "🐶", "🐱", "🦋", "🍀", "💎", "👑", "💥", "❤️",
)

private const val MIN_CROP = 0.08f

/**
 * Photo editor and story maker. Works on a copy: your original is never changed.
 * Everything happens on the phone.
 */
@Composable
fun EditorScreen(item: MediaItem, startStory: Boolean, onClose: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    val doc = remember { EditDoc() }

    var mode by remember { mutableIntStateOf(if (startStory) MODE_STORY else MODE_ADJUST) }
    var selectedId by remember { mutableStateOf<Int?>(null) }
    var saving by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var showDiscard by remember { mutableStateOf(false) }
    var textDialog by remember { mutableStateOf<EditLayer?>(null) }
    var shareMenu by remember { mutableStateOf(false) }
    var canvasPx by remember { mutableStateOf(IntSize.Zero) }
    var cropAspect by remember { mutableStateOf<Float?>(null) }

    var penColor by remember { mutableIntStateOf(PALETTE[2]) }
    var penWidth by remember { mutableFloatStateOf(0.012f) }
    var penTool by remember { mutableIntStateOf(0) } // 0 pen, 1 marker, 2 eraser

    var cutTool by remember { mutableIntStateOf(0) } // 0 rectangle, 1 lasso
    var cutRect by remember { mutableStateOf<RectF?>(null) }
    val lasso = remember { mutableStateListOf<Offset>() }

    LaunchedEffect(item.id) {
        doc.story = startStory
        doc.source = withContext(Dispatchers.Default) { EditorRender.decode(context, item.uri) }
        if (doc.source == null) message = "Couldn't open this photo."
    }

    val rotated by produceState<Bitmap?>(null, doc.source, doc.quarter, doc.flip) {
        val src = doc.source
        value = if (src == null) null else withContext(Dispatchers.Default) {
            EditorRender.rotateFlip(src, doc.quarter, doc.flip)
        }
    }
    val params = doc.params()
    val previewBase by produceState<Bitmap?>(null, rotated, params) {
        val r = rotated
        if (r == null) {
            value = null
        } else {
            delay(30)
            value = withContext(Dispatchers.Default) {
                val size = EditorRender.outputSize(r, params, 1080)
                EditorRender.canvasBase(r, params, size.first, size.second)
            }
        }
    }

    val rot = rotated
    val base = previewBase
    val canvasAspect: Float = when {
        mode == MODE_CROP && rot != null -> rot.width.toFloat() / rot.height
        base != null -> base.width.toFloat() / base.height
        else -> 1f
    }
    val selectedLayer = doc.layers.firstOrNull { it.id == selectedId }

    fun norm(o: Offset): Offset = Offset(
        (o.x / max(1, canvasPx.width)).coerceIn(0f, 1f),
        (o.y / max(1, canvasPx.height)).coerceIn(0f, 1f),
    )

    fun exportThen(action: (Uri) -> Unit) {
        val r = rotated ?: return
        if (saving) return
        saving = true
        message = null
        val p = doc.params()
        val layerSnaps = doc.layers.map { it.snap() }
        val strokeSnaps = doc.strokes.map { it.snap() }
        scope.launch {
            val uri = withContext(Dispatchers.Default) {
                try {
                    val size = EditorRender.outputSize(r, p, if (p.story) 1920 else 2400)
                    val out = EditorRender.canvasBase(r, p, size.first, size.second)
                    val canvas = android.graphics.Canvas(out)
                    EditorRender.drawOverlays(context, canvas, out.width, out.height, layerSnaps, strokeSnaps)
                    EditorRender.save(context, out, if (p.story) "Story" else "Edit")
                } catch (e: Throwable) {
                    null
                }
            }
            saving = false
            if (uri != null) action(uri) else message = "Couldn't save. Your original is untouched."
        }
    }

    fun cutout(remove: Boolean) {
        val sel = cutRect ?: return
        val r = rotated ?: return
        val p = doc.params()
        val points = if (cutTool == 1 && lasso.size >= 3) lasso.toList() else null
        scope.launch {
            val result = withContext(Dispatchers.Default) {
                val full = EditorRender.cropColor(r, p, 2048)
                val piece = EditorRender.cutPiece(full, sel, points)
                val filled = if (remove) EditorRender.fillRegion(full, sel, points) else null
                Pair(piece, filled)
            }
            val layer = EditLayer(doc.nextId++, 2)
            layer.bitmap = result.first
            layer.sizeFrac = (sel.right - sel.left).coerceIn(0.05f, 1f)
            layer.cx = (sel.left + sel.right) / 2f + (if (remove) 0f else 0.04f)
            layer.cy = (sel.top + sel.bottom) / 2f + (if (remove) 0f else 0.04f)
            doc.layers.add(layer)
            selectedId = layer.id
            val filled = result.second
            if (filled != null) {
                // The piece is now a separate layer, so the lifted-out picture becomes the new starting point.
                doc.source = filled
                doc.baked = true
                doc.quarter = 0
                doc.flip = false
                doc.resetCrop()
                doc.resetLook()
            }
            cutRect = null
            lasso.clear()
            mode = MODE_STICKER
            message = if (remove) "Cut. Drag the piece where you want it." else "Copied. Drag the copy where you want it."
        }
    }

    BackHandler { if (doc.isDirty) showDiscard = true else onClose() }

    Column(
        Modifier
            .fillMaxSize()
            .background(Color(0xFF0B0B0D))
            .systemBarsPadding()
    ) {
        // ---------------- top bar
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = { if (doc.isDirty) showDiscard = true else onClose() }) { BackIcon(Color.White) }
            Text(
                if (doc.story) "Story" else "Edit photo",
                color = Color.White,
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.weight(1f),
            )
            if (saving) {
                CircularProgressIndicator(Modifier.size(22.dp), color = Color.White, strokeWidth = 2.dp)
            } else {
                TextButton(onClick = {
                    exportThen { message = "Saved to Pictures/Gallerfix" }
                }) { Text("Save", color = Color.White) }
                Box {
                    TextButton(onClick = { shareMenu = true }) { Text("Share ▾", color = Color.White) }
                    DropdownMenu(expanded = shareMenu, onDismissRequest = { shareMenu = false }) {
                        DropdownMenuItem(
                            text = { Text("Share…") },
                            onClick = {
                                shareMenu = false
                                exportThen { shareUri(context, it, false) }
                            },
                        )
                        DropdownMenuItem(
                            text = { Text("Instagram") },
                            onClick = {
                                shareMenu = false
                                exportThen { shareUri(context, it, true) }
                            },
                        )
                    }
                }
            }
        }

        // ---------------- the picture
        BoxWithConstraints(
            Modifier.weight(1f).fillMaxWidth().padding(8.dp),
            contentAlignment = Alignment.Center,
        ) {
            val maxW = constraints.maxWidth.toFloat()
            val maxH = constraints.maxHeight.toFloat()
            val wide = canvasAspect > maxW / maxH
            val w = if (wide) maxW else maxH * canvasAspect
            val h = if (wide) maxW / canvasAspect else maxH

            Box(
                Modifier
                    .size(with(density) { w.toDp() }, with(density) { h.toDp() })
                    .onSizeChanged { canvasPx = it }
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0xFF1A1A1D))
            ) {
                when {
                    mode == MODE_CROP && rot != null -> {
                        val image = remember(rot) { rot.asImageBitmap() }
                        Image(image, null, Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
                        CropOverlay(doc, rot.width, rot.height, cropAspect, canvasPx)
                    }
                    base != null -> {
                        val image = remember(base) { base.asImageBitmap() }
                        Image(image, null, Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
                        doc.layers.forEach { layer ->
                            key(layer.id) {
                                LayerView(layer, canvasPx.width.toFloat(), canvasPx.height.toFloat(), layer.id == selectedId)
                            }
                        }
                        StrokesView(doc.strokes)

                        when (mode) {
                            MODE_DRAW -> Box(
                                Modifier
                                    .fillMaxSize()
                                    .pointerInput(penColor, penWidth, penTool, canvasPx) {
                                        var current: StrokeData? = null
                                        detectDragGestures(
                                            onDragStart = { o ->
                                                val stroke = StrokeData(
                                                    color = penColor,
                                                    widthFrac = if (penTool == 1) penWidth * 2.2f else penWidth,
                                                    alpha = if (penTool == 1) 0.45f else 1f,
                                                    eraser = penTool == 2,
                                                )
                                                stroke.points.add(norm(o))
                                                doc.strokes.add(stroke)
                                                current = stroke
                                            },
                                            onDrag = { change, _ ->
                                                change.consume()
                                                current?.points?.add(norm(change.position))
                                            },
                                            onDragEnd = { current = null },
                                            onDragCancel = { current = null },
                                        )
                                    }
                            )
                            MODE_CUTOUT -> {
                                Box(
                                    Modifier
                                        .fillMaxSize()
                                        .pointerInput(cutTool, canvasPx) {
                                            var start = Offset.Zero
                                            detectDragGestures(
                                                onDragStart = { o ->
                                                    start = o
                                                    lasso.clear()
                                                    cutRect = null
                                                    if (cutTool == 1) lasso.add(norm(o))
                                                },
                                                onDrag = { change, _ ->
                                                    change.consume()
                                                    val p = change.position
                                                    if (cutTool == 0) {
                                                        val a = norm(start)
                                                        val b = norm(p)
                                                        cutRect = RectF(min(a.x, b.x), min(a.y, b.y), max(a.x, b.x), max(a.y, b.y))
                                                    } else {
                                                        lasso.add(norm(p))
                                                        var l = 1f
                                                        var t = 1f
                                                        var r = 0f
                                                        var bt = 0f
                                                        for (o in lasso) {
                                                            l = min(l, o.x); t = min(t, o.y)
                                                            r = max(r, o.x); bt = max(bt, o.y)
                                                        }
                                                        cutRect = RectF(l, t, r, bt)
                                                    }
                                                },
                                            )
                                        }
                                )
                                SelectionOutline(cutRect, if (cutTool == 1) lasso.toList() else null)
                            }
                            else -> Box(
                                Modifier
                                    .fillMaxSize()
                                    .pointerInput(canvasPx) {
                                        detectTapGestures(
                                            onTap = { p -> selectedId = hitTest(doc.layers, p, canvasPx)?.id },
                                            onDoubleTap = { p ->
                                                val hit = hitTest(doc.layers, p, canvasPx)
                                                if (hit != null && hit.kind == 0) {
                                                    selectedId = hit.id
                                                    textDialog = hit
                                                }
                                            },
                                        )
                                    }
                                    .pointerInput(canvasPx) {
                                        detectTransformGestures { _, pan, zoom, rotation ->
                                            val l = doc.layers.firstOrNull { it.id == selectedId }
                                            if (l != null) {
                                                l.cx = (l.cx + pan.x / max(1, canvasPx.width)).coerceIn(0f, 1f)
                                                l.cy = (l.cy + pan.y / max(1, canvasPx.height)).coerceIn(0f, 1f)
                                                l.scale = (l.scale * zoom).coerceIn(0.2f, 8f)
                                                l.rot += rotation
                                            }
                                        }
                                    }
                            )
                        }
                    }
                    else -> CircularProgressIndicator(Modifier.align(Alignment.Center), color = Color.White)
                }
            }
        }

        if (message != null) {
            Text(
                message ?: "",
                color = Color(0xFFFFD166),
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 2.dp),
            )
        }

        // ---------------- actions for the selected layer
        if (selectedLayer != null && mode != MODE_CROP && mode != MODE_DRAW && mode != MODE_CUTOUT) {
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                if (selectedLayer.kind == 0) {
                    TextButton(onClick = { textDialog = selectedLayer }) { Text("Edit text", color = Color.White) }
                }
                TextButton(onClick = {
                    val copy = EditLayer(doc.nextId++, selectedLayer.kind)
                    copy.cx = (selectedLayer.cx + 0.05f).coerceIn(0f, 1f)
                    copy.cy = (selectedLayer.cy + 0.05f).coerceIn(0f, 1f)
                    copy.scale = selectedLayer.scale
                    copy.rot = selectedLayer.rot
                    copy.text = selectedLayer.text
                    copy.fontIndex = selectedLayer.fontIndex
                    copy.color = selectedLayer.color
                    copy.bgMode = selectedLayer.bgMode
                    copy.sizeFrac = selectedLayer.sizeFrac
                    copy.bitmap = selectedLayer.bitmap
                    doc.layers.add(copy)
                    selectedId = copy.id
                }) { Text("Duplicate", color = Color.White) }
                TextButton(onClick = {
                    doc.layers.remove(selectedLayer)
                    doc.layers.add(selectedLayer)
                }) { Text("To front", color = Color.White) }
                TextButton(onClick = {
                    doc.layers.remove(selectedLayer)
                    selectedId = null
                }) { Text("Delete", color = Color(0xFFFF8A80)) }
            }
        }

        // ---------------- the tool panel
        Column(
            Modifier
                .fillMaxWidth()
                .heightIn(max = 210.dp)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 12.dp, vertical = 4.dp)
        ) {
            when (mode) {
                MODE_CROP -> CropPanel(
                    doc = doc,
                    rotW = rot?.width ?: 1,
                    rotH = rot?.height ?: 1,
                    aspect = cropAspect,
                    onAspect = { cropAspect = it },
                )
                MODE_ADJUST -> AdjustPanel(doc)
                MODE_FILTER -> FilterPanel(doc)
                MODE_TEXT -> TextPanel(
                    doc = doc,
                    selected = selectedLayer,
                    onAdd = {
                        val layer = EditLayer(doc.nextId++, 0)
                        layer.text = ""
                        layer.fontIndex = 1
                        textDialog = layer
                    },
                )
                MODE_DRAW -> DrawPanel(
                    color = penColor,
                    onColor = { penColor = it },
                    width = penWidth,
                    onWidth = { penWidth = it },
                    tool = penTool,
                    onTool = { penTool = it },
                    onUndo = { if (doc.strokes.isNotEmpty()) doc.strokes.removeAt(doc.strokes.lastIndex) },
                    onClear = { doc.strokes.clear() },
                )
                MODE_STICKER -> StickerPanel(onPick = { emoji ->
                    val layer = EditLayer(doc.nextId++, 1)
                    layer.text = emoji
                    layer.sizeFrac = 0.2f
                    doc.layers.add(layer)
                    selectedId = layer.id
                })
                MODE_CUTOUT -> CutoutPanel(
                    story = doc.story,
                    tool = cutTool,
                    onTool = {
                        cutTool = it
                        cutRect = null
                        lasso.clear()
                    },
                    hasSelection = cutRect != null,
                    onCopy = { cutout(false) },
                    onCut = { cutout(true) },
                )
                else -> StoryPanel(doc)
            }
        }

        // ---------------- the tools
        Row(
            Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            MODE_NAMES.forEachIndexed { index, name ->
                FilterChip(
                    selected = mode == index,
                    onClick = {
                        mode = index
                        if (index == MODE_CROP || index == MODE_DRAW || index == MODE_CUTOUT) selectedId = null
                        message = null
                    },
                    label = { Text(name) },
                )
            }
        }
    }

    // ---------------- dialogs
    val editing = textDialog
    if (editing != null) {
        TextEditDialog(
            initial = editing.text,
            onConfirm = { value ->
                if (value.isNotBlank()) {
                    editing.text = value
                    if (editing !in doc.layers) doc.layers.add(editing)
                    selectedId = editing.id
                }
                textDialog = null
            },
            onDismiss = { textDialog = null },
        )
    }
    if (showDiscard) {
        AlertDialog(
            onDismissRequest = { showDiscard = false },
            title = { Text("Discard your changes?") },
            text = { Text("Anything you haven't saved will be lost. Your original photo is not affected.") },
            confirmButton = { TextButton(onClick = onClose) { Text("Discard") } },
            dismissButton = { TextButton(onClick = { showDiscard = false }) { Text("Keep editing") } },
        )
    }
}

// ============================================================================ helpers

private fun shareUri(context: Context, uri: Uri, instagram: Boolean) {
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "image/jpeg"
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    if (instagram) {
        try {
            context.startActivity(Intent(intent).setPackage("com.instagram.android"))
            return
        } catch (e: Exception) {
            // Instagram isn't installed: fall back to the normal share sheet.
        }
    }
    try {
        context.startActivity(Intent.createChooser(intent, "Share"))
    } catch (e: Exception) {
        // nothing can handle it
    }
}

private fun hitTest(layers: List<EditLayer>, p: Offset, size: IntSize): EditLayer? {
    for (l in layers.asReversed()) {
        val dx = p.x - l.cx * size.width
        val dy = p.y - l.cy * size.height
        val a = -l.rot * PI.toFloat() / 180f
        val lx = (dx * cos(a) - dy * sin(a)) / l.scale
        val ly = (dx * sin(a) + dy * cos(a)) / l.scale
        val hw = max(l.widthPx / 2f, 28f)
        val hh = max(l.heightPx / 2f, 28f)
        if (abs(lx) <= hw && abs(ly) <= hh) return l
    }
    return null
}

@Composable
private fun LayerView(layer: EditLayer, canvasW: Float, canvasH: Float, selected: Boolean) {
    val density = LocalDensity.current
    val sizePx = layer.sizeFrac * canvasW
    val frame = if (selected) {
        Modifier.border(1.5.dp, Color.White, RoundedCornerShape(4.dp))
    } else {
        Modifier
    }
    Box(
        Modifier
            .offset {
                IntOffset(
                    (layer.cx * canvasW - layer.widthPx / 2f).roundToInt(),
                    (layer.cy * canvasH - layer.heightPx / 2f).roundToInt(),
                )
            }
            .onSizeChanged {
                layer.widthPx = it.width
                layer.heightPx = it.height
            }
            .graphicsLayer {
                rotationZ = layer.rot
                scaleX = layer.scale
                scaleY = layer.scale
            }
            .then(frame)
    ) {
        when (layer.kind) {
            2 -> {
                val bmp = layer.bitmap
                if (bmp != null) {
                    val image = remember(bmp) { bmp.asImageBitmap() }
                    Image(
                        image,
                        null,
                        Modifier
                            .width(with(density) { sizePx.toDp() })
                            .aspectRatio(bmp.width.toFloat() / bmp.height),
                        contentScale = ContentScale.FillBounds,
                    )
                }
            }
            else -> {
                val text = EditorRender.textColor(layer.kind, layer.color, layer.bgMode)
                val box = if (layer.kind == 0) EditorRender.boxColor(layer.bgMode, layer.color) else null
                val padX = if (layer.kind == 0) sizePx * 0.35f else 0f
                val padY = if (layer.kind == 0) sizePx * 0.15f else 0f
                val background = if (box != null) {
                    Modifier.background(Color(box), RoundedCornerShape(with(density) { (sizePx * 0.3f).toDp() }))
                } else {
                    Modifier
                }
                Text(
                    text = layer.text,
                    color = Color(text),
                    fontFamily = if (layer.kind == 0) EditorFonts.family(layer.fontIndex) else null,
                    fontWeight = if (layer.kind == 0) EditorFonts.weight(layer.fontIndex) else null,
                    fontSize = with(density) { sizePx.toSp() },
                    textAlign = TextAlign.Center,
                    softWrap = false,
                    modifier = background.padding(
                        horizontal = with(density) { padX.toDp() },
                        vertical = with(density) { padY.toDp() },
                    ),
                )
            }
        }
    }
}

@Composable
private fun StrokesView(strokes: List<StrokeData>) {
    Canvas(
        Modifier
            .fillMaxSize()
            .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
    ) {
        for (s in strokes) {
            val pts = s.points
            if (pts.isEmpty()) continue
            val color = Color(s.color).copy(alpha = s.alpha)
            val width = s.widthFrac * size.width
            val blend = if (s.eraser) BlendMode.Clear else BlendMode.SrcOver
            if (pts.size == 1) {
                drawCircle(color, radius = width / 2f, center = Offset(pts[0].x * size.width, pts[0].y * size.height), blendMode = blend)
                continue
            }
            val path = Path()
            path.moveTo(pts[0].x * size.width, pts[0].y * size.height)
            for (i in 1 until pts.size) {
                val prev = pts[i - 1]
                val cur = pts[i]
                path.quadraticBezierTo(
                    prev.x * size.width, prev.y * size.height,
                    (prev.x + cur.x) / 2f * size.width, (prev.y + cur.y) / 2f * size.height,
                )
            }
            path.lineTo(pts.last().x * size.width, pts.last().y * size.height)
            drawPath(
                path = path,
                color = color,
                style = Stroke(width = width, cap = StrokeCap.Round, join = StrokeJoin.Round),
                blendMode = blend,
            )
        }
    }
}

@Composable
private fun SelectionOutline(rect: RectF?, lasso: List<Offset>?) {
    Canvas(Modifier.fillMaxSize()) {
        val dash = PathEffect.dashPathEffect(floatArrayOf(16f, 10f))
        if (lasso != null && lasso.size > 1) {
            val path = Path()
            lasso.forEachIndexed { i, o ->
                val x = o.x * size.width
                val y = o.y * size.height
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            drawPath(path, Color.White, style = Stroke(width = 3f, pathEffect = dash))
        } else if (rect != null) {
            drawRect(
                color = Color.White,
                topLeft = Offset(rect.left * size.width, rect.top * size.height),
                size = androidx.compose.ui.geometry.Size(
                    (rect.right - rect.left) * size.width,
                    (rect.bottom - rect.top) * size.height,
                ),
                style = Stroke(width = 3f, pathEffect = dash),
            )
        }
    }
}

// ============================================================================ crop

@Composable
private fun CropOverlay(doc: EditDoc, rotW: Int, rotH: Int, aspect: Float?, size: IntSize) {
    val k = if (aspect != null) rotW / (aspect * rotH) else null
    Box(
        Modifier
            .fillMaxSize()
            .pointerInput(size, aspect) {
                var target = 0
                detectDragGestures(
                    onDragStart = { o ->
                        val w = size.width.toFloat()
                        val h = size.height.toFloat()
                        val corners = listOf(
                            Offset(doc.cropL * w, doc.cropT * h),
                            Offset(doc.cropR * w, doc.cropT * h),
                            Offset(doc.cropL * w, doc.cropB * h),
                            Offset(doc.cropR * w, doc.cropB * h),
                        )
                        var best = 0
                        var bestDist = 90f
                        corners.forEachIndexed { i, c ->
                            val d = (c - o).getDistance()
                            if (d < bestDist) {
                                bestDist = d
                                best = i + 1
                            }
                        }
                        target = if (best != 0) {
                            best
                        } else if (o.x in doc.cropL * w..doc.cropR * w && o.y in doc.cropT * h..doc.cropB * h) {
                            5
                        } else {
                            0
                        }
                    },
                    onDrag = { change, delta ->
                        change.consume()
                        dragCrop(doc, target, delta.x / size.width, delta.y / size.height, k)
                    },
                )
            }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val w = this.size.width
            val h = this.size.height
            val l = doc.cropL * w
            val t = doc.cropT * h
            val r = doc.cropR * w
            val b = doc.cropB * h
            val dim = Color.Black.copy(alpha = 0.55f)
            drawRect(dim, Offset(0f, 0f), androidx.compose.ui.geometry.Size(w, t))
            drawRect(dim, Offset(0f, b), androidx.compose.ui.geometry.Size(w, h - b))
            drawRect(dim, Offset(0f, t), androidx.compose.ui.geometry.Size(l, b - t))
            drawRect(dim, Offset(r, t), androidx.compose.ui.geometry.Size(w - r, b - t))
            val frame = androidx.compose.ui.geometry.Size(r - l, b - t)
            drawRect(Color.White, Offset(l, t), frame, style = Stroke(width = 3f))
            for (i in 1..2) {
                val x = l + (r - l) * i / 3f
                val y = t + (b - t) * i / 3f
                drawLine(Color.White.copy(alpha = 0.4f), Offset(x, t), Offset(x, b), strokeWidth = 1.5f)
                drawLine(Color.White.copy(alpha = 0.4f), Offset(l, y), Offset(r, y), strokeWidth = 1.5f)
            }
            for (c in listOf(Offset(l, t), Offset(r, t), Offset(l, b), Offset(r, b))) {
                drawCircle(Color.White, radius = 14f, center = c)
            }
        }
    }
}

/** target: 1 top-left, 2 top-right, 3 bottom-left, 4 bottom-right, 5 move. k keeps a fixed shape if not null. */
private fun dragCrop(doc: EditDoc, target: Int, dx: Float, dy: Float, k: Float?) {
    var l = doc.cropL
    var t = doc.cropT
    var r = doc.cropR
    var b = doc.cropB
    when (target) {
        5 -> {
            val w = r - l
            val h = b - t
            l = (l + dx).coerceIn(0f, 1f - w)
            t = (t + dy).coerceIn(0f, 1f - h)
            r = l + w
            b = t + h
        }
        1 -> {
            l = (l + dx).coerceIn(0f, r - MIN_CROP)
            t = (t + dy).coerceIn(0f, b - MIN_CROP)
            if (k != null) {
                t = b - (r - l) * k
                if (t < 0f) {
                    t = 0f
                    l = r - (b - t) / k
                }
            }
        }
        2 -> {
            r = (r + dx).coerceIn(l + MIN_CROP, 1f)
            t = (t + dy).coerceIn(0f, b - MIN_CROP)
            if (k != null) {
                t = b - (r - l) * k
                if (t < 0f) {
                    t = 0f
                    r = l + (b - t) / k
                }
            }
        }
        3 -> {
            l = (l + dx).coerceIn(0f, r - MIN_CROP)
            b = (b + dy).coerceIn(t + MIN_CROP, 1f)
            if (k != null) {
                b = t + (r - l) * k
                if (b > 1f) {
                    b = 1f
                    l = r - (b - t) / k
                }
            }
        }
        4 -> {
            r = (r + dx).coerceIn(l + MIN_CROP, 1f)
            b = (b + dy).coerceIn(t + MIN_CROP, 1f)
            if (k != null) {
                b = t + (r - l) * k
                if (b > 1f) {
                    b = 1f
                    r = l + (b - t) / k
                }
            }
        }
        else -> return
    }
    doc.cropL = l.coerceIn(0f, 1f)
    doc.cropT = t.coerceIn(0f, 1f)
    doc.cropR = r.coerceIn(0f, 1f)
    doc.cropB = b.coerceIn(0f, 1f)
}

/** Largest centred crop of the given pixel shape (width / height). */
private fun applyAspect(doc: EditDoc, aspect: Float, rotW: Int, rotH: Int) {
    val k = rotW / (aspect * rotH)
    val w = if (k <= 1f) 1f else 1f / k
    val h = if (k <= 1f) k else 1f
    doc.cropL = (1f - w) / 2f
    doc.cropR = doc.cropL + w
    doc.cropT = (1f - h) / 2f
    doc.cropB = doc.cropT + h
}

// ============================================================================ panels

@Composable
private fun ChipLine(content: @Composable () -> Unit) {
    Row(
        Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) { content() }
}

@Composable
private fun LabeledSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, style = MaterialTheme.typography.labelMedium, modifier = Modifier.width(84.dp))
        Slider(value = value, onValueChange = onChange, valueRange = range, modifier = Modifier.weight(1f))
    }
}

@Composable
private fun Swatches(selected: Int, onPick: (Int) -> Unit) {
    ChipLine {
        PALETTE.forEach { c ->
            Box(
                Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(Color(c))
                    .border(
                        width = if (c == selected) 3.dp else 1.dp,
                        color = if (c == selected) Color(0xFFFFD166) else Color.Gray,
                        shape = CircleShape,
                    )
                    .clickable { onPick(c) }
            )
        }
    }
}

@Composable
private fun CropPanel(doc: EditDoc, rotW: Int, rotH: Int, aspect: Float?, onAspect: (Float?) -> Unit) {
    val presets = listOf(
        "Free" to null,
        "Original" to (rotW.toFloat() / rotH),
        "1:1" to 1f,
        "4:5" to 0.8f,
        "9:16" to 0.5625f,
        "16:9" to 1.7778f,
        "3:2" to 1.5f,
    )
    ChipLine {
        presets.forEach { (name, value) ->
            FilterChip(
                selected = aspect == value,
                onClick = {
                    onAspect(value)
                    if (value != null) applyAspect(doc, value, rotW, rotH) else Unit
                },
                label = { Text(name) },
            )
        }
    }
    ChipLine {
        TextButton(onClick = { doc.quarter = (doc.quarter + 3) % 4; doc.resetCrop(); onAspect(null) }) { Text("⟲ Rotate left", color = Color.White) }
        TextButton(onClick = { doc.quarter = (doc.quarter + 1) % 4; doc.resetCrop(); onAspect(null) }) { Text("Rotate right ⟳", color = Color.White) }
        TextButton(onClick = { doc.flip = !doc.flip; doc.resetCrop(); onAspect(null) }) { Text("Flip", color = Color.White) }
        TextButton(onClick = { doc.resetCrop(); onAspect(null) }) { Text("Reset crop", color = Color.White) }
    }
}

@Composable
private fun AdjustPanel(doc: EditDoc) {
    LabeledSlider("Brightness", doc.brightness, -0.5f..0.5f) { doc.brightness = it }
    LabeledSlider("Contrast", doc.contrast, -0.5f..0.5f) { doc.contrast = it }
    LabeledSlider("Saturation", doc.saturation, -1f..1f) { doc.saturation = it }
    LabeledSlider("Warmth", doc.warmth, -1f..1f) { doc.warmth = it }
    LabeledSlider("Vignette", doc.vignette, 0f..1f) { doc.vignette = it }
    TextButton(onClick = { doc.resetLook() }) { Text("Reset adjustments", color = Color.White) }
}

@Composable
private fun FilterPanel(doc: EditDoc) {
    ChipLine {
        EditorRender.FILTER_NAMES.forEachIndexed { index, name ->
            FilterChip(selected = doc.filter == index, onClick = { doc.filter = index }, label = { Text(name) })
        }
    }
    LabeledSlider("Strength", doc.filterAmount, 0f..1f) { doc.filterAmount = it }
}

@Composable
private fun TextPanel(doc: EditDoc, selected: EditLayer?, onAdd: () -> Unit) {
    OutlinedButton(onClick = onAdd) { Text("＋ Add text", color = Color.White) }
    if (selected != null && selected.kind == 0) {
        Text("Font", color = Color.White, style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(top = 6.dp))
        ChipLine {
            EditorFonts.entries.forEachIndexed { index, entry ->
                FilterChip(
                    selected = selected.fontIndex == index,
                    onClick = { selected.fontIndex = index },
                    label = { Text(entry.name, fontFamily = entry.family, fontWeight = EditorFonts.weight(index)) },
                )
            }
        }
        Text("Colour", color = Color.White, style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(top = 6.dp))
        Swatches(selected.color) { selected.color = it }
        ChipLine {
            listOf("No box", "Dark box", "Light box", "Colour box").forEachIndexed { index, name ->
                FilterChip(selected = selected.bgMode == index, onClick = { selected.bgMode = index }, label = { Text(name) })
            }
        }
        LabeledSlider("Size", selected.sizeFrac, 0.03f..0.3f) { selected.sizeFrac = it }
        Text(
            "Pinch to resize and twist to rotate. Double-tap the text to edit it.",
            color = Color.Gray,
            style = MaterialTheme.typography.bodySmall,
        )
    } else {
        Text(
            "Tap a piece of text to change its font and colour. Drag with one finger, pinch and twist with two.",
            color = Color.Gray,
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(top = 6.dp),
        )
    }
}

@Composable
private fun DrawPanel(
    color: Int,
    onColor: (Int) -> Unit,
    width: Float,
    onWidth: (Float) -> Unit,
    tool: Int,
    onTool: (Int) -> Unit,
    onUndo: () -> Unit,
    onClear: () -> Unit,
) {
    ChipLine {
        listOf("Pen", "Marker", "Eraser").forEachIndexed { index, name ->
            FilterChip(selected = tool == index, onClick = { onTool(index) }, label = { Text(name) })
        }
        TextButton(onClick = onUndo) { Text("Undo", color = Color.White) }
        TextButton(onClick = onClear) { Text("Clear", color = Color(0xFFFF8A80)) }
    }
    if (tool != 2) Swatches(color, onColor)
    LabeledSlider("Thickness", width, 0.004f..0.05f, onWidth)
}

@Composable
private fun StickerPanel(onPick: (String) -> Unit) {
    EMOJIS.chunked(14).forEach { row ->
        ChipLine {
            row.forEach { e ->
                Text(e, fontSize = 28.sp, modifier = Modifier.clickable { onPick(e) }.padding(4.dp))
            }
        }
    }
    Text(
        "Tap a sticker to add it. Drag, pinch and twist to place it.",
        color = Color.Gray,
        style = MaterialTheme.typography.bodySmall,
    )
}

@Composable
private fun CutoutPanel(
    story: Boolean,
    tool: Int,
    onTool: (Int) -> Unit,
    hasSelection: Boolean,
    onCopy: () -> Unit,
    onCut: () -> Unit,
) {
    if (story) {
        Text(
            "Turn off the story canvas (Story tab) to cut or copy part of the photo.",
            color = Color.Gray,
            style = MaterialTheme.typography.bodySmall,
        )
        return
    }
    ChipLine {
        FilterChip(selected = tool == 0, onClick = { onTool(0) }, label = { Text("Rectangle") })
        FilterChip(selected = tool == 1, onClick = { onTool(1) }, label = { Text("Freehand") })
    }
    ChipLine {
        OutlinedButton(onClick = onCopy, enabled = hasSelection) { Text("Copy piece", color = Color.White) }
        OutlinedButton(onClick = onCut, enabled = hasSelection) { Text("Cut piece", color = Color.White) }
    }
    Text(
        if (tool == 0) "Drag on the photo to select a rectangle." else "Draw around the part you want.",
        color = Color.Gray,
        style = MaterialTheme.typography.bodySmall,
    )
}

@Composable
private fun StoryPanel(doc: EditDoc) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("Story canvas (9:16)", color = Color.White, modifier = Modifier.weight(1f))
        Switch(checked = doc.story, onCheckedChange = { doc.story = it })
    }
    if (doc.story) {
        Text("Background", color = Color.White, style = MaterialTheme.typography.labelMedium)
        ChipLine {
            EditorRender.STORY_BG_NAMES.forEachIndexed { index, name ->
                FilterChip(selected = doc.storyBg == index, onClick = { doc.storyBg = index }, label = { Text(name) })
            }
        }
        ChipLine {
            FilterChip(selected = !doc.storyFill, onClick = { doc.storyFill = false }, label = { Text("Photo fits") })
            FilterChip(selected = doc.storyFill, onClick = { doc.storyFill = true }, label = { Text("Photo fills") })
        }
        Text(
            "Add text, stickers and drawings, then Share → Instagram. Gallerfix can't post by itself: it hands the image to Instagram.",
            color = Color.Gray,
            style = MaterialTheme.typography.bodySmall,
        )
    } else {
        Text(
            "Turn this on to make a tall 9:16 picture for Instagram, Facebook or WhatsApp stories.",
            color = Color.Gray,
            style = MaterialTheme.typography.bodySmall,
        )
    }
}

@Composable
private fun TextEditDialog(initial: String, onConfirm: (String) -> Unit, onDismiss: () -> Unit) {
    var value by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Your text") },
        text = {
            OutlinedTextField(
                value = value,
                onValueChange = { value = it.take(120) },
                label = { Text("Type here") },
                modifier = Modifier.fillMaxWidth(),
            )
        },
        confirmButton = { TextButton(onClick = { onConfirm(value) }, enabled = value.isNotBlank()) { Text("Done") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
