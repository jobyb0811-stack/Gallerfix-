package com.gallerfix.app.ui.editor

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.ImageDecoder
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.net.Uri
import android.provider.MediaStore
import android.text.Layout
import android.text.StaticLayout
import android.text.TextPaint
import androidx.compose.ui.geometry.Offset
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Draws the edited picture. Used both for the on-screen preview (small) and for saving (full size). */
object EditorRender {

    val FILTER_NAMES = listOf("None", "Mono", "Noir", "Sepia", "Vivid", "Fade", "Cool", "Warm", "Vintage")

    /** Story backgrounds after "Blur", "Black" and "White". */
    val GRADIENTS: List<Pair<Int, Int>> = listOf(
        0xFFFF512F.toInt() to 0xFFDD2476.toInt(),
        0xFF2193B0.toInt() to 0xFF6DD5ED.toInt(),
        0xFF8E2DE2.toInt() to 0xFF4A00E0.toInt(),
        0xFFF7971E.toInt() to 0xFFFFD200.toInt(),
    )
    val STORY_BG_NAMES = listOf("Blur", "Black", "White", "Sunset", "Ocean", "Violet", "Gold")

    // ------------------------------------------------------------------ loading

    fun decode(context: Context, uri: Uri, maxPx: Int = 2400): Bitmap? = try {
        val source = ImageDecoder.createSource(context.contentResolver, uri)
        ImageDecoder.decodeBitmap(source) { decoder, info, _ ->
            decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            decoder.setTargetSampleSize(max(1, max(info.size.width, info.size.height) / maxPx))
        }
    } catch (e: Exception) {
        null
    }

    fun rotateFlip(src: Bitmap, quarter: Int, flip: Boolean): Bitmap {
        if (quarter % 4 == 0 && !flip) return src
        val m = Matrix()
        m.postRotate((quarter % 4) * 90f)
        if (flip) m.postScale(-1f, 1f)
        return Bitmap.createBitmap(src, 0, 0, src.width, src.height, m, true)
    }

    // ------------------------------------------------------------------ colour

    private fun lerpMatrix(f: ColorMatrix, amount: Float): ColorMatrix {
        val identity = floatArrayOf(
            1f, 0f, 0f, 0f, 0f,
            0f, 1f, 0f, 0f, 0f,
            0f, 0f, 1f, 0f, 0f,
            0f, 0f, 0f, 1f, 0f,
        )
        val values = f.array
        val out = FloatArray(20) { identity[it] + (values[it] - identity[it]) * amount }
        return ColorMatrix(out)
    }

    private fun scaleOffset(rs: Float, gs: Float, bs: Float, offset: Float = 0f) = ColorMatrix(
        floatArrayOf(
            rs, 0f, 0f, 0f, offset,
            0f, gs, 0f, 0f, offset,
            0f, 0f, bs, 0f, offset,
            0f, 0f, 0f, 1f, 0f,
        )
    )

    private fun filterMatrix(index: Int): ColorMatrix? = when (index) {
        1 -> ColorMatrix().apply { setSaturation(0f) }
        2 -> ColorMatrix().apply {
            setSaturation(0f)
            postConcat(scaleOffset(1.35f, 1.35f, 1.35f, -30f))
        }
        3 -> ColorMatrix(
            floatArrayOf(
                0.393f, 0.769f, 0.189f, 0f, 0f,
                0.349f, 0.686f, 0.168f, 0f, 0f,
                0.272f, 0.534f, 0.131f, 0f, 0f,
                0f, 0f, 0f, 1f, 0f,
            )
        )
        4 -> ColorMatrix().apply {
            setSaturation(1.5f)
            postConcat(scaleOffset(1.1f, 1.1f, 1.1f, -10f))
        }
        5 -> ColorMatrix().apply {
            setSaturation(0.8f)
            postConcat(scaleOffset(0.85f, 0.85f, 0.85f, 30f))
        }
        6 -> scaleOffset(0.92f, 1.0f, 1.15f)
        7 -> scaleOffset(1.12f, 1.03f, 0.88f)
        8 -> ColorMatrix(
            floatArrayOf(
                0.393f, 0.769f, 0.189f, 0f, 0f,
                0.349f, 0.686f, 0.168f, 0f, 0f,
                0.272f, 0.534f, 0.131f, 0f, 0f,
                0f, 0f, 0f, 1f, 0f,
            )
        ).apply { postConcat(scaleOffset(0.88f, 0.88f, 0.88f, 24f)) }
        else -> null
    }

    fun colorMatrix(p: RenderParams): ColorMatrix {
        val m = ColorMatrix()
        m.postConcat(ColorMatrix().apply { setSaturation((1f + p.saturation).coerceIn(0f, 2.5f)) })
        val s = 1f + p.contrast
        m.postConcat(scaleOffset(s, s, s, 128f * (1f - s) + p.brightness * 255f))
        val w = p.warmth * 0.18f
        m.postConcat(scaleOffset(1f + w, 1f, 1f - w))
        val f = filterMatrix(p.filter)
        if (f != null) m.postConcat(lerpMatrix(f, p.filterAmount))
        return m
    }

    // ------------------------------------------------------------------ the base picture

    /** Crops, applies the colour changes and the vignette. */
    fun cropColor(rotated: Bitmap, p: RenderParams, maxPx: Int): Bitmap {
        val x = (p.cropL * rotated.width).toInt().coerceIn(0, rotated.width - 1)
        val y = (p.cropT * rotated.height).toInt().coerceIn(0, rotated.height - 1)
        val w = ((p.cropR - p.cropL) * rotated.width).toInt().coerceIn(1, rotated.width - x)
        val h = ((p.cropB - p.cropT) * rotated.height).toInt().coerceIn(1, rotated.height - y)
        val cropped = Bitmap.createBitmap(rotated, x, y, w, h)
        val scale = min(1f, maxPx.toFloat() / max(w, h))
        val ow = max(1, (w * scale).roundToInt())
        val oh = max(1, (h * scale).roundToInt())
        val out = Bitmap.createBitmap(ow, oh, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        paint.colorFilter = ColorMatrixColorFilter(colorMatrix(p))
        canvas.drawBitmap(cropped, null, Rect(0, 0, ow, oh), paint)
        if (p.vignette > 0.01f) {
            val vp = Paint()
            vp.shader = RadialGradient(
                ow / 2f, oh / 2f, max(ow, oh) * 0.75f,
                intArrayOf(0x00000000, (p.vignette * 220f).toInt() shl 24),
                floatArrayOf(0.45f, 1f),
                Shader.TileMode.CLAMP,
            )
            canvas.drawRect(0f, 0f, ow.toFloat(), oh.toFloat(), vp)
        }
        return out
    }

    /** Output size: the story canvas, or the cropped picture shrunk to fit [longSide]. */
    fun outputSize(rotated: Bitmap, p: RenderParams, longSide: Int): Pair<Int, Int> {
        if (p.story) return Pair(max(1, longSide * 9 / 16), longSide)
        val w = max(1f, (p.cropR - p.cropL) * rotated.width)
        val h = max(1f, (p.cropB - p.cropT) * rotated.height)
        val scale = min(1f, longSide / max(w, h))
        return Pair(max(1, (w * scale).roundToInt()), max(1, (h * scale).roundToInt()))
    }

    /** The picture without text, stickers or drawing. A mutable bitmap of exactly [w] by [h]. */
    fun canvasBase(rotated: Bitmap, p: RenderParams, w: Int, h: Int): Bitmap {
        val photo = cropColor(rotated, p, max(w, h))
        if (!p.story) return photo

        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        when {
            p.storyBg == 0 -> {
                val tiny = Bitmap.createScaledBitmap(photo, 24, max(2, 24 * photo.height / photo.width), true)
                val cover = max(w / tiny.width.toFloat(), h / tiny.height.toFloat())
                val dw = tiny.width * cover
                val dh = tiny.height * cover
                c.drawBitmap(tiny, null, RectF((w - dw) / 2f, (h - dh) / 2f, (w + dw) / 2f, (h + dh) / 2f), paint)
                c.drawColor(0x44000000)
            }
            p.storyBg == 1 -> c.drawColor(Color.BLACK)
            p.storyBg == 2 -> c.drawColor(Color.WHITE)
            else -> {
                val g = GRADIENTS[(p.storyBg - 3).coerceIn(0, GRADIENTS.lastIndex)]
                val gp = Paint()
                gp.shader = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), g.first, g.second, Shader.TileMode.CLAMP)
                c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), gp)
            }
        }
        val fit = min(w / photo.width.toFloat(), h / photo.height.toFloat()) * 0.94f
        val fill = max(w / photo.width.toFloat(), h / photo.height.toFloat())
        val scale = if (p.storyFill) fill else fit
        val dw = photo.width * scale
        val dh = photo.height * scale
        val dest = RectF((w - dw) / 2f, (h - dh) / 2f, (w + dw) / 2f, (h + dh) / 2f)
        if (!p.storyFill) {
            val clip = Path()
            clip.addRoundRect(dest, w * 0.04f, w * 0.04f, Path.Direction.CW)
            c.save()
            c.clipPath(clip)
            c.drawBitmap(photo, null, dest, paint)
            c.restore()
        } else {
            c.drawBitmap(photo, null, dest, paint)
        }
        return out
    }

    // ------------------------------------------------------------------ text colours (shared with the preview)

    private fun isLight(color: Int): Boolean =
        (0.299f * Color.red(color) + 0.587f * Color.green(color) + 0.114f * Color.blue(color)) > 150f

    fun textColor(kind: Int, color: Int, bgMode: Int): Int =
        if (kind == 0 && bgMode == 3) (if (isLight(color)) Color.BLACK else Color.WHITE) else color

    /** The box behind the text, or null for none. */
    fun boxColor(bgMode: Int, color: Int): Int? = when (bgMode) {
        1 -> 0xB3000000.toInt()
        2 -> 0xE6FFFFFF.toInt()
        3 -> color
        else -> null
    }

    // ------------------------------------------------------------------ overlays

    fun drawOverlays(
        context: Context,
        canvas: Canvas,
        w: Int,
        h: Int,
        layers: List<LayerSnap>,
        strokes: List<StrokeSnap>,
    ) {
        for (layer in layers) drawLayer(context, canvas, w, h, layer)
        if (strokes.isNotEmpty()) {
            val ink = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val inkCanvas = Canvas(ink)
            for (s in strokes) drawStroke(inkCanvas, w, h, s)
            canvas.drawBitmap(ink, 0f, 0f, null)
            ink.recycle()
        }
    }

    private fun drawStroke(canvas: Canvas, w: Int, h: Int, s: StrokeSnap) {
        if (s.points.isEmpty()) return
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        paint.style = Paint.Style.STROKE
        paint.strokeCap = Paint.Cap.ROUND
        paint.strokeJoin = Paint.Join.ROUND
        paint.strokeWidth = s.widthFrac * w
        paint.color = s.color
        paint.alpha = (s.alpha * 255f).toInt().coerceIn(0, 255)
        if (s.eraser) paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
        val first = s.points.first()
        if (s.points.size == 1) {
            paint.style = Paint.Style.FILL
            canvas.drawCircle(first.x * w, first.y * h, s.widthFrac * w / 2f, paint)
            return
        }
        val path = Path()
        path.moveTo(first.x * w, first.y * h)
        for (i in 1 until s.points.size) {
            val prev = s.points[i - 1]
            val cur = s.points[i]
            path.quadTo(prev.x * w, prev.y * h, (prev.x + cur.x) / 2f * w, (prev.y + cur.y) / 2f * h)
        }
        val last = s.points.last()
        path.lineTo(last.x * w, last.y * h)
        canvas.drawPath(path, paint)
    }

    private fun drawLayer(context: Context, canvas: Canvas, w: Int, h: Int, l: LayerSnap) {
        canvas.save()
        canvas.translate(l.cx * w, l.cy * h)
        canvas.rotate(l.rot)
        canvas.scale(l.scale, l.scale)
        when (l.kind) {
            2 -> {
                val bmp = l.bitmap
                if (bmp != null) {
                    val dw = l.sizeFrac * w
                    val dh = dw * bmp.height / bmp.width
                    val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
                    canvas.drawBitmap(bmp, null, RectF(-dw / 2f, -dh / 2f, dw / 2f, dh / 2f), paint)
                }
            }
            else -> drawText(context, canvas, w, l)
        }
        canvas.restore()
    }

    private fun drawText(context: Context, canvas: Canvas, w: Int, l: LayerSnap) {
        if (l.text.isEmpty()) return
        val size = l.sizeFrac * w
        val paint = TextPaint(Paint.ANTI_ALIAS_FLAG)
        paint.textSize = size
        paint.color = textColor(l.kind, l.color, l.bgMode)
        paint.typeface = if (l.kind == 0) EditorFonts.typeface(context, l.fontIndex) else android.graphics.Typeface.DEFAULT
        val widest = l.text.split("\n").maxOf { paint.measureText(it) }
        val layoutWidth = ceil(widest).toInt() + 2
        val layout = StaticLayout.Builder.obtain(l.text, 0, l.text.length, paint, layoutWidth)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setIncludePad(false)
            .build()
        val box = if (l.kind == 0) boxColor(l.bgMode, l.color) else null
        val padX = if (l.kind == 0) size * 0.35f else 0f
        val padY = if (l.kind == 0) size * 0.15f else 0f
        val boxW = layout.width + 2 * padX
        val boxH = layout.height + 2 * padY
        canvas.translate(-boxW / 2f, -boxH / 2f)
        if (box != null) {
            val bg = Paint(Paint.ANTI_ALIAS_FLAG)
            bg.color = box
            canvas.drawRoundRect(0f, 0f, boxW, boxH, size * 0.3f, size * 0.3f, bg)
        }
        canvas.translate(padX, padY)
        layout.draw(canvas)
    }

    // ------------------------------------------------------------------ cut and copy

    /** A piece of [bmp]: the rectangle [rect] (fractions), or only the part inside [lasso] if given. */
    fun cutPiece(bmp: Bitmap, rect: RectF, lasso: List<Offset>?): Bitmap {
        val l = (rect.left * bmp.width).toInt().coerceIn(0, bmp.width - 1)
        val t = (rect.top * bmp.height).toInt().coerceIn(0, bmp.height - 1)
        val w = ((rect.right - rect.left) * bmp.width).toInt().coerceIn(1, bmp.width - l)
        val h = ((rect.bottom - rect.top) * bmp.height).toInt().coerceIn(1, bmp.height - t)
        val piece = Bitmap.createBitmap(bmp, l, t, w, h)
        if (lasso == null || lasso.size < 3) return piece.copy(Bitmap.Config.ARGB_8888, true)
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val path = Path()
        lasso.forEachIndexed { i, o ->
            val x = o.x * bmp.width - l
            val y = o.y * bmp.height - t
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        val mask = Paint(Paint.ANTI_ALIAS_FLAG)
        mask.color = Color.WHITE
        c.drawPath(path, mask)
        val keep = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        keep.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
        c.drawBitmap(piece, 0f, 0f, keep)
        return out
    }

    /** The picture with that region smoothed over, as if the piece had been lifted out. */
    fun fillRegion(bmp: Bitmap, rect: RectF, lasso: List<Offset>?): Bitmap {
        val out = bmp.copy(Bitmap.Config.ARGB_8888, true)
        val tiny = Bitmap.createScaledBitmap(bmp, max(1, bmp.width / 40), max(1, bmp.height / 40), true)
        val c = Canvas(out)
        c.save()
        if (lasso != null && lasso.size >= 3) {
            val path = Path()
            lasso.forEachIndexed { i, o ->
                val x = o.x * bmp.width
                val y = o.y * bmp.height
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            path.close()
            c.clipPath(path)
        } else {
            c.clipRect(rect.left * bmp.width, rect.top * bmp.height, rect.right * bmp.width, rect.bottom * bmp.height)
        }
        c.drawBitmap(tiny, null, Rect(0, 0, bmp.width, bmp.height), Paint(Paint.FILTER_BITMAP_FLAG))
        c.restore()
        return out
    }

    // ------------------------------------------------------------------ saving

    fun save(context: Context, bmp: Bitmap, prefix: String): Uri? {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "${prefix}_$stamp.jpg")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/Gallerfix")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val resolver = context.contentResolver
        val collection = MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        val uri = resolver.insert(collection, values) ?: return null
        return try {
            val out = resolver.openOutputStream(uri) ?: throw IOException("no stream")
            out.use {
                if (!bmp.compress(Bitmap.CompressFormat.JPEG, 95, it)) throw IOException("compress failed")
            }
            values.clear()
            values.put(MediaStore.MediaColumns.IS_PENDING, 0)
            resolver.update(uri, values, null, null)
            uri
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            null
        }
    }
}
