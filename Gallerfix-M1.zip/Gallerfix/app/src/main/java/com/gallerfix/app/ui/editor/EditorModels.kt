package com.gallerfix.app.ui.editor

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Typeface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.core.content.res.ResourcesCompat
import com.gallerfix.app.R

/** The fonts you can pick for text. All of them live inside the app, so the editor works offline. */
object EditorFonts {
    class Entry(
        val name: String,
        val resId: Int?,
        val generic: FontFamily,
        val genericFace: Typeface,
        val bold: Boolean = false,
    ) {
        val family: FontFamily = if (resId != null) FontFamily(Font(resId)) else generic
    }

    val entries: List<Entry> = listOf(
        Entry("Clean", null, FontFamily.SansSerif, Typeface.SANS_SERIF),
        Entry("Bold", null, FontFamily.SansSerif, Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD), bold = true),
        Entry("Serif", null, FontFamily.Serif, Typeface.SERIF),
        Entry("Mono", null, FontFamily.Monospace, Typeface.MONOSPACE),
        Entry("Script", R.font.pacifico, FontFamily.SansSerif, Typeface.SANS_SERIF),
        Entry("Retro", R.font.lobster, FontFamily.SansSerif, Typeface.SANS_SERIF),
        Entry("Brush", R.font.yellowtail, FontFamily.SansSerif, Typeface.SANS_SERIF),
        Entry("Curly", R.font.courgette, FontFamily.SansSerif, Typeface.SANS_SERIF),
        Entry("Hand", R.font.shadows_into_light, FontFamily.SansSerif, Typeface.SANS_SERIF),
        Entry("Marker", R.font.permanent_marker, FontFamily.SansSerif, Typeface.SANS_SERIF),
        Entry("Typewriter", R.font.special_elite, FontFamily.SansSerif, Typeface.SANS_SERIF),
        Entry("Poster", R.font.anton, FontFamily.SansSerif, Typeface.SANS_SERIF),
        Entry("Condensed", R.font.bebas_neue, FontFamily.SansSerif, Typeface.SANS_SERIF),
        Entry("Fat", R.font.abril_fatface, FontFamily.SansSerif, Typeface.SANS_SERIF),
        Entry("Comic", R.font.bangers, FontFamily.SansSerif, Typeface.SANS_SERIF),
        Entry("Round", R.font.righteous, FontFamily.SansSerif, Typeface.SANS_SERIF),
        Entry("Pixel", R.font.press_start_2p, FontFamily.SansSerif, Typeface.SANS_SERIF),
    )

    private val cache = HashMap<Int, Typeface>()

    fun family(index: Int): FontFamily = entries[index.coerceIn(0, entries.lastIndex)].family

    fun weight(index: Int): FontWeight =
        if (entries[index.coerceIn(0, entries.lastIndex)].bold) FontWeight.Bold else FontWeight.Normal

    /** The same font for drawing onto the saved picture. */
    fun typeface(context: Context, index: Int): Typeface {
        val entry = entries[index.coerceIn(0, entries.lastIndex)]
        val id = entry.resId ?: return entry.genericFace
        return cache.getOrPut(id) { ResourcesCompat.getFont(context, id) ?: Typeface.DEFAULT }
    }
}

/** One thing laid over the photo: text (kind 0), an emoji sticker (1) or a piece cut from the photo (2). */
class EditLayer(val id: Int, val kind: Int) {
    /** Centre of the layer, as a fraction of the picture's width and height. */
    var cx by mutableFloatStateOf(0.5f)
    var cy by mutableFloatStateOf(0.5f)
    var scale by mutableFloatStateOf(1f)
    var rot by mutableFloatStateOf(0f)

    var text by mutableStateOf("")
    var fontIndex by mutableIntStateOf(0)
    var color by mutableIntStateOf(0xFFFFFFFF.toInt())
    /** 0 none, 1 dark box, 2 light box, 3 box in the text colour */
    var bgMode by mutableIntStateOf(0)
    /** Text size (or sticker size, or cut-out width) as a fraction of the picture's width. */
    var sizeFrac by mutableFloatStateOf(0.09f)

    var bitmap: Bitmap? = null

    /** Size on screen before scaling, measured by the preview (used to tap and drag the layer). */
    var widthPx by mutableIntStateOf(0)
    var heightPx by mutableIntStateOf(0)

    fun snap() = LayerSnap(kind, cx, cy, scale, rot, text, fontIndex, color, bgMode, sizeFrac, bitmap)
}

/** A line drawn with the pen, marker or eraser. Points are fractions of the picture's width and height. */
class StrokeData(val color: Int, val widthFrac: Float, val alpha: Float, val eraser: Boolean) {
    val points = mutableStateListOf<Offset>()
    fun snap() = StrokeSnap(color, widthFrac, alpha, eraser, points.toList())
}

class LayerSnap(
    val kind: Int,
    val cx: Float,
    val cy: Float,
    val scale: Float,
    val rot: Float,
    val text: String,
    val fontIndex: Int,
    val color: Int,
    val bgMode: Int,
    val sizeFrac: Float,
    val bitmap: Bitmap?,
)

class StrokeSnap(
    val color: Int,
    val widthFrac: Float,
    val alpha: Float,
    val eraser: Boolean,
    val points: List<Offset>,
)

/** Everything that decides how the base picture looks. A plain copy, safe to use on a background thread. */
data class RenderParams(
    val cropL: Float,
    val cropT: Float,
    val cropR: Float,
    val cropB: Float,
    val brightness: Float,
    val contrast: Float,
    val saturation: Float,
    val warmth: Float,
    val vignette: Float,
    val filter: Int,
    val filterAmount: Float,
    val story: Boolean,
    val storyBg: Int,
    val storyFill: Boolean,
)

class EditDoc {
    var source by mutableStateOf<Bitmap?>(null)
    var baked by mutableStateOf(false)

    var quarter by mutableIntStateOf(0)
    var flip by mutableStateOf(false)

    var cropL by mutableFloatStateOf(0f)
    var cropT by mutableFloatStateOf(0f)
    var cropR by mutableFloatStateOf(1f)
    var cropB by mutableFloatStateOf(1f)

    var brightness by mutableFloatStateOf(0f)
    var contrast by mutableFloatStateOf(0f)
    var saturation by mutableFloatStateOf(0f)
    var warmth by mutableFloatStateOf(0f)
    var vignette by mutableFloatStateOf(0f)

    var filter by mutableIntStateOf(0)
    var filterAmount by mutableFloatStateOf(1f)

    var story by mutableStateOf(false)
    var storyBg by mutableIntStateOf(0)
    var storyFill by mutableStateOf(false)

    val layers = mutableStateListOf<EditLayer>()
    val strokes = mutableStateListOf<StrokeData>()
    var nextId = 1

    fun resetCrop() {
        cropL = 0f
        cropT = 0f
        cropR = 1f
        cropB = 1f
    }

    fun resetLook() {
        brightness = 0f
        contrast = 0f
        saturation = 0f
        warmth = 0f
        vignette = 0f
        filter = 0
        filterAmount = 1f
    }

    fun params() = RenderParams(
        cropL, cropT, cropR, cropB,
        brightness, contrast, saturation, warmth, vignette,
        filter, filterAmount,
        story, storyBg, storyFill,
    )

    val isDirty: Boolean
        get() = layers.isNotEmpty() || strokes.isNotEmpty() || baked || quarter != 0 || flip ||
            cropL != 0f || cropT != 0f || cropR != 1f || cropB != 1f ||
            brightness != 0f || contrast != 0f || saturation != 0f || warmth != 0f || vignette != 0f ||
            filter != 0 || story
}
