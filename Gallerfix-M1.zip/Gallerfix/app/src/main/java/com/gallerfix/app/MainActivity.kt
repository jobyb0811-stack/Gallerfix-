package com.gallerfix.app

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.gallerfix.app.ui.GalleryApp
import com.gallerfix.app.ui.GalleryViewModel
import com.gallerfix.app.ui.LockScreen
import com.gallerfix.app.ui.theme.GallerfixTheme

// FragmentActivity (a ComponentActivity) is required by the system biometric prompt.
class MainActivity : FragmentActivity() {
    private val viewModel: GalleryViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()
            val palette by viewModel.palette.collectAsStateWithLifecycle()
            val amoled by viewModel.amoled.collectAsStateWithLifecycle()
            val locked by viewModel.locked.collectAsStateWithLifecycle()
            val secure by viewModel.secureWindow.collectAsStateWithLifecycle()
            val lockBiometric by viewModel.lockBiometric.collectAsStateWithLifecycle()
            val lockTaps by viewModel.lockTaps.collectAsStateWithLifecycle()
            val tapCount by viewModel.tapCount.collectAsStateWithLifecycle()

            DisposableEffect(secure) {
                if (secure) {
                    window.setFlags(
                        WindowManager.LayoutParams.FLAG_SECURE,
                        WindowManager.LayoutParams.FLAG_SECURE,
                    )
                } else {
                    window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
                }
                onDispose { }
            }

            GallerfixTheme(themeMode = themeMode, palette = palette, amoled = amoled) {
                if (locked) {
                    LockScreen(
                        biometricEnabled = lockBiometric,
                        tapsEnabled = lockTaps,
                        tapTarget = tapCount,
                        onUnlock = { viewModel.unlock() },
                        onDisableLock = { viewModel.setLockEnabled(false) },
                    )
                } else {
                    GalleryApp(viewModel)
                }
            }
        }
    }

    override fun onStart() {
        super.onStart()
        viewModel.onForegrounded()
    }

    override fun onStop() {
        super.onStop()
        // Rotation also stops the activity; don't lock for that.
        if (!isChangingConfigurations) viewModel.onBackgrounded()
    }
}
