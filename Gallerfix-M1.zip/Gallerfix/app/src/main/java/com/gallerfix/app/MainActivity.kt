package com.gallerfix.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.gallerfix.app.ui.GalleryApp
import com.gallerfix.app.ui.GalleryViewModel
import com.gallerfix.app.ui.theme.GallerfixTheme

class MainActivity : ComponentActivity() {
    private val viewModel: GalleryViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()
            val palette by viewModel.palette.collectAsStateWithLifecycle()
            val amoled by viewModel.amoled.collectAsStateWithLifecycle()
            GallerfixTheme(themeMode = themeMode, palette = palette, amoled = amoled) {
                GalleryApp(viewModel)
            }
        }
    }
}
