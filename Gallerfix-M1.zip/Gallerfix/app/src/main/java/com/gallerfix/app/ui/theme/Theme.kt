package com.gallerfix.app.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

class PaletteDef(
    val name: String,
    val lightPrimary: Color,
    val lightContainer: Color,
    val darkPrimary: Color,
    val darkContainer: Color,
)

/** Index 0 is "Wallpaper" (dynamic colors); its entry is the fallback used on Android 11. */
val PALETTES: List<PaletteDef> = listOf(
    PaletteDef("Wallpaper", Color(0xFF0B6BCB), Color(0xFFD4E6FB), Color(0xFF7DB7F5), Color(0xFF1F4E80)),
    PaletteDef("Ocean", Color(0xFF0B6BCB), Color(0xFFD4E6FB), Color(0xFF7DB7F5), Color(0xFF1F4E80)),
    PaletteDef("Forest", Color(0xFF2E7D4F), Color(0xFFD3EBDC), Color(0xFF7BC99A), Color(0xFF21533A)),
    PaletteDef("Rose", Color(0xFFC2185B), Color(0xFFF8D8E4), Color(0xFFF48FB1), Color(0xFF7B2147)),
    PaletteDef("Amber", Color(0xFFB26A00), Color(0xFFFBE3B8), Color(0xFFFFB74D), Color(0xFF6B4300)),
    PaletteDef("Mono", Color(0xFF3A3D42), Color(0xFFE1E3E8), Color(0xFFC9CCD2), Color(0xFF3B3E44)),
)

private fun paletteScheme(def: PaletteDef, dark: Boolean): ColorScheme =
    if (dark) {
        darkColorScheme(
            primary = def.darkPrimary,
            onPrimary = Color(0xFF101010),
            primaryContainer = def.darkContainer,
            onPrimaryContainer = Color.White,
            secondary = def.darkPrimary,
            onSecondary = Color(0xFF101010),
            secondaryContainer = def.darkContainer,
            onSecondaryContainer = Color.White,
            tertiary = def.darkPrimary,
            background = Color(0xFF111214),
            onBackground = Color(0xFFE6E6E8),
            surface = Color(0xFF111214),
            onSurface = Color(0xFFE6E6E8),
            onSurfaceVariant = Color(0xFFB5B8BE),
            surfaceContainerHigh = Color(0xFF24262A),
            outlineVariant = Color(0xFF45484E),
        )
    } else {
        lightColorScheme(
            primary = def.lightPrimary,
            onPrimary = Color.White,
            primaryContainer = def.lightContainer,
            onPrimaryContainer = Color(0xFF111111),
            secondary = def.lightPrimary,
            onSecondary = Color.White,
            secondaryContainer = def.lightContainer,
            onSecondaryContainer = Color(0xFF111111),
            tertiary = def.lightPrimary,
            background = Color(0xFFFAFAFB),
            onBackground = Color(0xFF1A1B1E),
            surface = Color(0xFFFAFAFB),
            onSurface = Color(0xFF1A1B1E),
            onSurfaceVariant = Color(0xFF55585E),
            surfaceContainerHigh = Color(0xFFE9EAEE),
            outlineVariant = Color(0xFFC9CCD2),
        )
    }

/**
 * @param themeMode 0 = follow system, 1 = light, 2 = dark
 * @param palette index into [PALETTES]
 */
@Composable
fun GallerfixTheme(
    themeMode: Int,
    palette: Int,
    amoled: Boolean,
    content: @Composable () -> Unit,
) {
    val systemDark = isSystemInDarkTheme()
    val dark = when (themeMode) {
        1 -> false
        2 -> true
        else -> systemDark
    }
    val context = LocalContext.current
    val safePalette = palette.coerceIn(0, PALETTES.lastIndex)

    var colors: ColorScheme = if (safePalette == 0 && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        if (dark) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    } else {
        paletteScheme(PALETTES[safePalette], dark)
    }
    if (dark && amoled) {
        colors = colors.copy(
            background = Color.Black,
            surface = Color.Black,
            surfaceContainerHigh = Color(0xFF1A1A1A),
        )
    }

    // Keep status/navigation bar icons readable when the theme differs from the system setting.
    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as? Activity)?.window
            if (window != null) {
                val controller = WindowCompat.getInsetsController(window, view)
                controller.isAppearanceLightStatusBars = !dark
                controller.isAppearanceLightNavigationBars = !dark
            }
        }
    }

    MaterialTheme(colorScheme = colors, content = content)
}
