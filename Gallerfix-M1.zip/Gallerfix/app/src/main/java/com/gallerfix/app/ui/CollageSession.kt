package com.gallerfix.app.ui

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Everything about the collage you are working on, so switching tabs doesn't lose it. */
class CollageSession {
    var step by mutableStateOf(0)
    var picked by mutableStateOf<List<Long>>(emptyList())
    var layoutIndex by mutableStateOf(0)
    var aspectIndex by mutableStateOf(0)
    var gap by mutableFloatStateOf(0.35f)
    var radius by mutableFloatStateOf(0.25f)
    var bgIndex by mutableStateOf(0)
}
