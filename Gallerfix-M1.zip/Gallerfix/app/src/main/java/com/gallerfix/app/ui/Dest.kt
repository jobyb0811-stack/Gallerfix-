package com.gallerfix.app.ui

/** Rail order = ordinal. The last entry (Settings) is pinned to the bottom of the rail. */
enum class Dest(val label: String) {
    Photos("Photos"),
    Videos("Videos"),
    Albums("Albums"),
    Collage("Collage"),
    Settings("Settings"),
}
