package com.gallerfix.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

@Composable
fun HeaderBar(title: String, actions: @Composable RowScope.() -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(start = 16.dp, end = 4.dp, top = 6.dp, bottom = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.headlineSmall,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f),
        )
        actions()
    }
}

@Composable
fun MessageState(
    title: String,
    body: String,
    actions: @Composable ColumnScope.() -> Unit,
) {
    Column(
        modifier = Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically),
    ) {
        Text(title, style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
        Text(body, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center)
        actions()
    }
}

/** What can be done to a group of selected items. Actions left null are not shown. */
class SelectionActions(
    val onSelectAll: () -> Unit,
    val onFavorite: () -> Unit,
    val onUnfavorite: () -> Unit,
    val onShare: () -> Unit,
    val onCancel: () -> Unit,
    val onAlbum: (() -> Unit)? = null,
    val onTrash: (() -> Unit)? = null,
    val onRemove: (() -> Unit)? = null,
)

@Composable
fun SelectionHeader(count: Int, actions: SelectionActions) {
    var menu by remember { mutableStateOf(false) }
    HeaderBar("$count selected") {
        actions.onAlbum?.let { TextButton(onClick = it) { Text("Album") } }
        actions.onTrash?.let { TextButton(onClick = it) { Text("Trash") } }
        actions.onRemove?.let { TextButton(onClick = it) { Text("Remove") } }
        Box {
            TextButton(onClick = { menu = true }) { Text("⋮") }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                DropdownMenuItem(text = { Text("Select all") }, onClick = { menu = false; actions.onSelectAll() })
                DropdownMenuItem(text = { Text("Add to favorites") }, onClick = { menu = false; actions.onFavorite() })
                DropdownMenuItem(text = { Text("Remove from favorites") }, onClick = { menu = false; actions.onUnfavorite() })
                DropdownMenuItem(text = { Text("Share") }, onClick = { menu = false; actions.onShare() })
                DropdownMenuItem(text = { Text("Cancel selection") }, onClick = { menu = false; actions.onCancel() })
            }
        }
    }
}
