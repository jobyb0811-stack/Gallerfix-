package com.gallerfix.app.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.ImageLoader
import coil.compose.AsyncImage
import com.gallerfix.app.data.MediaItem
import com.gallerfix.app.data.SmartAlbum

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun AlbumsScreen(
    albums: List<AlbumUi>,
    imageLoader: ImageLoader,
    tab: Int,
    onTabChange: (Int) -> Unit,
    smart: List<SmartAlbum>,
    locationGranted: Boolean,
    placesProgress: String?,
    onAllowLocation: () -> Unit,
    onOpenSmart: (SmartAlbum) -> Unit,
    onRenamePlace: (SmartAlbum, String) -> Unit,
    onOpen: (AlbumUi) -> Unit,
    onCreate: (String) -> Unit,
    onRename: (AlbumUi, String) -> Unit,
    onDelete: (AlbumUi) -> Unit,
) {
    var creating by remember { mutableStateOf(false) }
    var optionsFor by remember { mutableStateOf<AlbumUi?>(null) }
    var renaming by remember { mutableStateOf<AlbumUi?>(null) }
    var deleting by remember { mutableStateOf<AlbumUi?>(null) }

    Column(Modifier.fillMaxSize()) {
        HeaderBar("Albums") {
            TextButton(onClick = { creating = true }) { Text("New") }
        }
        Row(
            Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            FilterChip(
                selected = tab == 0,
                onClick = { onTabChange(0) },
                label = { Text("My albums") },
            )
            FilterChip(
                selected = tab == 1,
                onClick = { onTabChange(1) },
                label = { Text("Smart") },
            )
        }
        if (tab == 1) {
            SmartAlbumsPane(
                smart = smart,
                imageLoader = imageLoader,
                locationGranted = locationGranted,
                placesProgress = placesProgress,
                onAllowLocation = onAllowLocation,
                onOpen = onOpenSmart,
                onRenamePlace = onRenamePlace,
            )
        } else if (albums.isEmpty()) {
            MessageState(
                title = "No albums yet",
                body = "Tap New to create one. Then long-press photos in Photos or Videos and tap Album to fill it.",
            ) {}
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 140.dp),
                contentPadding = PaddingValues(12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize(),
            ) {
                items(albums, key = { it.id }) { album ->
                    Column(
                        Modifier.combinedClickable(
                            onClick = { onOpen(album) },
                            onLongClick = { optionsFor = album },
                        )
                    ) {
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .aspectRatio(1f)
                                .clip(RoundedCornerShape(16.dp))
                                .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                        ) {
                            val cover = album.items.firstOrNull()
                            if (cover != null) {
                                AsyncImage(
                                    model = cover.uri,
                                    imageLoader = imageLoader,
                                    contentDescription = null,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize(),
                                )
                            } else {
                                Text(
                                    "Empty",
                                    style = MaterialTheme.typography.labelLarge,
                                    modifier = Modifier.align(Alignment.Center),
                                )
                            }
                        }
                        Text(
                            text = album.name,
                            style = MaterialTheme.typography.titleSmall,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(top = 6.dp),
                        )
                        Text(
                            text = "${album.items.size} items",
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }
            }
        }
    }

    if (creating) {
        NameDialog(
            title = "New album",
            initial = "",
            confirmLabel = "Create",
            onConfirm = { onCreate(it); creating = false },
            onDismiss = { creating = false },
        )
    }

    val options = optionsFor
    if (options != null) {
        AlertDialog(
            onDismissRequest = { optionsFor = null },
            title = { Text(options.name) },
            text = { Text("What would you like to do with this album?") },
            confirmButton = {
                TextButton(onClick = { renaming = options; optionsFor = null }) { Text("Rename") }
            },
            dismissButton = {
                TextButton(onClick = { deleting = options; optionsFor = null }) { Text("Delete") }
            },
        )
    }

    val toRename = renaming
    if (toRename != null) {
        NameDialog(
            title = "Rename album",
            initial = toRename.name,
            confirmLabel = "Save",
            onConfirm = { onRename(toRename, it); renaming = null },
            onDismiss = { renaming = null },
        )
    }

    val toDelete = deleting
    if (toDelete != null) {
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Delete album?") },
            text = { Text("Your photos and videos stay on your phone. Only the album \"${toDelete.name}\" is removed.") },
            confirmButton = {
                TextButton(onClick = { onDelete(toDelete); deleting = null }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancel") } },
        )
    }
}

@Composable
fun AlbumDetailScreen(
    album: AlbumUi,
    imageLoader: ImageLoader,
    minSize: Dp,
    selected: List<Long>,
    onBack: () -> Unit,
    onItemClick: (MediaItem) -> Unit,
    onItemLongClick: (MediaItem) -> Unit,
    selection: SelectionActions,
) {
    Column(Modifier.fillMaxSize()) {
        if (selected.isNotEmpty()) {
            SelectionHeader(selected.size, selection)
        } else {
            HeaderBar(album.name) {
                TextButton(onClick = onBack) { Text("Back") }
            }
        }
        if (album.items.isEmpty()) {
            MessageState(
                title = "This album is empty",
                body = "Long-press photos in Photos or Videos and tap Album to add them here.",
            ) {}
        } else {
            MediaGrid(
                items = album.items,
                imageLoader = imageLoader,
                minSize = minSize,
                selectedIds = selected.toSet(),
                onItemClick = onItemClick,
                onItemLongClick = onItemLongClick,
            )
        }
    }
}
