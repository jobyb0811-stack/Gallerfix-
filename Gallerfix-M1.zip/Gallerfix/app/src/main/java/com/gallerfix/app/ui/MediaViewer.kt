package com.gallerfix.app.ui

import android.app.Activity
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import coil.ImageLoader
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.gallerfix.app.data.MediaItem
import kotlinx.coroutines.delay

@Composable
fun MediaViewer(
    items: List<MediaItem>,
    startIndex: Int,
    imageLoader: ImageLoader,
    slideshowSeconds: Int,
    onCurrentChanged: (Long) -> Unit,
    onClose: () -> Unit,
    onAddToAlbum: (MediaItem) -> Unit,
    onTrash: (MediaItem) -> Unit,
    onShare: (MediaItem) -> Unit,
    onToggleFavorite: (MediaItem) -> Unit,
    onDetails: (MediaItem) -> Unit,
) {
    val favorites = LocalFavorites.current
    var chrome by rememberSaveable { mutableStateOf(true) }
    var slideshow by rememberSaveable { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }

    BackHandler { if (slideshow) slideshow = false else onClose() }

    // White status/navigation icons while the black viewer is open.
    val view = LocalView.current
    DisposableEffect(Unit) {
        val window = (view.context as? Activity)?.window
        if (window != null) {
            val controller = WindowCompat.getInsetsController(window, view)
            val prevStatus = controller.isAppearanceLightStatusBars
            val prevNav = controller.isAppearanceLightNavigationBars
            controller.isAppearanceLightStatusBars = false
            controller.isAppearanceLightNavigationBars = false
            onDispose {
                controller.isAppearanceLightStatusBars = prevStatus
                controller.isAppearanceLightNavigationBars = prevNav
            }
        } else {
            onDispose { }
        }
    }

    // Keep the screen on during a slideshow, and hide the controls.
    DisposableEffect(slideshow) {
        view.keepScreenOn = slideshow
        onDispose { view.keepScreenOn = false }
    }
    LaunchedEffect(slideshow) { if (slideshow) chrome = false }

    val pagerState = rememberPagerState(
        initialPage = startIndex.coerceAtLeast(0),
        pageCount = { items.size },
    )

    LaunchedEffect(pagerState.settledPage) {
        items.getOrNull(pagerState.settledPage)?.let { onCurrentChanged(it.id) }
    }

    LaunchedEffect(slideshow, pagerState.settledPage) {
        if (slideshow) {
            val item = items.getOrNull(pagerState.settledPage)
            val wait = if (item?.isVideo == true) maxOf(slideshowSeconds * 1000L, 6000L) else slideshowSeconds * 1000L
            delay(wait)
            val next = pagerState.settledPage + 1
            if (next < items.size) pagerState.animateScrollToPage(next) else slideshow = false
        }
    }

    val current = items.getOrNull(pagerState.currentPage)

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .pointerInput(Unit) { }
    ) {
        HorizontalPager(
            state = pagerState,
            key = { items[it].id },
            pageSpacing = 8.dp,
            modifier = Modifier.fillMaxSize(),
        ) { page ->
            val item = items[page]
            if (item.isVideo) {
                if (page == pagerState.currentPage) {
                    VideoPlayer(
                        uri = item.uri,
                        key = item.id,
                        controlsVisible = chrome,
                        onToggleControls = { chrome = !chrome },
                    )
                } else {
                    AsyncImage(
                        model = item.uri,
                        imageLoader = imageLoader,
                        contentDescription = null,
                        contentScale = ContentScale.Fit,
                        modifier = Modifier.fillMaxSize(),
                    )
                }
            } else {
                ZoomableImage(item, imageLoader) { chrome = !chrome }
            }
        }

        if (chrome) {
            Row(
                Modifier
                    .align(Alignment.TopStart)
                    .fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.6f), Color.Transparent)))
                    .statusBarsPadding()
                    .padding(horizontal = 4.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = onClose) { BackIcon(Color.White) }
                Text(
                    "${pagerState.currentPage + 1}/${items.size}",
                    color = Color.White,
                    style = MaterialTheme.typography.labelMedium,
                )
                Spacer(Modifier.weight(1f))
                val isFavorite = current != null && current.id in favorites
                val tight = PaddingValues(horizontal = 10.dp)
                TextButton(onClick = { current?.let(onToggleFavorite) }, contentPadding = tight) {
                    Text(
                        if (isFavorite) "★" else "☆",
                        color = if (isFavorite) Color(0xFFFFD166) else Color.White,
                    )
                }
                TextButton(onClick = { current?.let(onShare) }, contentPadding = tight) {
                    Text("Share", color = Color.White)
                }
                TextButton(onClick = { current?.let(onTrash) }, contentPadding = tight) {
                    Text("Trash", color = Color.White)
                }
                Box {
                    TextButton(onClick = { menu = true }, contentPadding = tight) {
                        Text("⋮", color = Color.White)
                    }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(
                            text = { Text("Details") },
                            onClick = {
                                menu = false
                                current?.let(onDetails)
                            },
                        )
                        DropdownMenuItem(
                            text = { Text("Add to album") },
                            onClick = {
                                menu = false
                                current?.let(onAddToAlbum)
                            },
                        )
                        DropdownMenuItem(
                            text = { Text(if (slideshow) "Stop slideshow" else "Start slideshow") },
                            onClick = {
                                menu = false
                                slideshow = !slideshow
                            },
                        )
                    }
                }
            }
        }
    }
}

/** Photos load at up to 4096 px so deep zoom stays sharp, and zoom is effectively unlimited. */
@Composable
private fun ZoomableImage(item: MediaItem, imageLoader: ImageLoader, onTap: () -> Unit) {
    val context = LocalContext.current
    val request = remember(item.id) {
        ImageRequest.Builder(context)
            .data(item.uri)
            .size(4096, 4096)
            .build()
    }
    ZoomBox(onTap = onTap) {
        AsyncImage(
            model = request,
            imageLoader = imageLoader,
            contentDescription = null,
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxSize(),
        )
    }
}
