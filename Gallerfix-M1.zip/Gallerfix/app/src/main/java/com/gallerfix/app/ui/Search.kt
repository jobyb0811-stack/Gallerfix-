package com.gallerfix.app.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.ImageLoader
import com.gallerfix.app.data.MediaItem

/** Search by name, folder, year, month ("march"), or type ("video", "photo", "sd"). Stays on your phone. */
@Composable
fun SearchScreen(
    query: String,
    onQueryChange: (String) -> Unit,
    results: List<MediaItem>,
    imageLoader: ImageLoader,
    minSize: Dp,
    selected: List<Long>,
    onItemClick: (MediaItem) -> Unit,
    onItemLongClick: (MediaItem) -> Unit,
    selection: SelectionActions,
    onClose: () -> Unit,
) {
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        if (query.isEmpty()) {
            try {
                focus.requestFocus()
            } catch (e: Exception) {
                // not ready yet; the user can tap the field
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        if (selected.isNotEmpty()) {
            SelectionHeader(selected.size, selection)
        } else {
            HeaderBar("Search") {
                TextButton(onClick = onClose) { Text("Close") }
            }
        }
        OutlinedTextField(
            value = query,
            onValueChange = onQueryChange,
            singleLine = true,
            placeholder = { Text("Name, folder, year, month, video…") },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .focusRequester(focus),
        )
        Text(
            text = when {
                query.isBlank() -> "Try “screenshot”, “2024”, “march”, “video” or a folder name. Words can be combined."
                results.isEmpty() -> "No matches."
                else -> "${results.size} found"
            },
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
        )
        if (results.isNotEmpty()) {
            MediaGrid(
                items = results,
                imageLoader = imageLoader,
                minSize = minSize,
                selectedIds = selected.toSet(),
                onItemClick = onItemClick,
                onItemLongClick = onItemLongClick,
            )
        }
    }
}
