package com.gallerfix.app.ui

import android.net.Uri
import android.view.LayoutInflater
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.MediaItem as ExoMediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.gallerfix.app.R
import kotlinx.coroutines.delay

private val SPEEDS = listOf(1f, 1.5f, 2f, 0.5f)

/**
 * Plays [uri]. You can pinch-zoom and pan while it plays (it is drawn on a texture so it
 * transforms smoothly). Play, seek and speed live outside the zoomed layer so they stay put.
 */
@Composable
fun VideoPlayer(
    uri: Uri,
    key: Any,
    controlsVisible: Boolean,
    onToggleControls: () -> Unit,
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val exo = remember(key) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(ExoMediaItem.fromUri(uri))
            prepare()
            playWhenReady = true
        }
    }

    var isPlaying by remember { mutableStateOf(true) }
    var position by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(0L) }
    var dragging by remember { mutableStateOf(false) }
    var dragFraction by remember { mutableFloatStateOf(0f) }
    var speedIndex by remember { mutableStateOf(0) }

    DisposableEffect(exo, lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_PAUSE) exo.pause()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
            exo.release()
        }
    }

    LaunchedEffect(exo) {
        while (true) {
            isPlaying = exo.isPlaying
            position = exo.currentPosition
            duration = exo.duration.coerceAtLeast(0L)
            delay(200)
        }
    }

    Box(Modifier.fillMaxSize()) {
        ZoomBox(onTap = onToggleControls) {
            AndroidView(
                factory = { ctx ->
                    (LayoutInflater.from(ctx).inflate(R.layout.view_player_texture, null, false) as PlayerView)
                        .also { it.player = exo }
                },
                update = { it.player = exo },
                modifier = Modifier.fillMaxSize(),
            )
        }

        if (controlsVisible) {
            Column(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.65f))))
                    .navigationBarsPadding()
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                val fraction = if (dragging) {
                    dragFraction
                } else if (duration > 0L) {
                    (position.toFloat() / duration).coerceIn(0f, 1f)
                } else {
                    0f
                }
                Slider(
                    value = fraction,
                    onValueChange = {
                        dragging = true
                        dragFraction = it
                    },
                    onValueChangeFinished = {
                        exo.seekTo((dragFraction * duration).toLong())
                        dragging = false
                    },
                    valueRange = 0f..1f,
                )
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    TextButton(onClick = {
                        if (exo.isPlaying) {
                            exo.pause()
                        } else {
                            if (exo.playbackState == Player.STATE_ENDED) exo.seekTo(0)
                            exo.play()
                        }
                    }) { Text(if (isPlaying) "Pause" else "Play", color = Color.White) }
                    Text(
                        "${formatClock(if (dragging) (dragFraction * duration).toLong() else position)} / ${formatClock(duration)}",
                        color = Color.White,
                    )
                    TextButton(onClick = {
                        speedIndex = (speedIndex + 1) % SPEEDS.size
                        exo.setPlaybackSpeed(SPEEDS[speedIndex])
                    }) { Text("${SPEEDS[speedIndex]}x", color = Color.White) }
                }
            }
        }
    }
}

private fun formatClock(ms: Long): String {
    val total = ms / 1000
    val h = total / 3600
    val m = (total % 3600) / 60
    val s = total % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
}
