package com.gallerfix.app.ui

import android.content.Intent
import android.os.SystemClock
import android.provider.Settings
import androidx.biometric.BiometricManager
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.gallerfix.app.LockSpec
import kotlinx.coroutines.delay

/**
 * Shown instead of the gallery while locked. Nothing on screen hints at the secret taps:
 * tap anywhere the chosen number of times, then pause.
 */
@Composable
fun LockScreen(
    biometricEnabled: Boolean,
    tapsEnabled: Boolean,
    tapTarget: Int,
    onUnlock: () -> Unit,
    onDisableLock: () -> Unit,
) {
    val context = LocalContext.current
    val activity = context.findFragmentActivity()
    val currentTapsEnabled by rememberUpdatedState(tapsEnabled)
    val currentTarget by rememberUpdatedState(tapTarget)

    var availability by remember { mutableStateOf(BiometricAuth.availability(context)) }
    var prompting by remember { mutableStateOf(false) }
    var tapCount by remember { mutableStateOf(0) }
    var failures by remember { mutableStateOf(0) }
    var lockedUntil by remember { mutableStateOf(0L) }

    fun promptBiometric() {
        if (activity == null || prompting) return
        availability = BiometricAuth.availability(context)
        prompting = true
        BiometricAuth.authenticate(
            activity = activity,
            title = "Unlock Gallerfix",
            onUnavailable = { prompting = false },
        ) { ok ->
            prompting = false
            if (ok) onUnlock()
        }
    }

    // First method: fingerprint / face (whichever the phone offers), straight away.
    LaunchedEffect(Unit) {
        if (biometricEnabled) {
            delay(250)
            promptBiometric()
        }
    }

    // Second method: the secret tap code. Wait for a pause, then check the count.
    LaunchedEffect(tapCount) {
        if (tapCount > 0) {
            delay(LockSpec.TAP_PAUSE_MS)
            val count = tapCount
            tapCount = 0
            if (currentTapsEnabled && count == currentTarget) {
                failures = 0
                onUnlock()
            } else {
                failures++
                if (failures >= LockSpec.MAX_FAILURES) {
                    failures = 0
                    lockedUntil = SystemClock.elapsedRealtime() + LockSpec.LOCKOUT_MS
                }
            }
        }
    }

    val noDeviceSecurity = availability == BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED ||
        availability == BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE

    Surface(modifier = Modifier.fillMaxSize()) {
        Box(
            Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures(
                        onTap = {
                            if (currentTapsEnabled && SystemClock.elapsedRealtime() >= lockedUntil) {
                                tapCount++
                            }
                        }
                    )
                }
        ) {
            Column(
                Modifier.align(Alignment.Center).padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Text(
                    "Gallerfix",
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                )
                if (biometricEnabled && noDeviceSecurity) {
                    Text(
                        "This phone has no fingerprint, face or screen lock set up. Set one up in Settings to unlock with it.",
                        style = MaterialTheme.typography.bodyMedium,
                        textAlign = TextAlign.Center,
                    )
                    OutlinedButton(onClick = {
                        context.startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS))
                    }) { Text("Open security settings") }
                    if (!tapsEnabled) {
                        TextButton(onClick = onDisableLock) { Text("Turn off app lock") }
                    }
                }
            }
            if (biometricEnabled && !noDeviceSecurity) {
                TextButton(
                    onClick = { promptBiometric() },
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .navigationBarsPadding()
                        .padding(bottom = 24.dp),
                ) {
                    Text(
                        "Use fingerprint, face or screen lock",
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f),
                    )
                }
            }
        }
    }
}
