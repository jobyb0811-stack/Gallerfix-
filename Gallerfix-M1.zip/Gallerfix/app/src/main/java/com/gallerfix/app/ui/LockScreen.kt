package com.gallerfix.app.ui

import android.content.Intent
import android.os.SystemClock
import android.provider.Settings
import androidx.biometric.BiometricManager
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.gallerfix.app.LockSpec
import kotlinx.coroutines.delay

private enum class LockStep { Fingerprint, Face, Taps }

/**
 * Shown instead of the gallery while locked.
 *
 * sequential = true : every enabled step must pass, in order: fingerprint, then face, then the secret
 *                     taps. A wrong tap code sends you back to step 1.
 * sequential = false: any one enabled method is enough.
 *
 * Nothing on screen hints at the secret taps: tap anywhere the chosen number of times, then pause.
 */
@Composable
fun LockScreen(
    sequential: Boolean,
    useFingerprint: Boolean,
    useFace: Boolean,
    tapsEnabled: Boolean,
    tapTarget: Int,
    recoveryEnabled: Boolean,
    onUnlock: () -> Unit,
    onDisableLock: () -> Unit,
) {
    val context = LocalContext.current
    val activity = context.findFragmentActivity()
    val currentTarget by rememberUpdatedState(tapTarget)

    val steps = remember(sequential, useFingerprint, useFace, tapsEnabled) {
        if (!sequential) {
            emptyList<LockStep>()
        } else {
            buildList {
                if (useFingerprint) add(LockStep.Fingerprint)
                if (useFace) add(LockStep.Face)
                if (tapsEnabled) add(LockStep.Taps)
            }
        }
    }
    var stepIndex by rememberSaveable { mutableStateOf(0) }
    val current: LockStep? = if (sequential) steps.getOrNull(stepIndex) else null

    val anyBiometric = useFingerprint || useFace
    val tapsActive = tapsEnabled && (!sequential || current == LockStep.Taps)
    val currentTapsActive by rememberUpdatedState(tapsActive)

    var prompting by remember { mutableStateOf(false) }
    var tapCount by remember { mutableStateOf(0) }
    var failures by remember { mutableStateOf(0) }
    var lockedUntil by remember { mutableStateOf(0L) }

    fun advance() {
        if (stepIndex + 1 >= steps.size) onUnlock() else stepIndex += 1
    }

    fun authenticatorsFor(step: LockStep?): Int = when (step) {
        LockStep.Fingerprint -> BiometricAuth.FINGERPRINT_STEP
        LockStep.Face -> BiometricAuth.FACE_STEP
        else -> BiometricAuth.ANY
    }

    var availability by remember {
        mutableStateOf(BiometricAuth.availability(context, authenticatorsFor(current)))
    }

    fun promptBiometric() {
        if (activity == null || prompting) return
        val step = current
        availability = BiometricAuth.availability(context, authenticatorsFor(step))
        prompting = true
        BiometricAuth.authenticate(
            activity = activity,
            title = when (step) {
                LockStep.Fingerprint -> "Step 1 · Fingerprint"
                LockStep.Face -> "Step 2 · Face"
                else -> "Unlock Gallerfix"
            },
            authenticators = authenticatorsFor(step),
            onUnavailable = { prompting = false },
        ) { ok ->
            prompting = false
            if (ok) {
                if (sequential) advance() else onUnlock()
            }
        }
    }

    // A misconfigured lock with no steps must never lock you out.
    LaunchedEffect(sequential, steps) {
        if (sequential && steps.isEmpty()) onUnlock()
    }

    // Start each biometric step automatically.
    LaunchedEffect(stepIndex, sequential) {
        val wantsPrompt = if (sequential) {
            current == LockStep.Fingerprint || current == LockStep.Face
        } else {
            anyBiometric
        }
        if (wantsPrompt) {
            delay(300)
            promptBiometric()
        }
    }

    // The secret taps: wait for a pause, then check the count.
    LaunchedEffect(tapCount) {
        if (tapCount > 0) {
            delay(LockSpec.TAP_PAUSE_MS)
            val count = tapCount
            tapCount = 0
            if (currentTapsActive && count == currentTarget) {
                failures = 0
                if (sequential) advance() else onUnlock()
            } else {
                failures++
                if (sequential) stepIndex = 0 // wrong code: start again from step 1
                if (failures >= LockSpec.MAX_FAILURES) {
                    failures = 0
                    lockedUntil = SystemClock.elapsedRealtime() + LockSpec.LOCKOUT_MS
                }
            }
        }
    }

    val onBiometricStep = if (sequential) {
        current == LockStep.Fingerprint || current == LockStep.Face
    } else {
        anyBiometric
    }
    val noDeviceSecurity = onBiometricStep && (
        availability == BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED ||
            availability == BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE
        )

    Surface(modifier = Modifier.fillMaxSize()) {
        Box(
            Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    detectTapGestures(
                        onTap = {
                            if (currentTapsActive && SystemClock.elapsedRealtime() >= lockedUntil) {
                                tapCount++
                            }
                        }
                    )
                }
        ) {
            Column(
                Modifier.align(Alignment.Center).padding(32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Text(
                    "Gallerfix",
                    style = MaterialTheme.typography.headlineMedium,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                )
                if (sequential && onBiometricStep) {
                    Text(
                        "Step ${stepIndex + 1}",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                    )
                }
                if (noDeviceSecurity) {
                    Text(
                        "This phone has no fingerprint, face or screen lock set up for this step. Set one up in Settings.",
                        style = MaterialTheme.typography.bodyMedium,
                        textAlign = TextAlign.Center,
                    )
                    OutlinedButton(onClick = {
                        context.startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS))
                    }) { Text("Open security settings") }
                    if (!tapsEnabled) {
                        TextButton(onClick = onDisableLock) { Text("Turn off app lock") }
                    }
                }
            }

            if (onBiometricStep && !noDeviceSecurity) {
                TextButton(
                    onClick = { promptBiometric() },
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .navigationBarsPadding()
                        .padding(bottom = 24.dp),
                ) {
                    Text(
                        when (current) {
                            LockStep.Fingerprint -> "Use fingerprint"
                            LockStep.Face -> "Use face"
                            else -> "Use fingerprint, face or screen lock"
                        },
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f),
                    )
                }
            }

            // Backup for a forgotten tap code. Only appears on the tap step, and only if allowed.
            if (sequential && current == LockStep.Taps && recoveryEnabled) {
                TextButton(
                    onClick = {
                        if (activity != null) {
                            BiometricAuth.authenticate(
                                activity = activity,
                                title = "Use your screen lock",
                                authenticators = BiometricAuth.SCREEN_LOCK_ONLY,
                            ) { ok -> if (ok) onUnlock() }
                        }
                    },
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .navigationBarsPadding()
                        .padding(bottom = 24.dp),
                ) {
                    Text(
                        "Use screen lock instead",
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.3f),
                    )
                }
            }
        }
    }
}
