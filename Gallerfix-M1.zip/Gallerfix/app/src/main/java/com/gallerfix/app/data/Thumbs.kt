package com.gallerfix.app.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.BitmapDrawable
import android.net.Uri
import android.util.Size
import coil.ImageLoader
import coil.decode.DataSource
import coil.fetch.DrawableResult
import coil.fetch.FetchResult
import coil.fetch.Fetcher
import coil.key.Keyer
import coil.request.Options
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext

/** Grid, album and table pictures. */
const val GRID_THUMB = 384

/** The big pictures of the dial's ring. */
const val DIAL_THUMB = 512

/** Ask for a small picture of [uri] about [px] wide, from Android's own thumbnail cache. */
data class MediaThumb(val uri: Uri, val px: Int)

private fun loadSmall(context: Context, uri: Uri, px: Int): Bitmap? {
    try {
        // Android keeps ready-made thumbnails for every photo and video, so this is far quicker
        // than opening and shrinking the full-size file.
        return context.contentResolver.loadThumbnail(uri, Size(px, px), null)
    } catch (e: Exception) {
        // fall through to the slow way
    }
    return try {
        context.contentResolver.openInputStream(uri)?.use { stream ->
            val options = BitmapFactory.Options().apply { inSampleSize = 4 }
            BitmapFactory.decodeStream(stream, null, options)
        }
    } catch (e: Exception) {
        null
    }
}

class ThumbFetcher(private val data: MediaThumb, private val options: Options) : Fetcher {
    override suspend fun fetch(): FetchResult? {
        val bitmap = withContext(Dispatchers.IO) { loadSmall(options.context, data.uri, data.px) } ?: return null
        return DrawableResult(
            drawable = BitmapDrawable(options.context.resources, bitmap),
            isSampled = true,
            dataSource = DataSource.DISK,
        )
    }

    class Factory : Fetcher.Factory<MediaThumb> {
        override fun create(data: MediaThumb, options: Options, imageLoader: ImageLoader): Fetcher =
            ThumbFetcher(data, options)
    }
}

/** Lets Coil remember these pictures in memory. */
class ThumbKeyer : Keyer<MediaThumb> {
    override fun key(data: MediaThumb, options: Options): String = "thumb:${data.uri}:${data.px}"
}

/**
 * Asks Android to prepare a thumbnail for every photo and video once, so scrolling and spinning the
 * dial never wait. Slow the first time only. Later runs only look at newer items.
 */
class ThumbnailWarmer(private val context: Context, private val settings: SettingsStore) {

    suspend fun warm(items: List<MediaItem>, onProgress: (done: Int, total: Int) -> Unit) =
        withContext(Dispatchers.IO) {
            val mark = settings.warmedUpTo
            val todo = items.filter { it.dateAddedSeconds > mark }
            if (todo.isEmpty()) return@withContext
            var done = 0
            for (batch in todo.chunked(4)) {
                ensureActive()
                coroutineScope {
                    batch.map { item ->
                        async { loadSmall(context, item.uri, DIAL_THUMB) }
                    }.awaitAll()
                }
                done += batch.size
                if (done % 40 == 0 || done == todo.size) onProgress(done, todo.size)
                delay(4) // leave room for the screen
            }
            settings.warmedUpTo = items.maxOf { it.dateAddedSeconds }
        }
}
