package com.gallerfix.app.data

import android.content.ContentResolver
import android.content.ContentUris
import android.content.Context
import android.database.ContentObserver
import android.database.Cursor
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.BaseColumns
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.conflate
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext

enum class MediaKind { PHOTOS, VIDEOS }

class MediaRepository(private val context: Context) {

    /** Live list of non-trashed media of one kind. */
    fun observe(kind: MediaKind, includeSd: Boolean): Flow<List<MediaItem>> =
        changes(collectionFor(kind))
            .conflate()
            .map { query(kind, trashed = false, includeSd = includeSd) }
            .flowOn(Dispatchers.IO)

    /** Live list of trashed photos and videos. */
    fun observeTrash(includeSd: Boolean): Flow<List<MediaItem>> =
        changes(collectionFor(MediaKind.PHOTOS), collectionFor(MediaKind.VIDEOS))
            .conflate()
            .map {
                (query(MediaKind.PHOTOS, trashed = true, includeSd = includeSd) +
                    query(MediaKind.VIDEOS, trashed = true, includeSd = includeSd))
                    .sortedByDescending { it.dateAddedSeconds }
            }
            .flowOn(Dispatchers.IO)

    /** Extra facts about one item, read on demand. */
    suspend fun details(item: MediaItem): MediaDetails = withContext(Dispatchers.IO) {
        var width = 0
        var height = 0
        var mime = ""
        var size = item.sizeBytes
        var path = item.relativePath
        try {
            context.contentResolver.query(
                item.uri,
                arrayOf(
                    MediaStore.MediaColumns.WIDTH,
                    MediaStore.MediaColumns.HEIGHT,
                    MediaStore.MediaColumns.MIME_TYPE,
                    MediaStore.MediaColumns.SIZE,
                    MediaStore.MediaColumns.RELATIVE_PATH,
                ),
                null, null, null,
            )?.use { c ->
                if (c.moveToFirst()) {
                    width = c.getInt(0)
                    height = c.getInt(1)
                    mime = c.getString(2) ?: ""
                    size = c.getLong(3)
                    path = c.getString(4) ?: path
                }
            }
        } catch (e: Exception) {
            // keep what we already know
        }
        MediaDetails(
            name = item.displayName,
            mime = mime,
            sizeBytes = size,
            width = width,
            height = height,
            takenMs = item.takenMs,
            path = path,
            onSd = item.isSd,
            isVideo = item.isVideo,
            durationMs = item.durationMs,
        )
    }

    private fun changes(vararg uris: Uri): Flow<Unit> = callbackFlow<Unit> {
        val observer = object : ContentObserver(Handler(Looper.getMainLooper())) {
            override fun onChange(selfChange: Boolean) {
                trySend(Unit)
            }
        }
        for (uri in uris) {
            context.contentResolver.registerContentObserver(uri, true, observer)
        }
        trySend(Unit)
        awaitClose { context.contentResolver.unregisterContentObserver(observer) }
    }

    private fun collectionFor(kind: MediaKind): Uri = when (kind) {
        MediaKind.PHOTOS -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        MediaKind.VIDEOS -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
    }

    private fun query(kind: MediaKind, trashed: Boolean, includeSd: Boolean): List<MediaItem> {
        val collection = collectionFor(kind)
        val isVideo = kind == MediaKind.VIDEOS
        val projection = if (isVideo) {
            arrayOf(
                BaseColumns._ID,
                MediaStore.MediaColumns.DISPLAY_NAME,
                MediaStore.MediaColumns.DATE_ADDED,
                MediaStore.MediaColumns.VOLUME_NAME,
                MediaStore.MediaColumns.SIZE,
                MediaStore.MediaColumns.BUCKET_DISPLAY_NAME,
                MediaStore.MediaColumns.RELATIVE_PATH,
                MediaStore.MediaColumns.DATE_TAKEN,
                MediaStore.MediaColumns.DURATION,
            )
        } else {
            arrayOf(
                BaseColumns._ID,
                MediaStore.MediaColumns.DISPLAY_NAME,
                MediaStore.MediaColumns.DATE_ADDED,
                MediaStore.MediaColumns.VOLUME_NAME,
                MediaStore.MediaColumns.SIZE,
                MediaStore.MediaColumns.BUCKET_DISPLAY_NAME,
                MediaStore.MediaColumns.RELATIVE_PATH,
                MediaStore.MediaColumns.DATE_TAKEN,
            )
        }
        val sort = "${MediaStore.MediaColumns.DATE_ADDED} DESC"
        val result = ArrayList<MediaItem>()
        try {
            val cursor: Cursor? = if (trashed) {
                val args = Bundle().apply {
                    putInt(MediaStore.QUERY_ARG_MATCH_TRASHED, MediaStore.MATCH_ONLY)
                    putString(ContentResolver.QUERY_ARG_SQL_SORT_ORDER, sort)
                }
                context.contentResolver.query(collection, projection, args, null)
            } else {
                context.contentResolver.query(collection, projection, null, null, sort)
            }
            cursor?.use { c ->
                val idCol = c.getColumnIndexOrThrow(BaseColumns._ID)
                val nameCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                val dateCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)
                val volCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns.VOLUME_NAME)
                val sizeCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE)
                val bucketCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns.BUCKET_DISPLAY_NAME)
                val pathCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns.RELATIVE_PATH)
                val takenCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_TAKEN)
                val durCol = if (isVideo) {
                    c.getColumnIndexOrThrow(MediaStore.MediaColumns.DURATION)
                } else {
                    -1
                }
                while (c.moveToNext()) {
                    val isSd = (c.getString(volCol) ?: MediaStore.VOLUME_EXTERNAL_PRIMARY) !=
                        MediaStore.VOLUME_EXTERNAL_PRIMARY
                    if (isSd && !includeSd) continue
                    val id = c.getLong(idCol)
                    result.add(
                        MediaItem(
                            id = id,
                            uri = ContentUris.withAppendedId(collection, id),
                            displayName = c.getString(nameCol) ?: "",
                            dateAddedSeconds = c.getLong(dateCol),
                            isVideo = isVideo,
                            durationMs = if (durCol >= 0) c.getLong(durCol) else 0L,
                            isSd = isSd,
                            sizeBytes = c.getLong(sizeCol),
                            takenMs = c.getLong(takenCol).let { taken ->
                                if (taken > 0L) taken else c.getLong(dateCol) * 1000L
                            },
                            bucket = c.getString(bucketCol) ?: "",
                            relativePath = c.getString(pathCol) ?: "",
                        )
                    )
                }
            }
        } catch (e: SecurityException) {
            // Permission revoked while running: show nothing; UI re-checks on resume.
        }
        return result
    }
}
