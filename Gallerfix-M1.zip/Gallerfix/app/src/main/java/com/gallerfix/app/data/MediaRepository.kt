package com.gallerfix.app.data

import android.content.ContentUris
import android.content.Context
import android.database.ContentObserver
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.BaseColumns
import android.provider.MediaStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.conflate
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map

enum class MediaKind { PHOTOS, VIDEOS }

class MediaRepository(private val context: Context) {

    /**
     * Emits the list now and again whenever MediaStore changes
     * (e.g. an item deleted or added by another app).
     */
    fun observe(kind: MediaKind): Flow<List<MediaItem>> = callbackFlow<Unit> {
        val observer = object : ContentObserver(Handler(Looper.getMainLooper())) {
            override fun onChange(selfChange: Boolean) {
                trySend(Unit)
            }
        }
        context.contentResolver.registerContentObserver(collectionFor(kind), true, observer)
        trySend(Unit)
        awaitClose { context.contentResolver.unregisterContentObserver(observer) }
    }
        .conflate()
        .map { query(kind) }
        .flowOn(Dispatchers.IO)

    private fun collectionFor(kind: MediaKind): Uri = when (kind) {
        MediaKind.PHOTOS -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        MediaKind.VIDEOS -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
    }

    private fun query(kind: MediaKind): List<MediaItem> {
        val collection = collectionFor(kind)
        val isVideo = kind == MediaKind.VIDEOS
        val projection = if (isVideo) {
            arrayOf(
                BaseColumns._ID,
                MediaStore.MediaColumns.DISPLAY_NAME,
                MediaStore.MediaColumns.DATE_ADDED,
                MediaStore.MediaColumns.DURATION,
            )
        } else {
            arrayOf(
                BaseColumns._ID,
                MediaStore.MediaColumns.DISPLAY_NAME,
                MediaStore.MediaColumns.DATE_ADDED,
            )
        }
        val sort = "${MediaStore.MediaColumns.DATE_ADDED} DESC"
        val result = ArrayList<MediaItem>()
        try {
            context.contentResolver.query(collection, projection, null, null, sort)?.use { c ->
                val idCol = c.getColumnIndexOrThrow(BaseColumns._ID)
                val nameCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DISPLAY_NAME)
                val dateCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns.DATE_ADDED)
                val durCol = if (isVideo) {
                    c.getColumnIndexOrThrow(MediaStore.MediaColumns.DURATION)
                } else {
                    -1
                }
                while (c.moveToNext()) {
                    val id = c.getLong(idCol)
                    result.add(
                        MediaItem(
                            id = id,
                            uri = ContentUris.withAppendedId(collection, id),
                            displayName = c.getString(nameCol) ?: "",
                            dateAddedSeconds = c.getLong(dateCol),
                            isVideo = isVideo,
                            durationMs = if (durCol >= 0) c.getLong(durCol) else 0L,
                        )
                    )
                }
            }
        } catch (e: SecurityException) {
            // Permission revoked while running: show nothing; UI re-checks on resume.
        }
        return result
    }
}
