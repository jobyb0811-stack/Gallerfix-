package com.gallerfix.app.ui

import android.app.Activity
import android.content.Intent
import android.content.IntentSender
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.ImageLoader
import coil.decode.VideoFrameDecoder
import com.gallerfix.app.data.MediaItem
import com.gallerfix.app.data.MediaPermissions
import com.gallerfix.app.data.MediaRequests

private const val SUB_NONE = 0
private const val SUB_SORT = 1
private const val SUB_TRASH = 2
private const val SUB_ALBUM = 3

@Composable
fun GalleryApp(viewModel: GalleryViewModel) {
    val context = LocalContext.current
    val photos by viewModel.photos.collectAsStateWithLifecycle()
    val videos by viewModel.videos.collectAsStateWithLifecycle()
    val trash by viewModel.trash.collectAsStateWithLifecycle()
    val albums by viewModel.albums.collectAsStateWithLifecycle()
    val triage by viewModel.triage.collectAsStateWithLifecycle()
    val canUndo by viewModel.canUndo.collectAsStateWithLifecycle()
    val railOnRight by viewModel.railOnRight.collectAsStateWithLifecycle()
    val thumbSize by viewModel.thumbSize.collectAsStateWithLifecycle()

    // Survive rotation / process death
    var destIndex by rememberSaveable { mutableStateOf(0) }
    var subScreen by rememberSaveable { mutableStateOf(SUB_NONE) }
    var albumOpenId by rememberSaveable { mutableStateOf(0L) }
    var viewerId by rememberSaveable { mutableStateOf<Long?>(null) }
    var selected by rememberSaveable { mutableStateOf<List<Long>>(emptyList()) }
    var trashSelected by rememberSaveable { mutableStateOf<List<Long>>(emptyList()) }
    var addTarget by remember { mutableStateOf<List<MediaItem>?>(null) }

    val dest = Dest.entries[destIndex]
    val photoItems = (photos as? GalleryState.Content)?.items ?: emptyList()
    val videoItems = (videos as? GalleryState.Content)?.items ?: emptyList()
    val currentAlbum = albums.firstOrNull { it.id == albumOpenId }
    val albumItems = currentAlbum?.items ?: emptyList()
    val thumbMin: Dp = when (thumbSize) {
        0 -> 80.dp
        2 -> 160.dp
        else -> 110.dp
    }

    // If the open album vanished (deleted), go back to the album list.
    SideEffect {
        if (subScreen == SUB_ALBUM && currentAlbum == null) subScreen = SUB_NONE
    }

    val imageLoader = remember(context) {
        ImageLoader.Builder(context)
            .components { add(VideoFrameDecoder.Factory()) }
            .build()
    }

    // ---- permissions ----
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { viewModel.refreshPermission() }

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) viewModel.refreshPermission()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val onGrant: () -> Unit = { permissionLauncher.launch(MediaPermissions.required()) }
    val onOpenSettings: () -> Unit = {
        context.startActivity(
            Intent(
                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.fromParts("package", context.packageName, null)
            )
        )
    }

    // ---- system trash / delete dialogs ----
    // If the user cancels the system dialog, nothing runs and nothing changes.
    var pendingOk by remember { mutableStateOf<(() -> Unit)?>(null) }
    val requestLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) pendingOk?.invoke()
        pendingOk = null
    }

    fun launchRequest(sender: IntentSender, onOk: () -> Unit) {
        pendingOk = onOk
        try {
            requestLauncher.launch(IntentSenderRequest.Builder(sender).build())
        } catch (e: Exception) {
            pendingOk = null
        }
    }

    fun trashItems(items: List<MediaItem>) {
        if (items.isEmpty()) return
        launchRequest(MediaRequests.trash(context, items, true)) {
            selected = emptyList()
        }
    }

    // ---- selection helpers ----
    fun toggle(list: List<Long>, id: Long): List<Long> =
        if (id in list) list - id else list + id

    val gridItems = if (dest == Dest.Videos) videoItems else photoItems
    val selectedSet = selected.toSet()
    val selectedItems = gridItems.filter { it.id in selectedSet }

    // ---- back handling (viewer handles its own, and wins) ----
    BackHandler(enabled = subScreen != SUB_NONE) {
        subScreen = SUB_NONE
        trashSelected = emptyList()
        selected = emptyList()
    }
    BackHandler(enabled = selected.isNotEmpty()) { selected = emptyList() }

    val mediaHeader: @Composable () -> Unit = {
        if (selected.isNotEmpty()) {
            HeaderBar("${selected.size} selected") {
                TextButton(onClick = { addTarget = selectedItems }) { Text("Album") }
                TextButton(onClick = { trashItems(selectedItems) }) { Text("Trash") }
                TextButton(onClick = { selected = emptyList() }) { Text("Cancel") }
            }
        } else {
            HeaderBar(dest.label) {
                TextButton(onClick = { subScreen = SUB_SORT }) { Text("Sort") }
                TextButton(onClick = { subScreen = SUB_TRASH }) { Text("Trash") }
            }
        }
    }

    Surface(modifier = Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize()) {

            // Main layer: content + rail. Content never sits under the rail.
            Box(Modifier.fillMaxSize().systemBarsPadding()) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .padding(
                            start = if (railOnRight) 0.dp else RailSpec.CollapsedWidth,
                            end = if (railOnRight) RailSpec.CollapsedWidth else 0.dp,
                        )
                ) {
                    when {
                        subScreen == SUB_SORT -> TriageScreen(
                            state = triage,
                            canUndo = canUndo,
                            imageLoader = imageLoader,
                            onDecide = { item, toTrash -> viewModel.decide(item, toTrash) },
                            onUndo = { viewModel.undo() },
                            onReview = {
                                val batch = triage.queued.take(TRASH_BATCH)
                                if (batch.isNotEmpty()) {
                                    launchRequest(MediaRequests.trash(context, batch, true)) {
                                        viewModel.onTrashed(batch)
                                    }
                                }
                            },
                            onClearQueue = { viewModel.clearTrashQueue() },
                            onDone = { subScreen = SUB_NONE },
                        )

                        subScreen == SUB_TRASH -> TrashScreen(
                            state = trash,
                            imageLoader = imageLoader,
                            minSize = thumbMin,
                            selected = trashSelected,
                            onToggle = { trashSelected = toggle(trashSelected, it.id) },
                            onRestore = { items ->
                                launchRequest(MediaRequests.trash(context, items, false)) {
                                    trashSelected = emptyList()
                                }
                            },
                            onDeleteForever = { items ->
                                launchRequest(MediaRequests.deleteForever(context, items)) {
                                    trashSelected = emptyList()
                                }
                            },
                            onBack = {
                                subScreen = SUB_NONE
                                trashSelected = emptyList()
                            },
                        )

                        else -> when (dest) {
                            Dest.Photos -> MediaScreen(
                                state = photos,
                                emptyTitle = "No photos yet",
                                emptyBody = "Take a picture or save one to your phone and it will appear here automatically.",
                                imageLoader = imageLoader,
                                minSize = thumbMin,
                                selectedIds = selectedSet,
                                onGrant = onGrant,
                                onOpenSettings = onOpenSettings,
                                onItemClick = {
                                    if (selected.isNotEmpty()) selected = toggle(selected, it.id)
                                    else viewerId = it.id
                                },
                                onItemLongClick = { selected = toggle(selected, it.id) },
                                header = mediaHeader,
                            )

                            Dest.Videos -> MediaScreen(
                                state = videos,
                                emptyTitle = "No videos yet",
                                emptyBody = "Record a video or save one to your phone and it will appear here automatically.",
                                imageLoader = imageLoader,
                                minSize = thumbMin,
                                selectedIds = selectedSet,
                                onGrant = onGrant,
                                onOpenSettings = onOpenSettings,
                                onItemClick = {
                                    if (selected.isNotEmpty()) selected = toggle(selected, it.id)
                                    else viewerId = it.id
                                },
                                onItemLongClick = { selected = toggle(selected, it.id) },
                                header = mediaHeader,
                            )

                            Dest.Albums -> {
                                if (subScreen == SUB_ALBUM && currentAlbum != null) {
                                    AlbumDetailScreen(
                                        album = currentAlbum,
                                        imageLoader = imageLoader,
                                        minSize = thumbMin,
                                        selected = selected,
                                        onBack = {
                                            subScreen = SUB_NONE
                                            selected = emptyList()
                                        },
                                        onItemClick = {
                                            if (selected.isNotEmpty()) selected = toggle(selected, it.id)
                                            else viewerId = it.id
                                        },
                                        onItemLongClick = { selected = toggle(selected, it.id) },
                                        onRemoveSelected = {
                                            val toRemove = albumItems.filter { it.id in selectedSet }
                                            viewModel.removeFromAlbum(currentAlbum.id, toRemove)
                                            selected = emptyList()
                                        },
                                        onCancelSelection = { selected = emptyList() },
                                    )
                                } else {
                                    AlbumsScreen(
                                        albums = albums,
                                        imageLoader = imageLoader,
                                        onOpen = {
                                            albumOpenId = it.id
                                            subScreen = SUB_ALBUM
                                        },
                                        onCreate = { viewModel.createAlbum(it) },
                                        onRename = { album, name -> viewModel.renameAlbum(album.id, name) },
                                        onDelete = { viewModel.deleteAlbum(it.id) },
                                    )
                                }
                            }

                            Dest.Collage -> MessageState(
                                title = "Collage",
                                body = "Collages are coming in a later update.",
                            ) {}

                            Dest.Settings -> SettingsScreen(
                                railOnRight = railOnRight,
                                onRailOnRightChange = { viewModel.setRailOnRight(it) },
                                thumbSize = thumbSize,
                                onThumbSizeChange = { viewModel.setThumbSize(it) },
                                onResetSorting = { viewModel.resetSorting() },
                            )
                        }
                    }
                }

                NavRail(
                    current = dest,
                    onSelect = {
                        destIndex = it.ordinal
                        subScreen = SUB_NONE
                        selected = emptyList()
                        trashSelected = emptyList()
                    },
                    rightSide = railOnRight,
                    modifier = Modifier.align(if (railOnRight) Alignment.CenterEnd else Alignment.CenterStart),
                )
            }

            // Full-screen viewer on top of everything
            val openId = viewerId
            if (openId != null) {
                val viewerItems = when {
                    subScreen == SUB_ALBUM -> albumItems
                    dest == Dest.Videos -> videoItems
                    else -> photoItems
                }
                val start = viewerItems.indexOfFirst { it.id == openId }
                if (start >= 0) {
                    MediaViewer(
                        items = viewerItems,
                        startIndex = start,
                        imageLoader = imageLoader,
                        onCurrentChanged = { viewerId = it },
                        onClose = { viewerId = null },
                        onAddToAlbum = { addTarget = listOf(it) },
                        onTrash = { item -> trashItems(listOf(item)) },
                    )
                } else {
                    // The item disappeared (trashed/deleted) or the list isn't loaded: close.
                    SideEffect { viewerId = null }
                }
            }
        }
    }

    val target = addTarget
    if (target != null) {
        AddToAlbumDialog(
            albums = albums,
            onPick = {
                viewModel.addToAlbum(it.id, target)
                addTarget = null
                selected = emptyList()
            },
            onCreate = {
                viewModel.createAlbum(it, target)
                addTarget = null
                selected = emptyList()
            },
            onDismiss = { addTarget = null },
        )
    }
}

@Composable
private fun MediaScreen(
    state: GalleryState,
    emptyTitle: String,
    emptyBody: String,
    imageLoader: ImageLoader,
    minSize: Dp,
    selectedIds: Set<Long>,
    onGrant: () -> Unit,
    onOpenSettings: () -> Unit,
    onItemClick: (MediaItem) -> Unit,
    onItemLongClick: (MediaItem) -> Unit,
    header: @Composable () -> Unit,
) {
    Column(Modifier.fillMaxSize()) {
        header()
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (state) {
                GalleryState.Loading ->
                    CircularProgressIndicator(Modifier.align(Alignment.Center))

                GalleryState.NoPermission ->
                    MessageState(
                        title = "Allow access to your media",
                        body = "Gallerfix works entirely on your phone. It needs permission to read your photos and videos to show them here.",
                    ) {
                        Button(onClick = onGrant) { Text("Grant access") }
                        OutlinedButton(onClick = onOpenSettings) { Text("Open app settings") }
                    }

                GalleryState.Empty ->
                    MessageState(title = emptyTitle, body = emptyBody) {}

                is GalleryState.Content ->
                    MediaGrid(
                        items = state.items,
                        imageLoader = imageLoader,
                        minSize = minSize,
                        selectedIds = selectedIds,
                        onItemClick = onItemClick,
                        onItemLongClick = onItemLongClick,
                    )
            }
        }
    }
}
