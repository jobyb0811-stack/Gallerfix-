package com.gallerfix.app.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.ImageLoader
import coil.decode.VideoFrameDecoder
import com.gallerfix.app.data.MediaItem
import com.gallerfix.app.data.MediaPermissions

@Composable
fun GalleryApp(viewModel: GalleryViewModel) {
    val context = LocalContext.current
    val photos by viewModel.photos.collectAsStateWithLifecycle()
    val videos by viewModel.videos.collectAsStateWithLifecycle()
    val railOnRight by viewModel.railOnRight.collectAsStateWithLifecycle()

    // Survive rotation / process death
    var destIndex by rememberSaveable { mutableStateOf(0) }
    var viewerId by rememberSaveable { mutableStateOf<Long?>(null) }
    val dest = Dest.entries[destIndex]

    val imageLoader = remember(context) {
        ImageLoader.Builder(context)
            .components { add(VideoFrameDecoder.Factory()) }
            .build()
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { viewModel.refreshPermission() }

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) viewModel.refreshPermission()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val onGrant: () -> Unit = { permissionLauncher.launch(MediaPermissions.required()) }
    val onOpenSettings: () -> Unit = {
        context.startActivity(
            Intent(
                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.fromParts("package", context.packageName, null)
            )
        )
    }

    Surface(modifier = Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize()) {

            // Main layer: content + rail. Content never sits under the rail.
            Box(Modifier.fillMaxSize().systemBarsPadding()) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .padding(
                            start = if (railOnRight) 0.dp else RailSpec.CollapsedWidth,
                            end = if (railOnRight) RailSpec.CollapsedWidth else 0.dp,
                        )
                ) {
                    when (dest) {
                        Dest.Photos -> MediaScreen(
                            title = "Photos",
                            emptyTitle = "No photos yet",
                            emptyBody = "Take a picture or save one to your phone and it will appear here automatically.",
                            state = photos,
                            imageLoader = imageLoader,
                            onGrant = onGrant,
                            onOpenSettings = onOpenSettings,
                            onItemClick = { viewerId = it.id },
                        )
                        Dest.Videos -> MediaScreen(
                            title = "Videos",
                            emptyTitle = "No videos yet",
                            emptyBody = "Record a video or save one to your phone and it will appear here automatically.",
                            state = videos,
                            imageLoader = imageLoader,
                            onGrant = onGrant,
                            onOpenSettings = onOpenSettings,
                            onItemClick = { viewerId = it.id },
                        )
                        Dest.Albums -> MessageState(
                            title = "Albums",
                            body = "Custom albums are coming in a later update.",
                        ) {}
                        Dest.Collage -> MessageState(
                            title = "Collage",
                            body = "Collages are coming in a later update.",
                        ) {}
                        Dest.Settings -> SettingsScreen(
                            railOnRight = railOnRight,
                            onRailOnRightChange = { viewModel.setRailOnRight(it) },
                        )
                    }
                }

                NavRail(
                    current = dest,
                    onSelect = { destIndex = it.ordinal },
                    rightSide = railOnRight,
                    modifier = Modifier.align(if (railOnRight) Alignment.CenterEnd else Alignment.CenterStart),
                )
            }

            // Full-screen viewer on top of everything
            val openId = viewerId
            if (openId != null) {
                val currentState = if (dest == Dest.Videos) videos else photos
                val items = (currentState as? GalleryState.Content)?.items ?: emptyList()
                val start = items.indexOfFirst { it.id == openId }
                if (start >= 0) {
                    MediaViewer(
                        items = items,
                        startIndex = start,
                        imageLoader = imageLoader,
                        onCurrentChanged = { viewerId = it },
                        onClose = { viewerId = null },
                    )
                } else {
                    // The item disappeared (deleted elsewhere) or the list isn't loaded: close.
                    SideEffect { viewerId = null }
                }
            }
        }
    }
}

@Composable
private fun MediaScreen(
    title: String,
    emptyTitle: String,
    emptyBody: String,
    state: GalleryState,
    imageLoader: ImageLoader,
    onGrant: () -> Unit,
    onOpenSettings: () -> Unit,
    onItemClick: (MediaItem) -> Unit,
) {
    Box(Modifier.fillMaxSize()) {
        when (state) {
            GalleryState.Loading ->
                CircularProgressIndicator(Modifier.align(Alignment.Center))

            GalleryState.NoPermission ->
                MessageState(
                    title = "Allow access to your media",
                    body = "Gallerfix works entirely on your phone. It needs permission to read your photos and videos to show them here.",
                ) {
                    Button(onClick = onGrant) { Text("Grant access") }
                    OutlinedButton(onClick = onOpenSettings) { Text("Open app settings") }
                }

            GalleryState.Empty ->
                MessageState(title = emptyTitle, body = emptyBody) {}

            is GalleryState.Content ->
                MediaGrid(title, state.items, imageLoader, onItemClick)
        }
    }
}

@Composable
private fun MessageState(
    title: String,
    body: String,
    actions: @Composable ColumnScope.() -> Unit,
) {
    Column(
        modifier = Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp, Alignment.CenterVertically),
    ) {
        Text(title, style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
        Text(body, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center)
        actions()
    }
}
