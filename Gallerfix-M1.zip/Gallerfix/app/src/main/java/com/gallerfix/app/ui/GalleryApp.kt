package com.gallerfix.app.ui

import android.app.Activity
import android.content.Intent
import android.content.IntentSender
import android.net.Uri
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.ImageLoader
import coil.decode.VideoFrameDecoder
import coil.memory.MemoryCache
import com.gallerfix.app.data.ThumbFetcher
import com.gallerfix.app.data.ThumbKeyer
import com.gallerfix.app.VaultSpec
import com.gallerfix.app.data.MediaItem
import com.gallerfix.app.data.MediaPermissions
import com.gallerfix.app.data.MediaRequests
import com.gallerfix.app.data.SmartAlbum
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private const val SUB_NONE = 0
private const val SUB_SORT = 1
private const val SUB_TRASH = 2
private const val SUB_ALBUM = 3
private const val SUB_SMART = 5
private const val SUB_SEARCH = 6

@Composable
fun GalleryApp(viewModel: GalleryViewModel) {
    val context = LocalContext.current
    val photos by viewModel.photos.collectAsStateWithLifecycle()
    val videos by viewModel.videos.collectAsStateWithLifecycle()
    val albums by viewModel.albums.collectAsStateWithLifecycle()
    val canUndo by viewModel.canUndo.collectAsStateWithLifecycle()
    val favoriteIds by viewModel.favoriteIds.collectAsStateWithLifecycle()
    val slideshowSeconds by viewModel.slideshowSeconds.collectAsStateWithLifecycle()
    val autoHideRail by viewModel.autoHideRail.collectAsStateWithLifecycle()
    val startDest by viewModel.startDest.collectAsStateWithLifecycle()
    val warmStatus by viewModel.warmProgress.collectAsStateWithLifecycle()
    val dialHaptics by viewModel.dialHaptics.collectAsStateWithLifecycle()
    val railOnRight by viewModel.railOnRight.collectAsStateWithLifecycle()
    val thumbSize by viewModel.thumbSize.collectAsStateWithLifecycle()
    val showSd by viewModel.showSd.collectAsStateWithLifecycle()
    val themeMode by viewModel.themeMode.collectAsStateWithLifecycle()
    val palette by viewModel.palette.collectAsStateWithLifecycle()
    val amoled by viewModel.amoled.collectAsStateWithLifecycle()
    val lockEnabled by viewModel.lockEnabled.collectAsStateWithLifecycle()
    val lockBiometric by viewModel.lockBiometric.collectAsStateWithLifecycle()
    val lockTaps by viewModel.lockTaps.collectAsStateWithLifecycle()
    val lockFace by viewModel.lockFace.collectAsStateWithLifecycle()
    val lockSequential by viewModel.lockSequential.collectAsStateWithLifecycle()
    val lockRecovery by viewModel.lockRecovery.collectAsStateWithLifecycle()
    val tapCount by viewModel.tapCount.collectAsStateWithLifecycle()
    val lockGrace by viewModel.lockGrace.collectAsStateWithLifecycle()
    val locationGranted by viewModel.locationGranted.collectAsStateWithLifecycle()
    val placesProgress by viewModel.placesProgress.collectAsStateWithLifecycle()
    val vaultOpen by viewModel.vaultOpen.collectAsStateWithLifecycle()
    val vaultItems by viewModel.vaultItems.collectAsStateWithLifecycle()
    val vaultBusy by viewModel.vaultBusy.collectAsStateWithLifecycle()
    val vaultMessage by viewModel.vaultMessage.collectAsStateWithLifecycle()
    val activity = context.findFragmentActivity()
    val scope = rememberCoroutineScope()

    // Survive rotation / process death
    var destIndex by rememberSaveable { mutableStateOf(viewModel.startDest.value) }
    var subScreen by rememberSaveable { mutableStateOf(SUB_NONE) }
    var albumOpenId by rememberSaveable { mutableStateOf(0L) }
    var albumsTab by rememberSaveable { mutableStateOf(0) }
    var smartOpenId by rememberSaveable { mutableStateOf("") }
    var searchQuery by rememberSaveable { mutableStateOf("") }
    var viewerId by rememberSaveable { mutableStateOf<Long?>(null) }
    var selected by rememberSaveable { mutableStateOf<List<Long>>(emptyList()) }
    var trashSelected by rememberSaveable { mutableStateOf<List<Long>>(emptyList()) }
    var addTarget by remember { mutableStateOf<List<MediaItem>?>(null) }
    var detailsFor by remember { mutableStateOf<MediaItem?>(null) }
    var drawerOpen by rememberSaveable { mutableStateOf(false) }
    var viewerHint by remember { mutableStateOf(0) }
    // Set when a viewer is opened from the dial, which has its own ordering of the library.
    var viewerOverride by remember { mutableStateOf<List<MediaItem>?>(null) }

    val dest = Dest.entries[destIndex]

    // Heavy lists are only built while the screen that needs them is open.
    val trash = if (subScreen == SUB_TRASH) {
        viewModel.trash.collectAsStateWithLifecycle().value
    } else {
        GalleryState.Loading
    }
    val triage = if (subScreen == SUB_SORT) {
        viewModel.triage.collectAsStateWithLifecycle().value
    } else {
        TriageUi(emptyList(), emptyList(), false)
    }
    val searchIndex = if (subScreen == SUB_SEARCH) {
        viewModel.searchIndex.collectAsStateWithLifecycle().value
    } else {
        emptyList<SearchEntry>()
    }
    val smartActive = subScreen == SUB_SMART || (dest == Dest.Albums && albumsTab == 1)
    val smartAlbums = if (smartActive) {
        viewModel.smartAlbums.collectAsStateWithLifecycle().value
    } else {
        emptyList<SmartAlbum>()
    }
    LaunchedEffect(smartActive) { if (smartActive) viewModel.wantPlaces() }
    LaunchedEffect(dest) { if (dest == Dest.Dial) viewModel.wantDial() }
    val photoItems = (photos as? GalleryState.Content)?.items ?: emptyList()
    val videoItems = (videos as? GalleryState.Content)?.items ?: emptyList()
    val currentAlbum = albums.firstOrNull { it.id == albumOpenId }
    val albumItems = currentAlbum?.items ?: emptyList()
    val currentSmart = smartAlbums.firstOrNull { it.id == smartOpenId }
    val smartItems = currentSmart?.items ?: emptyList()
    val searchResults = remember(searchIndex, searchQuery) {
        val tokens = searchQuery.lowercase().split(" ").filter { it.isNotBlank() }
        if (tokens.isEmpty()) {
            emptyList()
        } else {
            searchIndex.filter { entry -> tokens.all { entry.text.contains(it) } }.map { it.item }
        }
    }
    val thumbMin: Dp = when (thumbSize) {
        0 -> 80.dp
        2 -> 160.dp
        else -> 110.dp
    }

    // If the open album vanished (deleted), go back to the album list.
    SideEffect {
        if (subScreen == SUB_ALBUM && currentAlbum == null) subScreen = SUB_NONE
        if (subScreen == SUB_SMART && currentSmart == null) subScreen = SUB_NONE
    }

    val imageLoader = remember(context) {
        ImageLoader.Builder(context)
            .components {
                add(VideoFrameDecoder.Factory())
                add(ThumbKeyer())
                add(ThumbFetcher.Factory())
            }
            .memoryCache { MemoryCache.Builder(context).maxSizePercent(0.35).build() }
            .build()
    }

    // ---- permissions ----
    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { viewModel.refreshPermission() }

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) viewModel.refreshPermission()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val onGrant: () -> Unit = { permissionLauncher.launch(MediaPermissions.required()) }
    val onOpenSettings: () -> Unit = {
        context.startActivity(
            Intent(
                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.fromParts("package", context.packageName, null)
            )
        )
    }

    // ---- system trash / delete dialogs ----
    // If the user cancels the system dialog, nothing runs and nothing changes.
    var pendingOk by remember { mutableStateOf<(() -> Unit)?>(null) }
    var pendingCancel by remember { mutableStateOf<(() -> Unit)?>(null) }
    val requestLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) pendingOk?.invoke() else pendingCancel?.invoke()
        pendingOk = null
        pendingCancel = null
    }

    fun launchRequest(sender: IntentSender, onCancel: () -> Unit = {}, onOk: () -> Unit) {
        pendingOk = onOk
        pendingCancel = onCancel
        try {
            requestLauncher.launch(IntentSenderRequest.Builder(sender).build())
        } catch (e: Exception) {
            pendingOk = null
            pendingCancel = null
            onCancel()
        }
    }

    fun trashItems(items: List<MediaItem>) {
        if (items.isEmpty()) return
        launchRequest(MediaRequests.trash(context, items, true)) {
            selected = emptyList()
        }
    }

    // ---- selection helpers ----
    fun toggle(list: List<Long>, id: Long): List<Long> =
        if (id in list) list - id else list + id

    val gridItems = when {
        subScreen == SUB_SMART -> smartItems
        subScreen == SUB_SEARCH -> searchResults
        dest == Dest.Videos -> videoItems
        else -> photoItems
    }
    val selectedSet = selected.toSet()

    /** The actions offered for the selected items of [pool]. */
    fun actionsFor(
        pool: List<MediaItem>,
        showAlbum: Boolean = true,
        showTrash: Boolean = true,
        onRemove: (() -> Unit)? = null,
    ): SelectionActions {
        val chosen = pool.filter { it.id in selectedSet }
        val albumAction: (() -> Unit)? = if (showAlbum) ({ addTarget = chosen }) else null
        val trashAction: (() -> Unit)? = if (showTrash) ({ trashItems(chosen) }) else null
        return SelectionActions(
            onSelectAll = { selected = pool.map { it.id } },
            onFavorite = {
                viewModel.setFavorite(chosen, true)
                selected = emptyList()
            },
            onUnfavorite = {
                viewModel.setFavorite(chosen, false)
                selected = emptyList()
            },
            onShare = { shareItems(context, chosen) },
            onCancel = { selected = emptyList() },
            onAlbum = albumAction,
            onTrash = trashAction,
            onRemove = onRemove,
        )
    }

    // ---- back handling (viewer handles its own, and wins) ----
    BackHandler(enabled = subScreen != SUB_NONE) {
        subScreen = SUB_NONE
        trashSelected = emptyList()
        selected = emptyList()
    }
    BackHandler(enabled = selected.isNotEmpty()) { selected = emptyList() }
    BackHandler(enabled = drawerOpen) { drawerOpen = false }

    // ---- hidden entrance to the private library: tap Collage several times, fast ----
    val openVaultWithAuth: () -> Unit = {
        if (activity != null) {
            BiometricAuth.authenticate(
                activity = activity,
                title = "Confirm it's you",
                onUnavailable = {
                    Toast.makeText(
                        context,
                        "Set up a fingerprint, face or screen lock in your phone's Settings to use this.",
                        Toast.LENGTH_LONG,
                    ).show()
                },
            ) { ok -> if (ok) viewModel.openVault() }
        }
    }
    val collageTaps = remember { ArrayList<Long>() }
    val onCollageTap: () -> Unit = {
        val now = SystemClock.elapsedRealtime()
        collageTaps.add(now)
        collageTaps.removeAll { now - it > VaultSpec.TAP_WINDOW_MS }
        if (collageTaps.size >= VaultSpec.TAP_COUNT) {
            collageTaps.clear()
            openVaultWithAuth()
        }
    }

    // ---- private library actions ----
    val pickerItems = if (vaultOpen) {
        remember(photoItems, videoItems) {
            (photoItems + videoItems).sortedByDescending { it.dateAddedSeconds }
        }
    } else {
        emptyList<MediaItem>()
    }

    fun removeVaultOriginals(uris: List<Uri>, ids: List<Long>) {
        try {
            launchRequest(
                sender = MediaRequests.deleteUris(context, uris),
                onCancel = { viewModel.onVaultOriginalsKept() },
            ) { viewModel.onVaultOriginalsRemoved(ids) }
        } catch (e: Exception) {
            viewModel.onVaultOriginalsKept()
        }
    }

    fun moveIntoVault(items: List<MediaItem>) {
        if (items.isEmpty()) return
        scope.launch {
            val result = viewModel.moveToVault(items)
            if (result.moved.isNotEmpty()) {
                removeVaultOriginals(result.moved.map { it.original }, result.moved.map { it.entityId })
            }
        }
    }

    fun finishPendingVault() {
        scope.launch {
            val remaining = viewModel.vaultPendingOriginals()
            if (remaining.isNotEmpty()) {
                removeVaultOriginals(remaining.map { it.original }, remaining.map { it.entityId })
            }
        }
    }

    // ---- turning app lock on: confirm the unlock method works first so you can't lock yourself out ----
    val onLockEnabledChange: (Boolean) -> Unit = { enable ->
        if (!enable || !lockBiometric) {
            viewModel.setLockEnabled(enable)
        } else if (activity != null) {
            BiometricAuth.authenticate(
                activity = activity,
                title = "Confirm to turn on app lock",
                onUnavailable = {
                    if (lockTaps) {
                        viewModel.setLockEnabled(true)
                    } else {
                        Toast.makeText(
                            context,
                            "Set up a fingerprint, face or screen lock in your phone's Settings first.",
                            Toast.LENGTH_LONG,
                        ).show()
                    }
                },
            ) { ok -> if (ok) viewModel.setLockEnabled(true) }
        }
    }

    // ---- auto-hide the rail while scrolling; a drag from the screen edge brings it back ----
    var scrolling by remember { mutableStateOf(false) }
    var hideRail by remember { mutableStateOf(false) }
    var revealed by remember { mutableStateOf(false) }
    LaunchedEffect(scrolling, autoHideRail) {
        if (autoHideRail && scrolling) {
            hideRail = true
        } else {
            delay(700)
            hideRail = false
            revealed = false
        }
    }
    val railHidden = autoHideRail && hideRail && !revealed && !drawerOpen
    // Photos slide into the rail's space when it tucks away, and make room again when it returns.
    val railPad by animateDpAsState(
        targetValue = if (railHidden) 0.dp else RailSpec.CollapsedWidth,
        animationSpec = tween(260),
        label = "railPad",
    )
    val origins = remember { OriginTracker() }

    // ---- keep the system "back" swipe from stealing drags that start on the rail's edge ----
    val view = LocalView.current
    val haptics = remember { Haptics(context, view) }
    DisposableEffect(haptics) { onDispose { haptics.close() } }
    var rootSize by remember { mutableStateOf(IntSize.Zero) }
    DisposableEffect(rootSize, railOnRight) {
        if (rootSize.width > 0) {
            val density = view.resources.displayMetrics.density
            val strip = (48 * density).toInt()
            val half = (100 * density).toInt()
            val centerY = rootSize.height / 2
            view.systemGestureExclusionRects = listOf(
                android.graphics.Rect(
                    if (railOnRight) rootSize.width - strip else 0,
                    centerY - half,
                    if (railOnRight) rootSize.width else strip,
                    centerY + half,
                )
            )
        }
        onDispose { view.systemGestureExclusionRects = emptyList() }
    }

    val mediaHeader: @Composable () -> Unit = {
        if (selected.isNotEmpty()) {
            SelectionHeader(selected.size, actionsFor(gridItems))
        } else {
            HeaderBar(dest.label) {
                TextButton(onClick = { subScreen = SUB_SEARCH }) { Text("Find") }
                TextButton(onClick = { subScreen = SUB_SORT }) { Text("Sort") }
                TextButton(onClick = { subScreen = SUB_TRASH }) { Text("Trash") }
            }
        }
    }

    CompositionLocalProvider(LocalFavorites provides favoriteIds, LocalOrigins provides origins) {
        Surface(modifier = Modifier.fillMaxSize()) {
            Box(Modifier.fillMaxSize().onSizeChanged { rootSize = it }) {

                // Main layer: content + rail. Content never sits under the rail.
                Box(Modifier.fillMaxSize().systemBarsPadding()) {
                    Box(
                        Modifier
                            .fillMaxSize()
                            .padding(
                                start = if (railOnRight) 0.dp else railPad,
                                end = if (railOnRight) railPad else 0.dp,
                            )
                    ) {
                        AnimatedContent(
                            targetState = destIndex * 10 + subScreen,
                            transitionSpec = {
                                if (initialState / 10 == targetState / 10) {
                                    (fadeIn(tween(240)) + scaleIn(initialScale = 0.96f, animationSpec = tween(240))) togetherWith
                                        fadeOut(tween(140))
                                } else {
                                    val forward = targetState / 10 > initialState / 10
                                    (slideInHorizontally(tween(280)) { w -> if (forward) w / 5 else -w / 5 } +
                                        fadeIn(tween(260))) togetherWith
                                        (slideOutHorizontally(tween(220)) { w -> if (forward) -w / 5 else w / 5 } +
                                            fadeOut(tween(160)))
                                }
                            },
                            label = "screen",
                        ) { screenKey ->
                            val screenDest = Dest.entries[screenKey / 10]
                            val screenSub = screenKey % 10
                        when {
                            screenSub == SUB_SORT -> TriageScreen(
                                state = triage,
                                canUndo = canUndo,
                                imageLoader = imageLoader,
                                onDecide = { item, toTrash -> viewModel.decide(item, toTrash) },
                                onUndo = { viewModel.undo() },
                                onReview = {
                                    val batch = triage.queued.take(TRASH_BATCH)
                                    if (batch.isNotEmpty()) {
                                        launchRequest(MediaRequests.trash(context, batch, true)) {
                                            viewModel.onTrashed(batch)
                                        }
                                    }
                                },
                                onClearQueue = { viewModel.clearTrashQueue() },
                                onDone = { subScreen = SUB_NONE },
                            )

                            screenSub == SUB_TRASH -> TrashScreen(
                                state = trash,
                                imageLoader = imageLoader,
                                minSize = thumbMin,
                                selected = trashSelected,
                                onToggle = { trashSelected = toggle(trashSelected, it.id) },
                                onRestore = { items ->
                                    launchRequest(MediaRequests.trash(context, items, false)) {
                                        trashSelected = emptyList()
                                    }
                                },
                                onDeleteForever = { items ->
                                    launchRequest(MediaRequests.deleteForever(context, items)) {
                                        trashSelected = emptyList()
                                    }
                                },
                                onBack = {
                                    subScreen = SUB_NONE
                                    trashSelected = emptyList()
                                },
                            )

                            screenSub == SUB_SEARCH -> SearchScreen(
                                query = searchQuery,
                                onQueryChange = { searchQuery = it },
                                results = searchResults,
                                imageLoader = imageLoader,
                                minSize = thumbMin,
                                selected = selected,
                                onItemClick = {
                                    if (selected.isNotEmpty()) selected = toggle(selected, it.id)
                                    else viewerId = it.id
                                },
                                onItemLongClick = { selected = toggle(selected, it.id) },
                                selection = actionsFor(searchResults),
                                onClose = {
                                    subScreen = SUB_NONE
                                    selected = emptyList()
                                },
                            )

                            else -> when (screenDest) {
                                Dest.Photos -> MediaScreen(
                                    state = photos,
                                    emptyTitle = "No photos yet",
                                    emptyBody = "Take a picture or save one to your phone and it will appear here automatically.",
                                    imageLoader = imageLoader,
                                    minSize = thumbMin,
                                    selectedIds = selectedSet,
                                    onGrant = onGrant,
                                    onOpenSettings = onOpenSettings,
                                    onItemClick = {
                                        if (selected.isNotEmpty()) selected = toggle(selected, it.id)
                                        else viewerId = it.id
                                    },
                                    onItemLongClick = { selected = toggle(selected, it.id) },
                                    onScrolling = { if (autoHideRail) scrolling = it },
                                    header = mediaHeader,
                                )

                                Dest.Videos -> MediaScreen(
                                    state = videos,
                                    emptyTitle = "No videos yet",
                                    emptyBody = "Record a video or save one to your phone and it will appear here automatically.",
                                    imageLoader = imageLoader,
                                    minSize = thumbMin,
                                    selectedIds = selectedSet,
                                    onGrant = onGrant,
                                    onOpenSettings = onOpenSettings,
                                    onItemClick = {
                                        if (selected.isNotEmpty()) selected = toggle(selected, it.id)
                                        else viewerId = it.id
                                    },
                                    onItemLongClick = { selected = toggle(selected, it.id) },
                                    onScrolling = { if (autoHideRail) scrolling = it },
                                    header = mediaHeader,
                                )

                                Dest.Albums -> {
                                    if (screenSub == SUB_ALBUM && currentAlbum != null) {
                                        AlbumDetailScreen(
                                            album = currentAlbum,
                                            imageLoader = imageLoader,
                                            minSize = thumbMin,
                                            selected = selected,
                                            onBack = {
                                                subScreen = SUB_NONE
                                                selected = emptyList()
                                            },
                                            onItemClick = {
                                                if (selected.isNotEmpty()) selected = toggle(selected, it.id)
                                                else viewerId = it.id
                                            },
                                            onItemLongClick = { selected = toggle(selected, it.id) },
                                            selection = actionsFor(
                                                pool = albumItems,
                                                onRemove = {
                                                    val toRemove = albumItems.filter { it.id in selectedSet }
                                                    viewModel.removeFromAlbum(currentAlbum.id, toRemove)
                                                    selected = emptyList()
                                                },
                                            ),
                                        )
                                    } else if (screenSub == SUB_SMART && currentSmart != null) {
                                        SmartDetailScreen(
                                            album = currentSmart,
                                            imageLoader = imageLoader,
                                            minSize = thumbMin,
                                            selected = selected,
                                            onBack = {
                                                subScreen = SUB_NONE
                                                selected = emptyList()
                                            },
                                            onItemClick = {
                                                if (selected.isNotEmpty()) selected = toggle(selected, it.id)
                                                else viewerId = it.id
                                            },
                                            onItemLongClick = { selected = toggle(selected, it.id) },
                                            selection = actionsFor(smartItems),
                                        )
                                    } else {
                                        AlbumsScreen(
                                            albums = albums,
                                            imageLoader = imageLoader,
                                            tab = albumsTab,
                                            onTabChange = { albumsTab = it },
                                            smart = smartAlbums,
                                            locationGranted = locationGranted,
                                            placesProgress = placesProgress,
                                            onAllowLocation = {
                                                permissionLauncher.launch(MediaPermissions.locationPermission())
                                            },
                                            onOpenSmart = {
                                                smartOpenId = it.id
                                                subScreen = SUB_SMART
                                            },
                                            onRenamePlace = { album, name -> viewModel.renamePlace(album.placeCell, name) },
                                            onOpen = {
                                                albumOpenId = it.id
                                                subScreen = SUB_ALBUM
                                            },
                                            onCreate = { viewModel.createAlbum(it) },
                                            onRename = { album, name -> viewModel.renameAlbum(album.id, name) },
                                            onDelete = { viewModel.deleteAlbum(it.id) },
                                        )
                                    }
                                }

                                Dest.Dial -> DialScreen(
                                    photos = photoItems,
                                    videos = videoItems,
                                    session = viewModel.dial,
                                    imageLoader = imageLoader,
                                    haptics = haptics,
                                    hapticLevel = dialHaptics,
                                    warmStatus = warmStatus,
                                    onOpen = { list, item ->
                                        viewerOverride = list
                                        viewerId = item.id
                                    },
                                )

                                Dest.Table -> TableScreen(
                                    photos = photoItems,
                                    albums = albums,
                                    imageLoader = imageLoader,
                                    haptics = haptics,
                                    hapticLevel = dialHaptics,
                                    onCreateAlbum = { viewModel.createAlbum(it) },
                                    onAddToAlbum = { albumId, item -> viewModel.addToAlbum(albumId, listOf(item)) },
                                    onPreview = { list, item ->
                                        viewerOverride = list
                                        viewerId = item.id
                                    },
                                )

                                Dest.Collage -> CollageScreen(
                                    state = photos,
                                    imageLoader = imageLoader,
                                    minSize = thumbMin,
                                    session = viewModel.collage,
                                )

                                Dest.Settings -> SettingsScreen(
                                    railOnRight = railOnRight,
                                    onRailOnRightChange = { viewModel.setRailOnRight(it) },
                                    thumbSize = thumbSize,
                                    onThumbSizeChange = { viewModel.setThumbSize(it) },
                                    startDest = startDest,
                                    onStartDestChange = { viewModel.setStartDest(it) },
                                    dialHaptics = dialHaptics,
                                    onDialHapticsChange = { viewModel.setDialHaptics(it) },
                                    autoHideRail = autoHideRail,
                                    onAutoHideRailChange = { viewModel.setAutoHideRail(it) },
                                    slideshowSeconds = slideshowSeconds,
                                    onSlideshowSecondsChange = { viewModel.setSlideshowSeconds(it) },
                                    showSd = showSd,
                                    sdPresent = remember { sdCardPresent(context) },
                                    onShowSdChange = { viewModel.setShowSd(it) },
                                    themeMode = themeMode,
                                    onThemeModeChange = { viewModel.setThemeMode(it) },
                                    palette = palette,
                                    onPaletteChange = { viewModel.setPalette(it) },
                                    amoled = amoled,
                                    onAmoledChange = { viewModel.setAmoled(it) },
                                    lockEnabled = lockEnabled,
                                    onLockEnabledChange = onLockEnabledChange,
                                    lockSequential = lockSequential,
                                    onLockSequentialChange = { viewModel.setLockSequential(it) },
                                    lockBiometric = lockBiometric,
                                    onLockBiometricChange = { viewModel.setLockBiometric(it) },
                                    lockFace = lockFace,
                                    onLockFaceChange = { viewModel.setLockFace(it) },
                                    lockRecovery = lockRecovery,
                                    onLockRecoveryChange = { viewModel.setLockRecovery(it) },
                                    lockTaps = lockTaps,
                                    onLockTapsChange = { viewModel.setLockTaps(it) },
                                    tapCount = tapCount,
                                    onTapCountChange = { viewModel.setTapCount(it) },
                                    lockGraceSeconds = lockGrace,
                                    onLockGraceChange = { viewModel.setLockGrace(it) },
                                    onResetSorting = { viewModel.resetSorting() },
                                )
                            }
                        }
                        }
                    }

                    if (drawerOpen) {
                        Box(
                            Modifier
                                .fillMaxSize()
                                .background(Color.Black.copy(alpha = 0.32f))
                                .pointerInput(Unit) { detectTapGestures { drawerOpen = false } }
                        )
                    }

                    NavRail(
                        current = dest,
                        drawerOpen = drawerOpen,
                        onDrawerOpenChange = { drawerOpen = it },
                        onCollageTap = onCollageTap,
                        hidden = railHidden,
                        onSelect = {
                            destIndex = it.ordinal
                            subScreen = SUB_NONE
                            selected = emptyList()
                            trashSelected = emptyList()
                        },
                        rightSide = railOnRight,
                        modifier = Modifier.align(if (railOnRight) Alignment.CenterEnd else Alignment.CenterStart),
                    )

                    // While the rail is tucked away, dragging in from the screen edge brings it back.
                    if (railHidden) {
                        Box(
                            Modifier
                                .align(if (railOnRight) Alignment.CenterEnd else Alignment.CenterStart)
                                .fillMaxHeight()
                                .width(24.dp)
                                .pointerInput(railOnRight) {
                                    var total = 0f
                                    val trigger = 20.dp.toPx()
                                    detectHorizontalDragGestures(
                                        onDragStart = { total = 0f },
                                        onHorizontalDrag = { change, amount ->
                                            change.consume()
                                            total += amount
                                            val inward = if (railOnRight) -total else total
                                            if (inward > trigger) revealed = true
                                        },
                                    )
                                }
                        )
                    }
                }

                // Full-screen viewer on top of everything
                val openId = viewerId
                if (openId != null) {
                    val viewerItems = viewerOverride ?: when {
                        subScreen == SUB_ALBUM -> albumItems
                        subScreen == SUB_SMART -> smartItems
                        subScreen == SUB_SEARCH -> searchResults
                        dest == Dest.Videos -> videoItems
                        else -> photoItems
                    }
                    if (viewerItems.isEmpty()) {
                        SideEffect { viewerId = null }
                    } else {
                        val found = viewerItems.indexOfFirst { it.id == openId }
                        val start = if (found >= 0) found else viewerHint.coerceIn(0, viewerItems.lastIndex)
                        SideEffect { if (found >= 0) viewerHint = found }
                        HeroOverlay(
                            openOrigin = origins.lookup(openId),
                            closeOrigin = { viewerId?.let { origins.lookup(it) } },
                            rootSize = rootSize,
                            onClosed = {
                                viewerId = null
                                viewerOverride = null
                            },
                        ) { close ->
                            MediaViewer(
                                items = viewerItems,
                                startIndex = start,
                                imageLoader = imageLoader,
                                slideshowSeconds = slideshowSeconds,
                                onCurrentChanged = { viewerId = it },
                                onClose = close,
                                onAddToAlbum = { addTarget = listOf(it) },
                                onTrash = { item -> trashItems(listOf(item)) },
                                onShare = { shareItems(context, listOf(it)) },
                                onToggleFavorite = { item ->
                                    viewModel.setFavorite(listOf(item), item.id !in favoriteIds)
                                },
                                onDetails = { detailsFor = it },
                            )
                        }
                    }
                }

                // The private library: no visible entry anywhere. Opens full screen above everything.
                if (vaultOpen) {
                    VaultScreen(
                        entities = vaultItems,
                        mediaForPicker = pickerItems,
                        imageLoader = imageLoader,
                        busy = vaultBusy,
                        message = vaultMessage,
                        onDismissMessage = { viewModel.dismissVaultMessage() },
                        onClose = { viewModel.closeVault() },
                        onMove = { items -> moveIntoVault(items) },
                        onRestore = { viewModel.restoreFromVault(it) },
                        onDeleteForever = { viewModel.deleteFromVault(it) },
                        onFinishPending = { finishPendingVault() },
                        onUndoPending = { viewModel.undoPendingVault() },
                        loadThumb = { viewModel.vaultThumb(it) },
                        loadImage = { viewModel.vaultImage(it) },
                        loadVideo = { viewModel.vaultVideo(it) },
                    )
                }
            }
        }

        val target = addTarget
        if (target != null) {
            AddToAlbumDialog(
                albums = albums,
                onPick = {
                    viewModel.addToAlbum(it.id, target)
                    addTarget = null
                    selected = emptyList()
                },
                onCreate = {
                    viewModel.createAlbum(it, target)
                    addTarget = null
                    selected = emptyList()
                },
                onDismiss = { addTarget = null },
            )
        }

        val detailsItem = detailsFor
        if (detailsItem != null) {
            DetailsDialog(
                item = detailsItem,
                load = { viewModel.details(it) },
                onDismiss = { detailsFor = null },
            )
        }
    }
}

@Composable
private fun MediaScreen(
    state: GalleryState,
    emptyTitle: String,
    emptyBody: String,
    imageLoader: ImageLoader,
    minSize: Dp,
    selectedIds: Set<Long>,
    onGrant: () -> Unit,
    onOpenSettings: () -> Unit,
    onItemClick: (MediaItem) -> Unit,
    onItemLongClick: (MediaItem) -> Unit,
    onScrolling: (Boolean) -> Unit,
    header: @Composable () -> Unit,
) {
    Column(Modifier.fillMaxSize()) {
        header()
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (state) {
                GalleryState.Loading ->
                    CircularProgressIndicator(Modifier.align(Alignment.Center))

                GalleryState.NoPermission ->
                    MessageState(
                        title = "Allow access to your media",
                        body = "Gallerfix works entirely on your phone. It needs permission to read your photos and videos to show them here.",
                    ) {
                        Button(onClick = onGrant) { Text("Grant access") }
                        OutlinedButton(onClick = onOpenSettings) { Text("Open app settings") }
                    }

                GalleryState.Empty ->
                    MessageState(title = emptyTitle, body = emptyBody) {}

                is GalleryState.Content ->
                    MediaGrid(
                        items = state.items,
                        imageLoader = imageLoader,
                        minSize = minSize,
                        selectedIds = selectedIds,
                        onItemClick = onItemClick,
                        onItemLongClick = onItemLongClick,
                        onScrolling = onScrolling,
                    )
            }
        }
    }
}

/** True if a memory card (any storage volume besides the phone's main storage) is mounted. */
private fun sdCardPresent(context: android.content.Context): Boolean = try {
    MediaStore.getExternalVolumeNames(context).any { it != MediaStore.VOLUME_EXTERNAL_PRIMARY }
} catch (e: Exception) {
    false
}
