package com.gallerfix.app.ui

import androidx.compose.animation.core.animate
import androidx.compose.animation.core.tween
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.isSpecified
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.util.lerp
import kotlinx.coroutines.launch
import androidx.compose.ui.geometry.lerp as lerpOffset

/** Practically unlimited: far beyond what a phone photo has pixels for. */
const val MAX_ZOOM = 64f

/**
 * Pinch to zoom around your fingers, drag to pan, double-tap to zoom in or back out.
 * With one finger at normal size it stays out of the way so the pager can swipe.
 * [onTap] is a single tap (used to show or hide the controls).
 */
@Composable
fun ZoomBox(
    modifier: Modifier = Modifier,
    onTap: (() -> Unit)? = null,
    content: @Composable BoxScope.() -> Unit,
) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    var boxSize by remember { mutableStateOf(IntSize.Zero) }
    val scope = rememberCoroutineScope()

    fun clampOffset(value: Offset, s: Float): Offset {
        val maxX = boxSize.width * (s - 1f) / 2f
        val maxY = boxSize.height * (s - 1f) / 2f
        return Offset(value.x.coerceIn(-maxX, maxX), value.y.coerceIn(-maxY, maxY))
    }

    Box(
        modifier
            .fillMaxSize()
            .onSizeChanged { boxSize = it }
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    do {
                        val event = awaitPointerEvent()
                        val pressed = event.changes.count { it.pressed }
                        // Take over only when pinching or already zoomed in, so the pager can still swipe.
                        if (pressed >= 2 || scale > 1.001f) {
                            val zoom = event.calculateZoom()
                            val pan = event.calculatePan()
                            val centroid = event.calculateCentroid(useCurrent = true)
                            val old = scale
                            val newScale = (old * zoom).coerceIn(1f, MAX_ZOOM)
                            val z = newScale / old
                            val center = Offset(boxSize.width / 2f, boxSize.height / 2f)
                            // Keep the point under your fingers fixed while zooming.
                            val anchored = if (centroid.isSpecified) {
                                offset * z + (centroid - center) * (1f - z)
                            } else {
                                offset
                            }
                            scale = newScale
                            offset = if (newScale <= 1.001f) Offset.Zero else clampOffset(anchored + pan, newScale)
                            event.changes.forEach { if (it.positionChanged()) it.consume() }
                        }
                    } while (event.changes.any { it.pressed })
                }
            }
            .pointerInput(onTap) {
                detectTapGestures(
                    onTap = { onTap?.invoke() },
                    onDoubleTap = { tap ->
                        scope.launch {
                            val startScale = scale
                            val startOffset = offset
                            val target = if (startScale > 1.05f) 1f else 3f
                            val center = Offset(boxSize.width / 2f, boxSize.height / 2f)
                            val endOffset = if (target <= 1f) {
                                Offset.Zero
                            } else {
                                clampOffset((tap - center) * (1f - target), target)
                            }
                            animate(0f, 1f, animationSpec = tween(220)) { t, _ ->
                                scale = lerp(startScale, target, t)
                                offset = lerpOffset(startOffset, endOffset, t)
                            }
                        }
                    },
                )
            }
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                    translationX = offset.x
                    translationY = offset.y
                },
            content = content,
        )
    }
}
