package com.gallerfix.app.ui

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.MediaItem as ExoMediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.ImageLoader
import com.gallerfix.app.data.MediaItem
import com.gallerfix.app.data.db.VaultEntity
import java.io.File

/** The private library. Full screen, with its own back handling. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun VaultScreen(
    entities: List<VaultEntity>,
    mediaForPicker: List<MediaItem>,
    imageLoader: ImageLoader,
    busy: String?,
    message: String?,
    onDismissMessage: () -> Unit,
    onClose: () -> Unit,
    onMove: (List<MediaItem>) -> Unit,
    onRestore: (List<VaultEntity>) -> Unit,
    onDeleteForever: (List<VaultEntity>) -> Unit,
    onFinishPending: () -> Unit,
    onUndoPending: () -> Unit,
    loadThumb: suspend (VaultEntity) -> Bitmap?,
    loadImage: suspend (VaultEntity) -> Bitmap?,
    loadVideo: suspend (VaultEntity) -> File?,
) {
    var adding by rememberSaveable { mutableStateOf(false) }
    var pickSelected by rememberSaveable { mutableStateOf<List<Long>>(emptyList()) }
    var selected by rememberSaveable { mutableStateOf<List<Long>>(emptyList()) }
    var viewId by rememberSaveable { mutableStateOf<Long?>(null) }
    var confirmDelete by remember { mutableStateOf<List<VaultEntity>?>(null) }

    val openId = viewId
    val viewIndex = if (openId != null) entities.indexOfFirst { it.id == openId } else -1
    if (openId != null && viewIndex < 0) {
        // The item was restored or deleted: leave the viewer.
        LaunchedEffect(openId) { viewId = null }
    }

    BackHandler {
        when {
            viewId != null -> viewId = null
            adding -> {
                adding = false
                pickSelected = emptyList()
            }
            selected.isNotEmpty() -> selected = emptyList()
            else -> onClose()
        }
    }

    Surface(modifier = Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize()) {
            if (openId != null && viewIndex >= 0) {
                VaultViewer(
                    entities = entities,
                    startIndex = viewIndex,
                    loadImage = loadImage,
                    loadVideo = loadVideo,
                    onCurrentChanged = { viewId = it },
                    onClose = { viewId = null },
                    onRestore = { onRestore(listOf(it)) },
                    onDelete = { confirmDelete = listOf(it) },
                )
            } else if (adding) {
                Column(Modifier.fillMaxSize().systemBarsPadding()) {
                    HeaderBar("Choose items") {
                        TextButton(onClick = {
                            adding = false
                            pickSelected = emptyList()
                        }) { Text("Cancel") }
                        TextButton(
                            enabled = pickSelected.isNotEmpty(),
                            onClick = {
                                val set = pickSelected.toSet()
                                onMove(mediaForPicker.filter { it.id in set })
                                adding = false
                                pickSelected = emptyList()
                            },
                        ) { Text("Move ${pickSelected.size}") }
                    }
                    Text(
                        "Selected items are encrypted and moved here. Android will then ask you to confirm removing the originals from your gallery.",
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                    )
                    val toggle: (MediaItem) -> Unit = { item ->
                        pickSelected = if (item.id in pickSelected) pickSelected - item.id else pickSelected + item.id
                    }
                    MediaGrid(
                        items = mediaForPicker,
                        imageLoader = imageLoader,
                        minSize = 110.dp,
                        selectedIds = pickSelected.toSet(),
                        onItemClick = toggle,
                        onItemLongClick = toggle,
                    )
                }
            } else {
                Column(Modifier.fillMaxSize().systemBarsPadding()) {
                    if (selected.isNotEmpty()) {
                        val chosen = entities.filter { it.id in selected }
                        HeaderBar("${selected.size} selected") {
                            TextButton(onClick = {
                                onRestore(chosen)
                                selected = emptyList()
                            }) { Text("Restore") }
                            TextButton(onClick = { confirmDelete = chosen }) { Text("Delete") }
                            TextButton(onClick = { selected = emptyList() }) { Text("Cancel") }
                        }
                    } else {
                        HeaderBar("Private library") {
                            TextButton(onClick = { adding = true }) { Text("Add") }
                            TextButton(onClick = onClose) { Text("Close") }
                        }
                    }

                    if (message != null) {
                        Row(
                            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                        ) {
                            Text(
                                message,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.weight(1f),
                            )
                            TextButton(onClick = onDismissMessage) { Text("OK") }
                        }
                    }

                    val pending = entities.count { it.state == 0 }
                    if (pending > 0) {
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 4.dp)
                                .background(
                                    MaterialTheme.colorScheme.surfaceContainerHigh,
                                    RoundedCornerShape(16.dp),
                                )
                                .padding(12.dp)
                        ) {
                            Text(
                                "$pending item(s) are copied here but still in your gallery.",
                                style = MaterialTheme.typography.bodyMedium,
                            )
                            Row {
                                TextButton(onClick = onFinishPending) { Text("Remove from gallery") }
                                TextButton(onClick = onUndoPending) { Text("Undo") }
                            }
                        }
                    }

                    if (entities.isEmpty()) {
                        MessageState(
                            title = "Nothing here yet",
                            body = "Tap Add to move photos and videos into your private library. They are encrypted and hidden from the gallery.",
                        ) {}
                    } else {
                        LazyVerticalGrid(
                            columns = GridCells.Adaptive(minSize = 110.dp),
                            contentPadding = PaddingValues(2.dp),
                            horizontalArrangement = Arrangement.spacedBy(2.dp),
                            verticalArrangement = Arrangement.spacedBy(2.dp),
                            modifier = Modifier.fillMaxSize(),
                        ) {
                            items(entities, key = { it.id }) { entity ->
                                val isSelected = entity.id in selected
                                Box(
                                    Modifier
                                        .fillMaxWidth()
                                        .aspectRatio(1f)
                                        .combinedClickable(
                                            onClick = {
                                                if (selected.isNotEmpty()) {
                                                    selected = if (isSelected) selected - entity.id else selected + entity.id
                                                } else {
                                                    viewId = entity.id
                                                }
                                            },
                                            onLongClick = {
                                                selected = if (isSelected) selected - entity.id else selected + entity.id
                                            },
                                        )
                                ) {
                                    VaultThumb(entity, loadThumb)
                                    if (isSelected) {
                                        Box(
                                            Modifier
                                                .fillMaxSize()
                                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.3f))
                                        )
                                        Text(
                                            "✓",
                                            color = MaterialTheme.colorScheme.onPrimary,
                                            modifier = Modifier
                                                .align(Alignment.TopStart)
                                                .padding(6.dp)
                                                .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(50))
                                                .padding(horizontal = 6.dp, vertical = 1.dp),
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if (busy != null) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.6f))
                        .pointerInput(Unit) { },
                    contentAlignment = Alignment.Center,
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                    ) {
                        CircularProgressIndicator()
                        Text(busy, color = Color.White)
                    }
                }
            }
        }
    }

    val toDelete = confirmDelete
    if (toDelete != null) {
        AlertDialog(
            onDismissRequest = { confirmDelete = null },
            title = { Text("Delete permanently?") },
            text = { Text("${toDelete.size} item(s) will be erased. This can't be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    onDeleteForever(toDelete)
                    selected = emptyList()
                    confirmDelete = null
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = null }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun VaultThumb(entity: VaultEntity, loadThumb: suspend (VaultEntity) -> Bitmap?) {
    val bitmap by produceState<Bitmap?>(initialValue = null, entity.id) {
        value = loadThumb(entity)
    }
    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surfaceContainerHigh)) {
        val bmp = bitmap
        if (bmp != null) {
            Image(
                bitmap = bmp.asImageBitmap(),
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize(),
            )
        }
        if (entity.isVideo) {
            Text(
                text = formatVaultDuration(entity.durationMs),
                color = Color.White,
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(4.dp)
                    .background(Color.Black.copy(alpha = 0.55f), RoundedCornerShape(6.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp),
            )
        }
        if (entity.state == 0) {
            Text(
                text = "Copy",
                color = Color.White,
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(4.dp)
                    .background(Color(0xFFB26A00).copy(alpha = 0.85f), RoundedCornerShape(6.dp))
                    .padding(horizontal = 6.dp, vertical = 2.dp),
            )
        }
    }
}

private fun formatVaultDuration(ms: Long): String {
    val total = ms / 1000
    return "%d:%02d".format(total / 60, total % 60)
}

@Composable
private fun VaultViewer(
    entities: List<VaultEntity>,
    startIndex: Int,
    loadImage: suspend (VaultEntity) -> Bitmap?,
    loadVideo: suspend (VaultEntity) -> File?,
    onCurrentChanged: (Long) -> Unit,
    onClose: () -> Unit,
    onRestore: (VaultEntity) -> Unit,
    onDelete: (VaultEntity) -> Unit,
) {
    val pagerState = rememberPagerState(
        initialPage = startIndex.coerceAtLeast(0),
        pageCount = { entities.size },
    )
    LaunchedEffect(pagerState.settledPage) {
        entities.getOrNull(pagerState.settledPage)?.let { onCurrentChanged(it.id) }
    }
    val current = entities.getOrNull(pagerState.currentPage)

    Box(
        Modifier
            .fillMaxSize()
            .background(Color.Black)
            .pointerInput(Unit) { }
    ) {
        HorizontalPager(
            state = pagerState,
            key = { entities[it].id },
            pageSpacing = 8.dp,
            modifier = Modifier.fillMaxSize(),
        ) { page ->
            val entity = entities[page]
            if (entity.isVideo) {
                VaultVideo(entity, isCurrent = page == pagerState.currentPage, loadVideo = loadVideo)
            } else {
                val bitmap by produceState<Bitmap?>(initialValue = null, entity.id) {
                    value = loadImage(entity)
                }
                val bmp = bitmap
                if (bmp != null) {
                    ZoomableBitmap(bmp)
                } else {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = Color.White)
                    }
                }
            }
        }
        Row(
            Modifier
                .align(Alignment.TopStart)
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton(onClick = onClose) { BackIcon(Color.White) }
            Spacer(Modifier.weight(1f))
            Text(
                "${pagerState.currentPage + 1} / ${entities.size}",
                color = Color.White,
                modifier = Modifier.padding(end = 4.dp),
            )
            TextButton(onClick = { current?.let(onRestore) }) { Text("Restore", color = Color.White) }
            TextButton(onClick = { current?.let(onDelete) }) { Text("Delete", color = Color.White) }
        }
    }
}

@Composable
private fun ZoomableBitmap(bitmap: Bitmap) {
    ZoomBox {
        Image(
            bitmap = bitmap.asImageBitmap(),
            contentDescription = null,
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxSize(),
        )
    }
}

@Composable
private fun VaultVideo(
    entity: VaultEntity,
    isCurrent: Boolean,
    loadVideo: suspend (VaultEntity) -> File?,
) {
    if (!isCurrent) {
        Box(Modifier.fillMaxSize())
        return
    }
    val file by produceState<File?>(initialValue = null, entity.id) {
        value = loadVideo(entity)
    }
    val ready = file
    if (ready == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = Color.White)
        }
    } else {
        VaultPlayer(Uri.fromFile(ready), entity.id)
    }
}

@Composable
private fun VaultPlayer(uri: Uri, key: Long) {
    var controls by remember { mutableStateOf(true) }
    VideoPlayer(
        uri = uri,
        key = key,
        controlsVisible = controls,
        onToggleControls = { controls = !controls },
    )
}
