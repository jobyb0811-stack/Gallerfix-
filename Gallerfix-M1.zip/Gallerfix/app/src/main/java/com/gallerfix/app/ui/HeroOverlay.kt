package com.gallerfix.app.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.util.lerp
import kotlinx.coroutines.launch

/**
 * Makes the viewer grow out of the thumbnail you tapped, and shrink back into the right thumbnail
 * when you leave. [content] receives a `close` function to call instead of closing directly.
 */
@Composable
fun HeroOverlay(
    openOrigin: Rect?,
    closeOrigin: () -> Rect?,
    rootSize: IntSize,
    onClosed: () -> Unit,
    content: @Composable (close: () -> Unit) -> Unit,
) {
    val progress = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    var origin by remember { mutableStateOf(openOrigin) }
    var closing by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        progress.animateTo(1f, tween(360, easing = FastOutSlowInEasing))
    }

    val close: () -> Unit = {
        if (!closing) {
            closing = true
            origin = closeOrigin()
            scope.launch {
                progress.animateTo(0f, tween(280, easing = FastOutSlowInEasing))
                onClosed()
            }
        }
    }

    Box(
        Modifier
            .fillMaxSize()
            .graphicsLayer {
                val p = progress.value
                val o = origin
                val w = rootSize.width.toFloat()
                val h = rootSize.height.toFloat()
                if (o != null && w > 0f && h > 0f) {
                    val start = (o.width / w).coerceIn(0.05f, 1f)
                    val s = lerp(start, 1f, p)
                    scaleX = s
                    scaleY = s
                    translationX = (o.center.x - w / 2f) * (1f - p)
                    translationY = (o.center.y - h / 2f) * (1f - p)
                } else {
                    val s = lerp(0.88f, 1f, p)
                    scaleX = s
                    scaleY = s
                }
                alpha = (p * 1.7f).coerceIn(0f, 1f)
                clip = true
                shape = RoundedCornerShape(((1f - p) * 28.dp.toPx()).coerceAtLeast(0f))
            }
    ) {
        content(close)
    }
}
