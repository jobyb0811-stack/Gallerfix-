package com.gallerfix.app.ui

import android.content.Context
import android.content.ContextWrapper
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

/**
 * Uses the system prompt. Apps cannot demand a specific sensor: they can only say how strong the
 * biometric must be. The phone then decides whether it shows the fingerprint or the face scan.
 */
object BiometricAuth {
    private const val STRONG = BiometricManager.Authenticators.BIOMETRIC_STRONG
    private const val WEAK = BiometricManager.Authenticators.BIOMETRIC_WEAK
    private const val CREDENTIAL = BiometricManager.Authenticators.DEVICE_CREDENTIAL

    /** Any fingerprint, face or the screen lock. */
    const val ANY = WEAK or CREDENTIAL

    /** Step 1: a strong biometric (normally the fingerprint), or the screen lock if none is set up. */
    const val FINGERPRINT_STEP = STRONG or CREDENTIAL

    /** Step 2: a biometric prompt that includes face unlock, or the screen lock if none is set up. */
    const val FACE_STEP = WEAK or CREDENTIAL

    /** Only the PIN, pattern or password. */
    const val SCREEN_LOCK_ONLY = CREDENTIAL

    fun availability(context: Context, authenticators: Int = ANY): Int =
        BiometricManager.from(context).canAuthenticate(authenticators)

    fun isAvailable(context: Context, authenticators: Int = ANY): Boolean =
        availability(context, authenticators) == BiometricManager.BIOMETRIC_SUCCESS

    /**
     * [onResult] is called once with true on success, false on cancel or error.
     * [onUnavailable] is called first if the phone has nothing set up that can answer the prompt.
     */
    fun authenticate(
        activity: FragmentActivity,
        title: String,
        authenticators: Int = ANY,
        onUnavailable: () -> Unit = {},
        onResult: (Boolean) -> Unit,
    ) {
        if (!isAvailable(activity, authenticators)) {
            onUnavailable()
            onResult(false)
            return
        }
        var finished = false
        val callback = object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                if (!finished) {
                    finished = true
                    onResult(true)
                }
            }

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                if (!finished) {
                    finished = true
                    onResult(false)
                }
            }
            // onAuthenticationFailed (a wrong finger) keeps the prompt open, so nothing to do.
        }
        val prompt = BiometricPrompt(activity, ContextCompat.getMainExecutor(activity), callback)
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setAllowedAuthenticators(authenticators)
            .build()
        prompt.authenticate(info)
    }
}

fun Context.findFragmentActivity(): FragmentActivity? {
    var current: Context = this
    while (current is ContextWrapper) {
        if (current is FragmentActivity) return current
        current = current.baseContext
    }
    return null
}
