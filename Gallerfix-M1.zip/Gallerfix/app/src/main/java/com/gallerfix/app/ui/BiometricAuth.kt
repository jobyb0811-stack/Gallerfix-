package com.gallerfix.app.ui

import android.content.Context
import android.content.ContextWrapper
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

/**
 * Uses the system prompt. Android decides whether to offer fingerprint or face, based on what the
 * phone supports and what you enrolled. The screen lock (PIN/pattern/password) is the built-in backup.
 */
object BiometricAuth {
    private val AUTHENTICATORS =
        BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL

    fun availability(context: Context): Int =
        BiometricManager.from(context).canAuthenticate(AUTHENTICATORS)

    fun isAvailable(context: Context): Boolean =
        availability(context) == BiometricManager.BIOMETRIC_SUCCESS

    /**
     * [onResult] is called once with true on success, false on cancel or error.
     * [onUnavailable] is called first if the phone has no fingerprint, face or screen lock set up.
     */
    fun authenticate(
        activity: FragmentActivity,
        title: String,
        onUnavailable: () -> Unit = {},
        onResult: (Boolean) -> Unit,
    ) {
        if (!isAvailable(activity)) {
            onUnavailable()
            onResult(false)
            return
        }
        var finished = false
        val callback = object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                if (!finished) {
                    finished = true
                    onResult(true)
                }
            }

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                if (!finished) {
                    finished = true
                    onResult(false)
                }
            }
            // onAuthenticationFailed (a wrong finger) keeps the prompt open, so nothing to do.
        }
        val prompt = BiometricPrompt(activity, ContextCompat.getMainExecutor(activity), callback)
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setAllowedAuthenticators(AUTHENTICATORS)
            .build()
        prompt.authenticate(info)
    }
}

fun Context.findFragmentActivity(): FragmentActivity? {
    var current: Context = this
    while (current is ContextWrapper) {
        if (current is FragmentActivity) return current
        current = current.baseContext
    }
    return null
}
