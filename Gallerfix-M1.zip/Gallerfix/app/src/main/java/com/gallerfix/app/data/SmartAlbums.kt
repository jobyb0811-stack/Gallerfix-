package com.gallerfix.app.data

import com.gallerfix.app.data.db.GeoEntity
import java.time.Instant
import java.time.YearMonth
import java.time.ZoneId
import java.time.format.TextStyle
import java.util.Locale
import kotlin.math.abs
import kotlin.math.floor

/** section: 0 smart, 1 by year, 2 recent months, 3 folders, 4 places */
data class SmartAlbum(
    val id: String,
    val title: String,
    val subtitle: String,
    val items: List<MediaItem>,
    val section: Int,
    /** For places: the grid cell, used to save a name you choose. */
    val placeCell: String = "",
)

/**
 * Builds automatic albums from information already on the phone (folder names, dates, file sizes,
 * and GPS data inside your own photos). Nothing is sent anywhere and nothing is "looked up".
 */
object SmartAlbumBuilder {
    private const val CELL_DEGREES = 0.05 // roughly 5 km
    private const val MIN_PLACE_ITEMS = 3
    private const val BIG_FILE_BYTES = 20L * 1024 * 1024
    private const val DAY_MS = 24L * 60 * 60 * 1000

    fun build(
        all: List<MediaItem>,
        geo: List<GeoEntity>,
        placeNames: Map<String, String>,
        favorites: Set<Long>,
        nowMs: Long,
    ): List<SmartAlbum> {
        val out = ArrayList<SmartAlbum>()
        if (all.isEmpty()) return out
        val newestFirst = all.sortedByDescending { it.takenMs }

        fun add(id: String, title: String, section: Int, items: List<MediaItem>, extra: String = "", cell: String = "") {
            if (items.isNotEmpty()) {
                out.add(SmartAlbum(id, title, "${items.size} items$extra", items, section, cell))
            }
        }

        // ---- smart ----
        add("smart:favorites", "Favorites", 0, newestFirst.filter { it.id in favorites })
        add("smart:screenshots", "Screenshots", 0, newestFirst.filter { isScreenshot(it) })
        add(
            "smart:camera", "Camera", 0,
            newestFirst.filter { it.relativePath.startsWith("DCIM/Camera", ignoreCase = true) },
        )
        add("smart:recent", "Last 30 days", 0, newestFirst.filter { it.takenMs >= nowMs - 30 * DAY_MS })
        val big = all.filter { it.sizeBytes >= BIG_FILE_BYTES }.sortedByDescending { it.sizeBytes }.take(200)
        add("smart:big", "Biggest files", 0, big, " · ${formatSize(big.sumOf { it.sizeBytes })}")

        // ---- dates ----
        val zone = ZoneId.systemDefault()
        val dated = newestFirst.map { it to Instant.ofEpochMilli(it.takenMs).atZone(zone) }
        dated.groupBy { it.second.year }
            .toSortedMap(compareByDescending<Int> { it })
            .forEach { (year, list) -> add("year:$year", "$year", 1, list.map { it.first }) }

        val firstMonth = YearMonth.now(zone).minusMonths(23)
        dated.groupBy { YearMonth.from(it.second) }
            .filterKeys { it >= firstMonth }
            .toSortedMap(compareByDescending<YearMonth> { it })
            .forEach { (ym, list) ->
                val name = ym.month.getDisplayName(TextStyle.FULL, Locale.getDefault())
                add("month:$ym", "$name ${ym.year}", 2, list.map { it.first })
            }

        // ---- folders ----
        newestFirst.filter { it.bucket.isNotEmpty() }
            .groupBy { it.bucket }
            .entries.sortedByDescending { it.value.size }
            .forEach { (bucket, list) -> add("folder:$bucket", bucket, 3, list) }

        // ---- places (from GPS data inside photos) ----
        val located = HashMap<Long, GeoEntity>()
        for (row in geo) if (row.lat != null && row.lon != null) located[row.mediaId] = row
        if (located.isNotEmpty()) {
            val clusters = HashMap<String, MutableList<MediaItem>>()
            for (item in newestFirst) {
                val g = located[item.id] ?: continue
                if (item.isVideo) continue
                val key = cellKey(g.lat!!, g.lon!!)
                clusters.getOrPut(key) { ArrayList() }.add(item)
            }
            clusters.entries
                .filter { it.value.size >= MIN_PLACE_ITEMS }
                .sortedByDescending { it.value.size }
                .forEach { (key, list) ->
                    add("place:$key", placeNames[key] ?: defaultPlaceLabel(key), 4, list, cell = key)
                }
        }
        return out
    }

    private fun isScreenshot(item: MediaItem): Boolean =
        item.relativePath.contains("screenshot", ignoreCase = true) ||
            item.displayName.startsWith("Screenshot", ignoreCase = true)

    private fun cellKey(lat: Double, lon: Double): String =
        "${floor(lat / CELL_DEGREES).toInt()}:${floor(lon / CELL_DEGREES).toInt()}"

    private fun defaultPlaceLabel(key: String): String {
        val parts = key.split(":")
        val lat = ((parts.getOrNull(0)?.toIntOrNull() ?: 0) + 0.5) * CELL_DEGREES
        val lon = ((parts.getOrNull(1)?.toIntOrNull() ?: 0) + 0.5) * CELL_DEGREES
        return String.format(
            Locale.US, "Near %.2f°%s, %.2f°%s",
            abs(lat), if (lat >= 0) "N" else "S",
            abs(lon), if (lon >= 0) "E" else "W",
        )
    }

    fun formatSize(bytes: Long): String {
        val gb = bytes / (1024.0 * 1024.0 * 1024.0)
        return if (gb >= 1.0) {
            String.format(Locale.US, "%.1f GB", gb)
        } else {
            "${bytes / (1024 * 1024)} MB"
        }
    }
}
