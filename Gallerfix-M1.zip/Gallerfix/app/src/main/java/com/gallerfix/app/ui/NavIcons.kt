package com.gallerfix.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

/** Icons are drawn with Canvas so we need no icon library. */
@Composable
fun NavIcon(dest: Dest, color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier.size(24.dp)) {
        val s = size.minDimension
        val sw = s / 12f
        val stroke = Stroke(width = sw, cap = StrokeCap.Round, join = StrokeJoin.Round)
        when (dest) {
            Dest.Photos -> {
                drawRoundRect(
                    color = color,
                    topLeft = Offset(s * 0.1f, s * 0.18f),
                    size = Size(s * 0.8f, s * 0.64f),
                    cornerRadius = CornerRadius(s * 0.1f),
                    style = stroke,
                )
                drawCircle(color = color, radius = s * 0.07f, center = Offset(s * 0.34f, s * 0.38f))
                val hills = Path().apply {
                    moveTo(s * 0.14f, s * 0.74f)
                    lineTo(s * 0.4f, s * 0.52f)
                    lineTo(s * 0.58f, s * 0.68f)
                    lineTo(s * 0.7f, s * 0.58f)
                    lineTo(s * 0.86f, s * 0.74f)
                }
                drawPath(hills, color, style = stroke)
            }
            Dest.Videos -> {
                drawRoundRect(
                    color = color,
                    topLeft = Offset(s * 0.1f, s * 0.18f),
                    size = Size(s * 0.8f, s * 0.64f),
                    cornerRadius = CornerRadius(s * 0.1f),
                    style = stroke,
                )
                val tri = Path().apply {
                    moveTo(s * 0.42f, s * 0.36f)
                    lineTo(s * 0.42f, s * 0.64f)
                    lineTo(s * 0.66f, s * 0.5f)
                    close()
                }
                drawPath(tri, color)
            }
            Dest.Albums -> {
                drawRoundRect(
                    color = color,
                    topLeft = Offset(s * 0.1f, s * 0.32f),
                    size = Size(s * 0.8f, s * 0.58f),
                    cornerRadius = CornerRadius(s * 0.1f),
                    style = stroke,
                )
                drawLine(color, Offset(s * 0.2f, s * 0.2f), Offset(s * 0.8f, s * 0.2f), strokeWidth = sw, cap = StrokeCap.Round)
                drawLine(color, Offset(s * 0.3f, s * 0.09f), Offset(s * 0.7f, s * 0.09f), strokeWidth = sw, cap = StrokeCap.Round)
            }
            Dest.Collage -> {
                val r = CornerRadius(s * 0.07f)
                drawRoundRect(color, Offset(s * 0.1f, s * 0.1f), Size(s * 0.38f, s * 0.5f), r)
                drawRoundRect(color, Offset(s * 0.52f, s * 0.1f), Size(s * 0.38f, s * 0.3f), r)
                drawRoundRect(color, Offset(s * 0.1f, s * 0.64f), Size(s * 0.38f, s * 0.26f), r)
                drawRoundRect(color, Offset(s * 0.52f, s * 0.44f), Size(s * 0.38f, s * 0.46f), r)
            }
            Dest.Settings -> {
                drawLine(color, Offset(s * 0.1f, s * 0.25f), Offset(s * 0.9f, s * 0.25f), strokeWidth = sw, cap = StrokeCap.Round)
                drawLine(color, Offset(s * 0.1f, s * 0.5f), Offset(s * 0.9f, s * 0.5f), strokeWidth = sw, cap = StrokeCap.Round)
                drawLine(color, Offset(s * 0.1f, s * 0.75f), Offset(s * 0.9f, s * 0.75f), strokeWidth = sw, cap = StrokeCap.Round)
                drawCircle(color, radius = s * 0.09f, center = Offset(s * 0.66f, s * 0.25f))
                drawCircle(color, radius = s * 0.09f, center = Offset(s * 0.34f, s * 0.5f))
                drawCircle(color, radius = s * 0.09f, center = Offset(s * 0.58f, s * 0.75f))
            }
        }
    }
}

@Composable
fun BackIcon(color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier.size(24.dp)) {
        val s = size.minDimension
        val p = Path().apply {
            moveTo(s * 0.64f, s * 0.2f)
            lineTo(s * 0.3f, s * 0.5f)
            lineTo(s * 0.64f, s * 0.8f)
        }
        drawPath(p, color, style = Stroke(width = s / 10f, cap = StrokeCap.Round, join = StrokeJoin.Round))
    }
}
