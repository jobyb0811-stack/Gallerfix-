package com.gallerfix.app.ui

import androidx.compose.runtime.compositionLocalOf

/** Ids of favourite items, available to every grid and viewer. */
val LocalFavorites = compositionLocalOf<Set<Long>> { emptySet() }
