package com.gallerfix.app.ui

import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.geometry.Rect

/** Ids of favourite items, available to every grid and viewer. */
val LocalFavorites = compositionLocalOf<Set<Long>> { emptySet() }

/** Remembers where each thumbnail is on screen, so the viewer can grow out of it and shrink back into it. */
class OriginTracker {
    /** Set by the visible grid: where on screen is this item's thumbnail right now (or null). */
    var lookup: (Long) -> Rect? = { null }
}

val LocalOrigins = staticCompositionLocalOf { OriginTracker() }
