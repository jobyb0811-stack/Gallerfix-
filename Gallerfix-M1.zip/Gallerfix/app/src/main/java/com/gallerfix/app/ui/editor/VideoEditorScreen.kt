package com.gallerfix.app.ui.editor

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.MediaStore
import android.view.LayoutInflater
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RangeSlider
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem as ExoMediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.effect.Brightness
import androidx.media3.effect.Contrast
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.Presentation
import androidx.media3.effect.ScaleAndRotateTransformation
import androidx.media3.effect.SpeedChangeEffect
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.ui.PlayerView
import com.gallerfix.app.R
import com.gallerfix.app.data.MediaItem
import com.gallerfix.app.ui.BackIcon
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val SPEEDS = listOf(0.25f, 0.5f, 0.75f, 1f, 1.5f, 2f, 3f, 4f)
private val ASPECTS = listOf("Original" to 0f, "1:1" to 1f, "4:5" to 0.8f, "9:16 story" to 0.5625f, "16:9" to 1.7778f)
private val TOOLS = listOf("Trim", "Speed", "Crop", "Colour", "Audio")

private fun clock(ms: Long): String {
    val total = ms / 1000
    return "%d:%02d".format(total / 60, total % 60)
}

/**
 * Video editor. Works on a copy: your original is never changed. The finished video is saved
 * to Movies/Gallerfix. Everything happens on the phone.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoEditorScreen(item: MediaItem, onClose: () -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val duration = item.durationMs.coerceAtLeast(1000L)

    var tool by remember { mutableIntStateOf(0) }
    var trimStart by remember { mutableFloatStateOf(0f) }
    var trimEnd by remember { mutableFloatStateOf(duration.toFloat()) }
    var speedIndex by remember { mutableIntStateOf(3) }
    var aspectIndex by remember { mutableIntStateOf(0) }
    var quarter by remember { mutableIntStateOf(0) }
    var brightness by remember { mutableFloatStateOf(0f) }
    var contrast by remember { mutableFloatStateOf(0f) }
    var saturation by remember { mutableFloatStateOf(0f) }
    var mute by remember { mutableStateOf(false) }

    var exporting by remember { mutableStateOf(false) }
    var progress by remember { mutableIntStateOf(0) }
    var message by remember { mutableStateOf<String?>(null) }
    var showDiscard by remember { mutableStateOf(false) }
    var shareMenu by remember { mutableStateOf(false) }
    var transformer by remember { mutableStateOf<Transformer?>(null) }

    val dirty = trimStart > 0f || trimEnd < duration || speedIndex != 3 || aspectIndex != 0 ||
        quarter != 0 || brightness != 0f || contrast != 0f || saturation != 0f || mute

    // ---------------- preview player (shows trim and speed)
    val exo = remember(item.id) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(ExoMediaItem.fromUri(item.uri))
            prepare()
            playWhenReady = true
        }
    }
    DisposableEffect(exo) { onDispose { exo.release() } }
    LaunchedEffect(exo, trimStart, trimEnd, speedIndex) {
        exo.setPlaybackSpeed(SPEEDS[speedIndex])
        val current = exo.currentPosition
        if (current < trimStart.toLong() || current > trimEnd.toLong()) exo.seekTo(trimStart.toLong())
        while (true) {
            if (exo.currentPosition >= trimEnd.toLong()) exo.seekTo(trimStart.toLong())
            delay(120)
        }
    }

    val frames by produceState<List<Bitmap>>(emptyList(), item.id) {
        value = withContext(Dispatchers.IO) {
            val retriever = MediaMetadataRetriever()
            try {
                retriever.setDataSource(context, item.uri)
                (0 until 8).mapNotNull { i ->
                    retriever.getScaledFrameAtTime(
                        duration * 1000L * i / 8,
                        MediaMetadataRetriever.OPTION_CLOSEST_SYNC,
                        160,
                        120,
                    )
                }
            } catch (e: Exception) {
                emptyList()
            } finally {
                retriever.release()
            }
        }
    }

    fun export(then: (Uri) -> Unit) {
        if (exporting) return
        exporting = true
        progress = 0
        message = null
        val clip = ExoMediaItem.Builder()
            .setUri(item.uri)
            .setClippingConfiguration(
                ExoMediaItem.ClippingConfiguration.Builder()
                    .setStartPositionMs(trimStart.toLong())
                    .setEndPositionMs(trimEnd.toLong())
                    .build()
            )
            .build()
        val speed = SPEEDS[speedIndex]
        val effects = ArrayList<Effect>()
        if (quarter != 0) {
            effects.add(ScaleAndRotateTransformation.Builder().setRotationDegrees(quarter * 90f).build())
        }
        val ratio = ASPECTS[aspectIndex].second
        if (ratio > 0f) {
            effects.add(Presentation.createForAspectRatio(ratio, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP))
        }
        if (brightness != 0f) effects.add(Brightness(brightness))
        if (contrast != 0f) effects.add(Contrast(contrast))
        if (saturation != 0f) effects.add(HslAdjustment.Builder().adjustSaturation(saturation * 100f).build())
        if (speed != 1f) effects.add(SpeedChangeEffect(speed))
        val audio = ArrayList<AudioProcessor>()
        if (speed != 1f && !mute) {
            val sonic = SonicAudioProcessor()
            sonic.setSpeed(speed)
            audio.add(sonic)
        }
        val edited = EditedMediaItem.Builder(clip)
            .setRemoveAudio(mute)
            .setEffects(Effects(audio, effects))
            .build()

        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val temp = File(context.cacheDir, "export_$stamp.mp4")
        val t = Transformer.Builder(context)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    scope.launch {
                        val uri = withContext(Dispatchers.IO) { saveVideo(context, temp, stamp) }
                        temp.delete()
                        exporting = false
                        transformer = null
                        if (uri != null) then(uri) else message = "Couldn't save. Your original is untouched."
                    }
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException,
                ) {
                    temp.delete()
                    exporting = false
                    transformer = null
                    message = "Couldn't make the video on this phone. Your original is untouched."
                }
            })
            .build()
        transformer = t
        try {
            t.start(edited, temp.absolutePath)
        } catch (e: Exception) {
            exporting = false
            transformer = null
            message = "Couldn't start. Your original is untouched."
        }
    }

    LaunchedEffect(exporting) {
        val holder = ProgressHolder()
        while (exporting) {
            val t = transformer
            if (t != null && t.getProgress(holder) == Transformer.PROGRESS_STATE_AVAILABLE) progress = holder.progress
            delay(300)
        }
    }

    BackHandler {
        if (exporting) {
            transformer?.cancel()
            exporting = false
        } else if (dirty) {
            showDiscard = true
        } else {
            onClose()
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(Color(0xFF0B0B0D))
            .systemBarsPadding()
    ) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { if (dirty) showDiscard = true else onClose() }) { BackIcon(Color.White) }
            Text("Edit video", color = Color.White, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            if (exporting) {
                CircularProgressIndicator(Modifier.size(22.dp), color = Color.White, strokeWidth = 2.dp)
                Text("  $progress%", color = Color.White)
                TextButton(onClick = {
                    transformer?.cancel()
                    exporting = false
                }) { Text("Cancel", color = Color(0xFFFF8A80)) }
            } else {
                TextButton(onClick = { export { message = "Saved to Movies/Gallerfix" } }) { Text("Save", color = Color.White) }
                Box {
                    TextButton(onClick = { shareMenu = true }) { Text("Share ▾", color = Color.White) }
                    DropdownMenu(expanded = shareMenu, onDismissRequest = { shareMenu = false }) {
                        DropdownMenuItem(
                            text = { Text("Share…") },
                            onClick = {
                                shareMenu = false
                                export { shareVideo(context, it, false) }
                            },
                        )
                        DropdownMenuItem(
                            text = { Text("Instagram") },
                            onClick = {
                                shareMenu = false
                                export { shareVideo(context, it, true) }
                            },
                        )
                    }
                }
            }
        }

        Box(Modifier.weight(1f).fillMaxWidth().padding(8.dp).clip(MaterialTheme.shapes.medium), contentAlignment = Alignment.Center) {
            AndroidView(
                factory = { ctx ->
                    (LayoutInflater.from(ctx).inflate(R.layout.view_player_texture, null, false) as PlayerView)
                        .also { it.player = exo }
                },
                update = { it.player = exo },
                modifier = Modifier.fillMaxSize(),
            )
        }

        if (message != null) {
            Text(message ?: "", color = Color(0xFFFFD166), style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(horizontal = 16.dp))
        }

        // ---------------- timeline: film strip with trim handles
        Column(Modifier.padding(horizontal = 12.dp)) {
            Box(Modifier.fillMaxWidth().height(54.dp).clip(MaterialTheme.shapes.small).background(Color(0xFF1A1A1D))) {
                Row(Modifier.fillMaxSize()) {
                    frames.forEach { f ->
                        Image(
                            f.asImageBitmap(),
                            null,
                            Modifier.weight(1f).fillMaxSize(),
                            contentScale = ContentScale.Crop,
                        )
                    }
                }
            }
            RangeSlider(
                value = trimStart..trimEnd,
                onValueChange = { range ->
                    trimStart = range.start
                    trimEnd = range.endInclusive.coerceAtLeast(range.start + 500f)
                },
                valueRange = 0f..duration.toFloat(),
            )
            Text(
                "${clock(trimStart.toLong())} – ${clock(trimEnd.toLong())}   ·   ${clock(((trimEnd - trimStart) / SPEEDS[speedIndex]).toLong())} long",
                color = Color.White,
                style = MaterialTheme.typography.labelMedium,
            )
        }

        Column(
            Modifier.fillMaxWidth().heightIn(max = 170.dp).verticalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 4.dp)
        ) {
            when (tool) {
                0 -> Text("Drag the two handles to keep only the part you want. The preview plays just that part.", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                1 -> Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SPEEDS.forEachIndexed { i, s ->
                        FilterChip(selected = speedIndex == i, onClick = { speedIndex = i }, label = { Text("${s}x") })
                    }
                }
                2 -> {
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ASPECTS.forEachIndexed { i, (name, _) ->
                            FilterChip(selected = aspectIndex == i, onClick = { aspectIndex = i }, label = { Text(name) })
                        }
                    }
                    Row {
                        TextButton(onClick = { quarter = (quarter + 3) % 4 }) { Text("⟲ Rotate left", color = Color.White) }
                        TextButton(onClick = { quarter = (quarter + 1) % 4 }) { Text("Rotate right ⟳", color = Color.White) }
                    }
                    Text("Crop and rotation are applied when you save.", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                }
                3 -> {
                    VSlider("Brightness", brightness, -0.5f..0.5f) { brightness = it }
                    VSlider("Contrast", contrast, -0.5f..0.5f) { contrast = it }
                    VSlider("Saturation", saturation, -1f..1f) { saturation = it }
                    Text("Colour changes are applied when you save.", color = Color.Gray, style = MaterialTheme.typography.bodySmall)
                }
                else -> Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Remove the sound", color = Color.White, modifier = Modifier.weight(1f))
                    Switch(checked = mute, onCheckedChange = { mute = it })
                }
            }
        }

        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            TOOLS.forEachIndexed { i, name ->
                FilterChip(selected = tool == i, onClick = { tool = i }, label = { Text(name) })
            }
        }
    }

    if (showDiscard) {
        AlertDialog(
            onDismissRequest = { showDiscard = false },
            title = { Text("Discard your changes?") },
            text = { Text("Your original video is not affected.") },
            confirmButton = { TextButton(onClick = onClose) { Text("Discard") } },
            dismissButton = { TextButton(onClick = { showDiscard = false }) { Text("Keep editing") } },
        )
    }
}

@Composable
private fun VSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, style = MaterialTheme.typography.labelMedium, modifier = Modifier.width(84.dp))
        Slider(value = value, onValueChange = onChange, valueRange = range, modifier = Modifier.weight(1f))
    }
}

/** Copies the finished file into the gallery (Movies/Gallerfix). */
private fun saveVideo(context: Context, file: File, stamp: String): Uri? {
    val values = ContentValues().apply {
        put(MediaStore.MediaColumns.DISPLAY_NAME, "Video_$stamp.mp4")
        put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
        put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/Gallerfix")
        put(MediaStore.MediaColumns.IS_PENDING, 1)
    }
    val resolver = context.contentResolver
    val uri = resolver.insert(MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY), values) ?: return null
    return try {
        resolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } }
            ?: throw java.io.IOException("no stream")
        values.clear()
        values.put(MediaStore.MediaColumns.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
        uri
    } catch (e: Exception) {
        resolver.delete(uri, null, null)
        null
    }
}

private fun shareVideo(context: Context, uri: Uri, instagram: Boolean) {
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "video/mp4"
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    if (instagram) {
        try {
            context.startActivity(Intent(intent).setPackage("com.instagram.android"))
            return
        } catch (e: Exception) {
            // not installed: use the normal share sheet
        }
    }
    try {
        context.startActivity(Intent.createChooser(intent, "Share"))
    } catch (e: Exception) {
        // nothing can handle it
    }
}
