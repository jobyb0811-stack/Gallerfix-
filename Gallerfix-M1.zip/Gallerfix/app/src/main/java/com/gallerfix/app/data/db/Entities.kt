package com.gallerfix.app.data.db

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "albums")
data class AlbumEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val createdAt: Long,
)

@Entity(
    tableName = "album_items",
    primaryKeys = ["albumId", "mediaId", "isVideo"],
    foreignKeys = [
        ForeignKey(
            entity = AlbumEntity::class,
            parentColumns = ["id"],
            childColumns = ["albumId"],
            onDelete = ForeignKey.CASCADE,
        )
    ],
    indices = [Index("albumId")],
)
data class AlbumItemEntity(
    val albumId: Long,
    val mediaId: Long,
    val isVideo: Boolean,
    val addedAt: Long,
)

/** One row per media item the user has swiped on in Sort. */
@Entity(tableName = "triage", primaryKeys = ["mediaId", "isVideo"])
data class TriageEntity(
    val mediaId: Long,
    val isVideo: Boolean,
    val decision: Int,
    val decidedAt: Long,
)

object Decision {
    const val KEEP = 0
    const val TRASH = 1
}

/**
 * One encrypted item in the private library. The encrypted bytes live in the app's private storage;
 * this row is the journal that makes moving in/out recoverable.
 *
 * state: 0 = copied in, original may still be in the gallery; 1 = original removed (safe).
 */
@Entity(tableName = "vault_items")
data class VaultEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val displayName: String,
    val mimeType: String,
    val isVideo: Boolean,
    val sizeBytes: Long,
    val dateAdded: Long,
    val durationMs: Long,
    val blobName: String,
    val thumbName: String,
    val state: Int,
    val originalUri: String,
    val createdAt: Long,
)
