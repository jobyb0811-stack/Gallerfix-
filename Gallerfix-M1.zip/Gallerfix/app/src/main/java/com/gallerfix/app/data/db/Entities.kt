package com.gallerfix.app.data.db

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "albums")
data class AlbumEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val createdAt: Long,
)

@Entity(
    tableName = "album_items",
    primaryKeys = ["albumId", "mediaId", "isVideo"],
    foreignKeys = [
        ForeignKey(
            entity = AlbumEntity::class,
            parentColumns = ["id"],
            childColumns = ["albumId"],
            onDelete = ForeignKey.CASCADE,
        )
    ],
    indices = [Index("albumId")],
)
data class AlbumItemEntity(
    val albumId: Long,
    val mediaId: Long,
    val isVideo: Boolean,
    val addedAt: Long,
)

/** One row per media item the user has swiped on in Sort. */
@Entity(tableName = "triage", primaryKeys = ["mediaId", "isVideo"])
data class TriageEntity(
    val mediaId: Long,
    val isVideo: Boolean,
    val decision: Int,
    val decidedAt: Long,
)

object Decision {
    const val KEEP = 0
    const val TRASH = 1
}
