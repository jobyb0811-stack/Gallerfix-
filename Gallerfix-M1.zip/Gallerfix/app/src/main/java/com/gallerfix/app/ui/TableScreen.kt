package com.gallerfix.app.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.util.lerp
import androidx.compose.ui.zIndex
import coil.ImageLoader
import coil.compose.AsyncImage
import com.gallerfix.app.data.GRID_THUMB
import com.gallerfix.app.data.MediaItem
import com.gallerfix.app.data.MediaThumb
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.random.Random

private val CARD_W = 84.dp
private val CARD_H = 104.dp
private const val TABLE_SIZE = 10

/** One photo lying on the table. */
class TableCard(val item: MediaItem, x0: Float, y0: Float, tilt0: Float) {
    var x by mutableFloatStateOf(x0)
    var y by mutableFloatStateOf(y0)
    var tilt by mutableFloatStateOf(tilt0)
    var z by mutableFloatStateOf(0f)
    var scale by mutableFloatStateOf(1f)
    var alpha by mutableFloatStateOf(1f)
    /** 0 = still in the deck, 1 = dealt onto the table. */
    var dealt by mutableFloatStateOf(0f)
}

/**
 * Photos are dealt onto a table. Make albums first, then drag photos from the table into them.
 * A new photo is dealt every time one is placed. There is no trash here.
 */
@Composable
fun TableScreen(
    photos: List<MediaItem>,
    albums: List<AlbumUi>,
    imageLoader: ImageLoader,
    haptics: Haptics,
    hapticLevel: Int,
    onCreateAlbum: (String) -> Unit,
    onAddToAlbum: (Long, MediaItem) -> Unit,
    onPreview: (List<MediaItem>, MediaItem) -> Unit,
) {
    val density = LocalDensity.current
    val scope = rememberCoroutineScope()
    val level by rememberUpdatedState(hapticLevel)
    val cardW = with(density) { CARD_W.toPx() }
    val cardH = with(density) { CARD_H.toPx() }

    val photosNow by rememberUpdatedState(photos)
    val inAlbum = remember(albums) { albums.flatMap { album -> album.items.map { it.id } }.toHashSet() }
    val inAlbumNow by rememberUpdatedState(inAlbum)

    val cards = remember { mutableStateListOf<TableCard>() }
    var tableSize by remember { mutableStateOf(IntSize.Zero) }
    var tableOrigin by remember { mutableStateOf(Offset.Zero) }
    val binRects = remember { mutableStateMapOf<Long, Rect>() }
    var hoverId by remember { mutableStateOf<Long?>(null) }
    var zCounter by remember { mutableFloatStateOf(1f) }
    var creating by remember { mutableStateOf(false) }
    var deck by remember { mutableIntStateOf(0) }

    val ready = albums.isNotEmpty() && tableSize.width > 0

    fun pickPhoto(): MediaItem? {
        val source = photosNow
        if (source.isEmpty()) return null
        repeat(80) {
            val candidate = source[Random.nextInt(source.size)]
            if (candidate.id !in inAlbumNow && cards.none { it.item.id == candidate.id }) return candidate
        }
        return null
    }

    fun deal(count: Int) {
        val maxX = max(tableSize.width - cardW, 0f)
        val maxY = max(tableSize.height - cardH, 0f)
        repeat(count) { n ->
            val photo = pickPhoto() ?: return
            val card = TableCard(
                item = photo,
                x0 = Random.nextFloat() * maxX,
                y0 = Random.nextFloat() * maxY,
                tilt0 = Random.nextFloat() * 28f - 14f,
            )
            cards.add(card)
            scope.launch {
                delay(n * 45L)
                animate(0f, 1f, animationSpec = spring(dampingRatio = 0.75f, stiffness = 300f)) { v, _ ->
                    card.dealt = v
                }
            }
        }
    }

    // The next deck is dealt only once every card of this one has been placed.
    LaunchedEffect(ready, cards.size, photos.size) {
        if (ready && cards.isEmpty()) {
            delay(450)
            if (cards.isEmpty()) {
                deal(TABLE_SIZE)
                if (cards.isNotEmpty()) deck += 1
            }
        }
    }

    /** Throws the cards you still have back across the table. */
    fun shuffle() {
        val maxX = max(tableSize.width - cardW, 0f)
        val maxY = max(tableSize.height - cardH, 0f)
        cards.toList().forEach { card ->
            val x0 = card.x
            val y0 = card.y
            val t0 = card.tilt
            val tx = Random.nextFloat() * maxX
            val ty = Random.nextFloat() * maxY
            val tt = Random.nextFloat() * 28f - 14f
            scope.launch {
                animate(0f, 1f, animationSpec = tween(480, easing = FastOutSlowInEasing)) { v, _ ->
                    card.x = lerp(x0, tx, v)
                    card.y = lerp(y0, ty, v)
                    card.tilt = lerp(t0, tt, v)
                }
            }
        }
    }

    fun tidy() {
        val columns = 3
        val gapX = (tableSize.width - columns * cardW) / (columns + 1)
        val rows = (cards.size + columns - 1) / columns
        val gapY = (tableSize.height - rows * cardH) / (rows + 1)
        cards.toList().forEachIndexed { i, card ->
            val tx = gapX + (i % columns) * (cardW + gapX)
            val ty = gapY + (i / columns) * (cardH + gapY)
            val x0 = card.x
            val y0 = card.y
            val t0 = card.tilt
            scope.launch {
                animate(0f, 1f, animationSpec = tween(420, easing = FastOutSlowInEasing)) { v, _ ->
                    card.x = lerp(x0, tx, v)
                    card.y = lerp(y0, ty, v)
                    card.tilt = lerp(t0, 0f, v)
                }
            }
        }
    }

    fun finishDrag(card: TableCard) {
        val target = hoverId
        hoverId = null
        val rect = if (target != null) binRects[target] else null
        if (target == null || rect == null) {
            card.scale = 1f
            card.tilt = Random.nextFloat() * 24f - 12f
            return
        }
        scope.launch {
            val tx = rect.center.x - tableOrigin.x - cardW / 2f
            val ty = rect.center.y - tableOrigin.y - cardH / 2f
            val x0 = card.x
            val y0 = card.y
            val s0 = card.scale
            haptics.drop(level)
            animate(0f, 1f, animationSpec = tween(260, easing = FastOutSlowInEasing)) { t, _ ->
                card.x = lerp(x0, tx, t)
                card.y = lerp(y0, ty, t)
                card.scale = lerp(s0, 0.15f, t)
                card.alpha = 1f - t
            }
            cards.remove(card)
            onAddToAlbum(target, card.item)
        }
    }

    Column(Modifier.fillMaxSize()) {
        HeaderBar("Table") {
            TextButton(onClick = { shuffle() }, enabled = ready) { Text("Shuffle") }
            TextButton(onClick = { tidy() }, enabled = ready && cards.isNotEmpty()) { Text("Tidy") }
        }
        Text(
            text = when {
                albums.isEmpty() -> "Start by making an album. Then photos are dealt onto the table for you to sort."
                cards.isEmpty() -> "Deck finished. The next one is on its way."
                else -> "Deck $deck · ${cards.size} left. Drag a photo onto an album, or tap one to preview it."
            },
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(horizontal = 16.dp),
        )

        Box(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(12.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                .onSizeChanged { tableSize = it }
                .onGloballyPositioned { tableOrigin = it.positionInRoot() }
        ) {
            if (albums.isEmpty()) {
                Column(
                    Modifier.align(Alignment.Center).padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    Text(
                        "The table is empty",
                        style = MaterialTheme.typography.titleMedium,
                        textAlign = TextAlign.Center,
                    )
                    Text(
                        "Create your first album below, then drag photos into it.",
                        style = MaterialTheme.typography.bodyMedium,
                        textAlign = TextAlign.Center,
                    )
                    Button(onClick = { creating = true }) { Text("New album") }
                }
            }

            cards.forEach { card ->
                key(card.item.id) {
                    Box(
                        Modifier
                            .offset {
                                val p = card.dealt
                                val cx = (tableSize.width - cardW) / 2f
                                val cy = (tableSize.height - cardH) / 2f
                                IntOffset(
                                    (cx + (card.x - cx) * p).roundToInt(),
                                    (cy + (card.y - cy) * p).roundToInt(),
                                )
                            }
                            .zIndex(card.z)
                            .size(CARD_W, CARD_H)
                            .pointerInput(card) {
                                detectTapGestures(onTap = {
                                    onPreview(cards.map { it.item }, card.item)
                                })
                            }
                            .pointerInput(card) {
                                detectDragGestures(
                                    onDragStart = {
                                        zCounter += 1f
                                        card.z = zCounter
                                        card.scale = 1.1f
                                        card.tilt = 0f
                                    },
                                    onDrag = { change, delta ->
                                        change.consume()
                                        card.x += delta.x
                                        card.y += delta.y
                                        val root = tableOrigin + Offset(card.x, card.y) + change.position
                                        val hit = binRects.entries.firstOrNull { it.value.contains(root) }?.key
                                        if (hit != hoverId) {
                                            hoverId = hit
                                            if (hit != null) haptics.hover(level)
                                        }
                                    },
                                    onDragEnd = { finishDrag(card) },
                                    onDragCancel = { finishDrag(card) },
                                )
                            }
                            .graphicsLayer {
                                rotationZ = card.tilt * card.dealt
                                val s = card.scale * (0.6f + 0.4f * card.dealt)
                                scaleX = s
                                scaleY = s
                                alpha = card.alpha * card.dealt
                            }
                            .background(Color.White, RoundedCornerShape(6.dp))
                            .padding(4.dp)
                            .clip(RoundedCornerShape(3.dp))
                    ) {
                        AsyncImage(
                            model = MediaThumb(card.item.uri, GRID_THUMB),
                            imageLoader = imageLoader,
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize(),
                        )
                    }
                }
            }
        }

        LazyRow(
            modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp),
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(albums, key = { it.id }) { album ->
                AlbumBin(
                    album = album,
                    hovered = hoverId == album.id,
                    imageLoader = imageLoader,
                    onBounds = { binRects[album.id] = it },
                )
            }
            item(key = "new") {
                Column(
                    Modifier.width(84.dp).clickable { creating = true },
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Box(
                        Modifier
                            .size(72.dp)
                            .clip(RoundedCornerShape(16.dp))
                            .border(1.5.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp)),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text("+", style = MaterialTheme.typography.headlineMedium)
                    }
                    Text(
                        "New album",
                        style = MaterialTheme.typography.labelMedium,
                        maxLines = 1,
                        modifier = Modifier.padding(top = 4.dp),
                    )
                }
            }
        }
    }

    if (creating) {
        NameDialog(
            title = "New album",
            initial = "",
            confirmLabel = "Create",
            onConfirm = {
                onCreateAlbum(it)
                creating = false
            },
            onDismiss = { creating = false },
        )
    }
}

@Composable
private fun AlbumBin(
    album: AlbumUi,
    hovered: Boolean,
    imageLoader: ImageLoader,
    onBounds: (Rect) -> Unit,
) {
    val grow by animateFloatAsState(if (hovered) 1.14f else 1f, label = "binGrow")
    val primary = MaterialTheme.colorScheme.primary
    Column(Modifier.width(84.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier
                .size(72.dp)
                .onGloballyPositioned { onBounds(it.boundsInRoot()) }
                .graphicsLayer {
                    scaleX = grow
                    scaleY = grow
                }
                .clip(RoundedCornerShape(16.dp))
                .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                .border(
                    width = if (hovered) 3.dp else 1.dp,
                    color = if (hovered) primary else MaterialTheme.colorScheme.outlineVariant,
                    shape = RoundedCornerShape(16.dp),
                ),
            contentAlignment = Alignment.Center,
        ) {
            val cover = album.items.firstOrNull()
            if (cover != null) {
                AsyncImage(
                    model = MediaThumb(cover.uri, GRID_THUMB),
                    imageLoader = imageLoader,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )
            } else {
                Text(
                    album.name.take(1).uppercase(),
                    style = MaterialTheme.typography.headlineSmall,
                    color = primary,
                )
            }
        }
        Text(
            album.name,
            style = MaterialTheme.typography.labelMedium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 4.dp),
        )
        Text("${album.items.size}", style = MaterialTheme.typography.bodySmall)
    }
}
