package com.gallerfix.app.data

import android.net.Uri

data class MediaItem(
    val id: Long,
    val uri: Uri,
    val displayName: String,
    val dateAddedSeconds: Long,
    val isVideo: Boolean = false,
    val durationMs: Long = 0L,
)
