package com.gallerfix.app.data

import android.net.Uri

data class MediaItem(
    val id: Long,
    val uri: Uri,
    val displayName: String,
    val dateAddedSeconds: Long,
    val isVideo: Boolean = false,
    val durationMs: Long = 0L,
    /** True when the file lives on a memory card (any volume other than the phone's main storage). */
    val isSd: Boolean = false,
    val sizeBytes: Long = 0L,
    /** When the photo was taken (falls back to when it was added). Milliseconds. */
    val takenMs: Long = 0L,
    /** Folder name, e.g. "Camera" or "Screenshots". */
    val bucket: String = "",
    /** Folder path, e.g. "DCIM/Camera/". */
    val relativePath: String = "",
)
