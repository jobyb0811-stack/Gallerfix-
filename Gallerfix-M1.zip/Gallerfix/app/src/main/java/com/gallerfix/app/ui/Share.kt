package com.gallerfix.app.ui

import android.content.Context
import android.content.Intent
import com.gallerfix.app.data.MediaItem

/** Opens Android's share sheet. You choose where it goes; Gallerfix itself never sends anything. */
fun shareItems(context: Context, items: List<MediaItem>) {
    if (items.isEmpty()) return
    val intent = if (items.size == 1) {
        Intent(Intent.ACTION_SEND).apply {
            type = if (items[0].isVideo) "video/*" else "image/*"
            putExtra(Intent.EXTRA_STREAM, items[0].uri)
        }
    } else {
        Intent(Intent.ACTION_SEND_MULTIPLE).apply {
            type = when {
                items.all { it.isVideo } -> "video/*"
                items.none { it.isVideo } -> "image/*"
                else -> "*/*"
            }
            putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList(items.map { it.uri }))
        }
    }
    intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    try {
        context.startActivity(Intent.createChooser(intent, "Share"))
    } catch (e: Exception) {
        // No app can handle it: nothing to do.
    }
}
