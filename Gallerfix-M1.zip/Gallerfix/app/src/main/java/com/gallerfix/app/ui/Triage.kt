package com.gallerfix.app.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.dp
import coil.ImageLoader
import coil.compose.AsyncImage
import com.gallerfix.app.data.MediaItem
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

const val TRASH_BATCH = 500

/** How far you must drag, as a fraction of the screen width. Small, so a short swipe is enough. */
private const val SWIPE_FRACTION = 0.13f

/** A quick flick (pixels per second) decides even if you barely moved. */
private const val FLICK_VELOCITY = 700f

@Composable
fun TriageScreen(
    state: TriageUi,
    canUndo: Boolean,
    imageLoader: ImageLoader,
    onDecide: (MediaItem, Boolean) -> Unit,
    onUndo: () -> Unit,
    onReview: () -> Unit,
    onClearQueue: () -> Unit,
    onDone: () -> Unit,
) {
    val current = state.remaining.firstOrNull()
    val next = state.remaining.getOrNull(1)
    // Set by the buttons; the card plays its animation and then reports the decision.
    var command by remember { mutableStateOf(0) }

    Column(Modifier.fillMaxSize()) {
        HeaderBar("Sort") {
            TextButton(onClick = onDone) { Text("Done") }
        }
        Text(
            text = "${state.remaining.size} left · ${state.queued.size} queued for trash",
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(horizontal = 16.dp),
        )
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when {
                current != null -> key(current.id) {
                    SwipeCard(
                        item = current,
                        next = next,
                        imageLoader = imageLoader,
                        command = command,
                        onDecided = { trash ->
                            command = 0
                            onDecide(current, trash)
                        },
                    )
                }
                !state.loaded -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                else -> MessageState(
                    title = "All sorted",
                    body = "There is nothing left to review. New photos will show up here automatically.",
                ) {}
            }
        }
        Text(
            text = "Swipe right to keep · swipe left to trash",
            style = MaterialTheme.typography.labelMedium,
            modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 4.dp),
        )
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            OutlinedButton(
                onClick = { if (command == 0) command = 2 },
                enabled = current != null,
            ) { Text("Trash") }
            TextButton(onClick = onUndo, enabled = canUndo) { Text("Undo") }
            Button(
                onClick = { if (command == 0) command = 1 },
                enabled = current != null,
            ) { Text("Keep") }
        }
        if (state.queued.isNotEmpty()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Button(onClick = onReview) {
                    Text("Move ${minOf(TRASH_BATCH, state.queued.size)} to trash")
                }
                TextButton(onClick = onClearQueue) { Text("Clear queue") }
            }
        }
    }
}

@Composable
private fun SwipeCard(
    item: MediaItem,
    next: MediaItem?,
    imageLoader: ImageLoader,
    command: Int,
    onDecided: (trash: Boolean) -> Unit,
) {
    val haptics = LocalHapticFeedback.current
    val scope = rememberCoroutineScope()
    val dragX = remember { Animatable(0f) }
    val exit = remember { Animatable(0f) }
    var exitType by remember { mutableStateOf(0) } // 0 none, 1 keep, 2 trash
    var widthPx by remember { mutableFloatStateOf(1f) }
    var heightPx by remember { mutableFloatStateOf(1f) }

    suspend fun runExit(trash: Boolean) {
        if (exitType != 0) return
        exitType = if (trash) 2 else 1
        haptics.performHapticFeedback(
            if (trash) HapticFeedbackType.LongPress else HapticFeedbackType.TextHandleMove
        )
        exit.animateTo(1f, tween(if (trash) 480 else 400, easing = FastOutSlowInEasing))
        onDecided(trash)
    }

    LaunchedEffect(command) {
        if (command != 0) runExit(command == 2)
    }

    val dragState = rememberDraggableState { delta ->
        scope.launch { dragX.snapTo(dragX.value + delta) }
    }
    val e = exit.value
    val progress = when (exitType) {
        1 -> 1f
        2 -> -1f
        else -> (dragX.value / (widthPx * SWIPE_FRACTION)).coerceIn(-1f, 1f)
    }

    Box(
        Modifier
            .fillMaxSize()
            .onSizeChanged {
                widthPx = it.width.toFloat().coerceAtLeast(1f)
                heightPx = it.height.toFloat().coerceAtLeast(1f)
            }
            .draggable(
                state = dragState,
                orientation = Orientation.Horizontal,
                enabled = exitType == 0,
                onDragStopped = { velocity ->
                    val x = dragX.value
                    val limit = widthPx * SWIPE_FRACTION
                    val flick = abs(velocity) > FLICK_VELOCITY && abs(x) > 10f && velocity * x > 0f
                    if (abs(x) > limit || flick) {
                        runExit(trash = x < 0f)
                    } else {
                        dragX.animateTo(0f, spring(dampingRatio = 0.6f, stiffness = 500f))
                    }
                },
            )
    ) {
        // The next photo waits behind and grows into place as this one leaves.
        if (next != null) {
            Box(
                Modifier
                    .fillMaxSize()
                    .padding(16.dp)
                    .graphicsLayer {
                        val s = 0.94f + 0.06f * exit.value
                        scaleX = s
                        scaleY = s
                        alpha = 0.7f + 0.3f * exit.value
                    }
            ) { CardFace(next, imageLoader, showStamp = 0f) }
        }

        Box(
            Modifier
                .fillMaxSize()
                .padding(16.dp)
                .graphicsLayer {
                    val x = dragX.value
                    val p = exit.value
                    when (exitType) {
                        1 -> { // keep: sails off to the right
                            translationX = x + p * widthPx * 1.3f
                            translationY = -p * heightPx * 0.04f
                            rotationZ = x / widthPx * 12f + p * 14f
                            val s = 1f + 0.05f * sin(PI * p).toFloat()
                            scaleX = s
                            scaleY = s
                            alpha = 1f - ((p - 0.5f) / 0.5f).coerceIn(0f, 1f)
                        }
                        2 -> { // trash: spins and shrinks down into the bin
                            translationX = x * (1f - p)
                            translationY = p * heightPx * 0.22f
                            rotationZ = x / widthPx * 12f * (1f - p) - p * 28f
                            val s = 1f - 0.88f * p
                            scaleX = s
                            scaleY = s
                            alpha = 1f - ((p - 0.7f) / 0.3f).coerceIn(0f, 1f)
                        }
                        else -> {
                            translationX = x
                            rotationZ = x / widthPx * 12f
                        }
                    }
                }
        ) { CardFace(item, imageLoader, showStamp = progress) }

        if (exitType == 1) KeepBurst(e)
        if (exitType == 2) TrashBin(e)
    }
}

@Composable
private fun CardFace(item: MediaItem, imageLoader: ImageLoader, showStamp: Float) {
    Box(
        Modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(24.dp))
            .background(MaterialTheme.colorScheme.surfaceContainerHigh)
    ) {
        AsyncImage(
            model = item.uri,
            imageLoader = imageLoader,
            contentDescription = null,
            contentScale = ContentScale.Fit,
            modifier = Modifier.fillMaxSize(),
        )
        if (item.isVideo) {
            Text(
                text = "Video",
                color = Color.White,
                style = MaterialTheme.typography.labelMedium,
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(12.dp)
                    .background(Color.Black.copy(alpha = 0.55f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 3.dp),
            )
        }
        if (showStamp > 0.02f) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color(0xFF2E7D32).copy(alpha = 0.35f * showStamp))
            )
            Text(
                text = "KEEP",
                color = Color.White,
                style = MaterialTheme.typography.headlineMedium,
                modifier = Modifier.align(Alignment.TopStart).padding(20.dp),
            )
        } else if (showStamp < -0.02f) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color(0xFFC62828).copy(alpha = 0.35f * -showStamp))
            )
            Text(
                text = "TRASH",
                color = Color.White,
                style = MaterialTheme.typography.headlineMedium,
                modifier = Modifier.align(Alignment.TopEnd).padding(20.dp),
            )
        }
    }
}

private fun mix(a: Offset, b: Offset, f: Float): Offset =
    Offset(a.x + (b.x - a.x) * f, a.y + (b.y - a.y) * f)

/** Keep: a green seal pops in, a ring ripples out, the tick draws itself, and gold sparks fly. */
@Composable
private fun KeepBurst(p: Float) {
    Canvas(Modifier.fillMaxSize()) {
        val c = center
        val grow = FastOutSlowInEasing.transform(min(1f, p * 1.6f))
        val r = size.minDimension * 0.17f * grow
        val green = Color(0xFF2E7D32)
        val fade = 1f - ((p - 0.75f) / 0.25f).coerceIn(0f, 1f)

        drawCircle(
            color = green.copy(alpha = 0.35f * (1f - p) * fade),
            radius = size.minDimension * 0.45f * grow,
            center = c,
        )
        drawCircle(color = green.copy(alpha = 0.95f * fade), radius = r, center = c)

        val t = ((p - 0.1f) / 0.5f).coerceIn(0f, 1f)
        if (t > 0f) {
            val a = Offset(c.x - r * 0.45f, c.y + r * 0.02f)
            val b = Offset(c.x - r * 0.12f, c.y + r * 0.36f)
            val d = Offset(c.x + r * 0.5f, c.y - r * 0.32f)
            val width = r * 0.18f
            val first = (t / 0.4f).coerceIn(0f, 1f)
            drawLine(Color.White.copy(alpha = fade), a, mix(a, b, first), strokeWidth = width, cap = StrokeCap.Round)
            val second = ((t - 0.4f) / 0.6f).coerceIn(0f, 1f)
            if (second > 0f) {
                drawLine(Color.White.copy(alpha = fade), b, mix(b, d, second), strokeWidth = width, cap = StrokeCap.Round)
            }
        }

        for (i in 0 until 10) {
            val angle = i * 36f * (PI.toFloat() / 180f)
            val dist = size.minDimension * 0.42f * grow
            drawCircle(
                color = Color(0xFFFFD166).copy(alpha = (1f - p).coerceIn(0f, 1f)),
                radius = 7f * (1f - p) + 2f,
                center = Offset(c.x + cos(angle) * dist, c.y + sin(angle) * dist),
            )
        }
    }
}

/** Trash: a bin pops up, its lid swings open as the photo drops in, then closes. */
@Composable
private fun TrashBin(p: Float) {
    Canvas(Modifier.fillMaxSize()) {
        val appear = FastOutSlowInEasing.transform(min(1f, p * 3f))
        val fade = 1f - ((p - 0.85f) / 0.15f).coerceIn(0f, 1f)
        val bw = size.minDimension * 0.22f
        val bh = bw * 1.15f
        val cx = size.width / 2f
        val baseY = size.height * 0.78f
        val red = Color(0xFFC62828).copy(alpha = fade)

        drawRect(Color(0xFFC62828).copy(alpha = 0.16f * (1f - p)))

        scale(appear, pivot = Offset(cx, baseY)) {
            val body = Path().apply {
                moveTo(cx - bw / 2f, baseY - bh)
                lineTo(cx + bw / 2f, baseY - bh)
                lineTo(cx + bw * 0.4f, baseY)
                lineTo(cx - bw * 0.4f, baseY)
                close()
            }
            drawPath(body, red)
            for (k in -1..1) {
                drawLine(
                    color = Color.White.copy(alpha = 0.7f * fade),
                    start = Offset(cx + k * bw * 0.2f, baseY - bh * 0.8f),
                    end = Offset(cx + k * bw * 0.17f, baseY - bh * 0.12f),
                    strokeWidth = bw * 0.05f,
                    cap = StrokeCap.Round,
                )
            }
            val lid = 38f * sin(PI * ((p - 0.1f) / 0.8f).coerceIn(0f, 1f)).toFloat()
            rotate(-lid, pivot = Offset(cx - bw * 0.55f, baseY - bh)) {
                drawRoundRect(
                    color = red,
                    topLeft = Offset(cx - bw * 0.6f, baseY - bh - bw * 0.12f),
                    size = Size(bw * 1.2f, bw * 0.12f),
                    cornerRadius = CornerRadius(bw * 0.04f),
                )
                drawRoundRect(
                    color = red,
                    topLeft = Offset(cx - bw * 0.12f, baseY - bh - bw * 0.2f),
                    size = Size(bw * 0.24f, bw * 0.09f),
                    cornerRadius = CornerRadius(bw * 0.03f),
                )
            }
        }
    }
}
