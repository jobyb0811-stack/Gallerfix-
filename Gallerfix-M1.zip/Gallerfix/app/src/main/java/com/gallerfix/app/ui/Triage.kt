package com.gallerfix.app.ui

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.dp
import coil.ImageLoader
import coil.compose.AsyncImage
import com.gallerfix.app.data.MediaItem
import kotlinx.coroutines.launch
import kotlin.math.abs

const val TRASH_BATCH = 500

@Composable
fun TriageScreen(
    state: TriageUi,
    canUndo: Boolean,
    imageLoader: ImageLoader,
    onDecide: (MediaItem, Boolean) -> Unit,
    onUndo: () -> Unit,
    onReview: () -> Unit,
    onClearQueue: () -> Unit,
    onDone: () -> Unit,
) {
    val current = state.remaining.firstOrNull()
    Column(Modifier.fillMaxSize()) {
        HeaderBar("Sort") {
            TextButton(onClick = onDone) { Text("Done") }
        }
        Text(
            text = "${state.remaining.size} left · ${state.queued.size} queued for trash",
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(horizontal = 16.dp),
        )
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when {
                current != null -> SwipeCard(
                    item = current,
                    imageLoader = imageLoader,
                    onDecide = { trash -> onDecide(current, trash) },
                )
                !state.loaded -> CircularProgressIndicator(Modifier.align(Alignment.Center))
                else -> MessageState(
                    title = "All sorted",
                    body = "There is nothing left to review. New photos will show up here automatically.",
                ) {}
            }
        }
        Text(
            text = "Swipe right to keep · swipe left to trash",
            style = MaterialTheme.typography.labelMedium,
            modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 4.dp),
        )
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            OutlinedButton(
                onClick = { if (current != null) onDecide(current, true) },
                enabled = current != null,
            ) { Text("Trash") }
            TextButton(onClick = onUndo, enabled = canUndo) { Text("Undo") }
            Button(
                onClick = { if (current != null) onDecide(current, false) },
                enabled = current != null,
            ) { Text("Keep") }
        }
        if (state.queued.isNotEmpty()) {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Button(onClick = onReview) {
                    Text("Move ${minOf(TRASH_BATCH, state.queued.size)} to trash")
                }
                TextButton(onClick = onClearQueue) { Text("Clear queue") }
            }
        }
    }
}

@Composable
private fun SwipeCard(
    item: MediaItem,
    imageLoader: ImageLoader,
    onDecide: (trash: Boolean) -> Unit,
) {
    val offsetX = remember(item.id) { Animatable(0f) }
    val scope = rememberCoroutineScope()
    var widthPx by remember { mutableFloatStateOf(1f) }
    val threshold = widthPx * 0.3f
    val progress = (offsetX.value / threshold).coerceIn(-1f, 1f)

    Box(
        Modifier
            .fillMaxSize()
            .onSizeChanged { widthPx = it.width.toFloat().coerceAtLeast(1f) }
            .pointerInput(item.id) {
                detectHorizontalDragGestures(
                    onDragEnd = {
                        val x = offsetX.value
                        val limit = size.width * 0.3f
                        val away = size.width * 1.4f
                        scope.launch {
                            if (abs(x) > limit) {
                                offsetX.animateTo(if (x > 0f) away else -away, tween(160))
                                onDecide(x < 0f)
                            } else {
                                offsetX.animateTo(0f, spring())
                            }
                        }
                    },
                    onDragCancel = {
                        scope.launch { offsetX.animateTo(0f, spring()) }
                    },
                    onHorizontalDrag = { change, dragAmount ->
                        change.consume()
                        scope.launch { offsetX.snapTo(offsetX.value + dragAmount) }
                    },
                )
            }
    ) {
        Box(
            Modifier
                .fillMaxSize()
                .padding(16.dp)
                .graphicsLayer {
                    translationX = offsetX.value
                    rotationZ = offsetX.value / widthPx * 12f
                }
                .clip(RoundedCornerShape(24.dp))
                .background(MaterialTheme.colorScheme.surfaceContainerHigh)
        ) {
            AsyncImage(
                model = item.uri,
                imageLoader = imageLoader,
                contentDescription = null,
                contentScale = ContentScale.Fit,
                modifier = Modifier.fillMaxSize(),
            )
            if (item.isVideo) {
                Text(
                    text = "Video",
                    color = Color.White,
                    style = MaterialTheme.typography.labelMedium,
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(12.dp)
                        .background(Color.Black.copy(alpha = 0.55f), RoundedCornerShape(8.dp))
                        .padding(horizontal = 8.dp, vertical = 3.dp),
                )
            }
            if (progress > 0.02f) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(Color(0xFF2E7D32).copy(alpha = 0.35f * progress))
                )
                Text(
                    text = "KEEP",
                    color = Color.White,
                    style = MaterialTheme.typography.headlineMedium,
                    modifier = Modifier.align(Alignment.TopStart).padding(20.dp),
                )
            } else if (progress < -0.02f) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .background(Color(0xFFC62828).copy(alpha = 0.35f * -progress))
                )
                Text(
                    text = "TRASH",
                    color = Color.White,
                    style = MaterialTheme.typography.headlineMedium,
                    modifier = Modifier.align(Alignment.TopEnd).padding(20.dp),
                )
            }
        }
    }
}
