package com.gallerfix.app.ui

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import coil.ImageLoader
import coil.compose.AsyncImage
import com.gallerfix.app.data.MediaItem
import com.gallerfix.app.data.SmartAlbum

private val SECTIONS = listOf(
    0 to "Smart",
    1 to "By year",
    2 to "Recent months",
    3 to "Folders",
    4 to "Places",
)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SmartAlbumsPane(
    smart: List<SmartAlbum>,
    imageLoader: ImageLoader,
    locationGranted: Boolean,
    placesProgress: String?,
    onAllowLocation: () -> Unit,
    onOpen: (SmartAlbum) -> Unit,
    onRenamePlace: (SmartAlbum, String) -> Unit,
) {
    var renaming by remember { mutableStateOf<SmartAlbum?>(null) }

    if (smart.isEmpty() && !locationGranted) {
        // still show the Places explanation below even with no albums yet
    }

    LazyVerticalGrid(
        columns = GridCells.Adaptive(minSize = 140.dp),
        contentPadding = PaddingValues(12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxSize(),
    ) {
        for ((section, title) in SECTIONS) {
            val list = smart.filter { it.section == section }
            if (list.isNotEmpty() || section == 4) {
                item(key = "header$section", span = { GridItemSpan(maxLineSpan) }) {
                    Column {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.titleMedium,
                            color = MaterialTheme.colorScheme.primary,
                        )
                        if (section == 4) {
                            PlacesNote(list.isEmpty(), locationGranted, placesProgress, onAllowLocation)
                        }
                    }
                }
            }
            items(list, key = { it.id }) { album ->
                SmartCard(
                    album = album,
                    imageLoader = imageLoader,
                    onClick = { onOpen(album) },
                    onLongClick = { if (album.section == 4) renaming = album },
                )
            }
        }
    }

    val target = renaming
    if (target != null) {
        NameDialog(
            title = "Name this place",
            initial = target.title,
            confirmLabel = "Save",
            onConfirm = {
                onRenamePlace(target, it)
                renaming = null
            },
            onDismiss = { renaming = null },
        )
    }
}

@Composable
private fun PlacesNote(
    noPlaces: Boolean,
    locationGranted: Boolean,
    progress: String?,
    onAllowLocation: () -> Unit,
) {
    Column(Modifier.padding(top = 4.dp)) {
        Text(
            "Places come from the GPS info saved inside your own photos. Everything stays on your phone. " +
                "No place names are looked up online, so long-press a place to name it yourself.",
            style = MaterialTheme.typography.bodySmall,
        )
        when {
            !locationGranted -> {
                Button(
                    onClick = onAllowLocation,
                    modifier = Modifier.padding(top = 8.dp),
                ) { Text("Allow location info in photos") }
            }
            progress != null -> Text(
                progress,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(top = 6.dp),
            )
            noPlaces -> Text(
                "No places found yet. Places appear when at least 3 photos were taken in the same area.",
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(top = 6.dp),
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun SmartCard(
    album: SmartAlbum,
    imageLoader: ImageLoader,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
) {
    Column(Modifier.combinedClickable(onClick = onClick, onLongClick = onLongClick)) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(1f)
                .clip(RoundedCornerShape(16.dp))
                .background(MaterialTheme.colorScheme.surfaceContainerHigh)
        ) {
            val cover = album.items.firstOrNull()
            if (cover != null) {
                AsyncImage(
                    model = cover.uri,
                    imageLoader = imageLoader,
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                )
            }
        }
        Text(
            text = album.title,
            style = MaterialTheme.typography.titleSmall,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 6.dp),
        )
        Text(
            text = album.subtitle,
            style = MaterialTheme.typography.bodySmall,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
    }
}

@Composable
fun SmartDetailScreen(
    album: SmartAlbum,
    imageLoader: ImageLoader,
    minSize: Dp,
    selected: List<Long>,
    onBack: () -> Unit,
    onItemClick: (MediaItem) -> Unit,
    onItemLongClick: (MediaItem) -> Unit,
    selection: SelectionActions,
) {
    Column(Modifier.fillMaxSize()) {
        if (selected.isNotEmpty()) {
            SelectionHeader(selected.size, selection)
        } else {
            HeaderBar(album.title) {
                TextButton(onClick = onBack) { Text("Back") }
            }
            Text(
                album.subtitle,
                style = MaterialTheme.typography.bodySmall,
                modifier = Modifier.padding(horizontal = 16.dp),
            )
        }
        MediaGrid(
            items = album.items,
            imageLoader = imageLoader,
            minSize = minSize,
            selectedIds = selected.toSet(),
            onItemClick = onItemClick,
            onItemLongClick = onItemLongClick,
        )
    }
}
