package com.gallerfix.app.data.vault

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.nio.ByteBuffer
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * AES-256-GCM with a key that never leaves the Android Keystore.
 *
 * File format: "GFX1", then repeated chunks of [int32 length][1 byte IV length][IV][ciphertext+tag].
 * Each chunk (1 MB of plaintext) is authenticated and bound to its position, so a damaged, reordered
 * or tampered file fails instead of producing garbage. Chunking lets large videos stream without
 * loading the whole file into memory.
 */
object VaultCrypto {
    private const val ALIAS = "gallerfix_vault_key_v1"
    private const val CHUNK = 1 shl 20
    private val MAGIC = byteArrayOf(0x47, 0x46, 0x58, 0x31) // "GFX1"

    private fun key(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore")
        store.load(null)
        val existing = store.getKey(ALIAS, null)
        if (existing is SecretKey) return existing
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT,
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return generator.generateKey()
    }

    private fun aad(index: Long): ByteArray = ByteBuffer.allocate(8).putLong(index).array()

    private fun readFully(input: InputStream, buffer: ByteArray): Int {
        var total = 0
        while (total < buffer.size) {
            val n = input.read(buffer, total, buffer.size - total)
            if (n < 0) break
            total += n
        }
        return total
    }

    /** Returns the number of plaintext bytes written. */
    fun encrypt(input: InputStream, output: OutputStream): Long {
        val key = key()
        output.write(MAGIC)
        val buffer = ByteArray(CHUNK)
        var index = 0L
        var total = 0L
        while (true) {
            val n = readFully(input, buffer)
            if (n <= 0) break
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, key)
            cipher.updateAAD(aad(index))
            val encrypted = cipher.doFinal(buffer, 0, n)
            val iv = cipher.iv
            output.write(ByteBuffer.allocate(4).putInt(encrypted.size).array())
            output.write(iv.size)
            output.write(iv)
            output.write(encrypted)
            total += n
            index++
            if (n < CHUNK) break
        }
        return total
    }

    /** Returns the number of plaintext bytes written. Throws if the data is damaged or tampered with. */
    fun decrypt(input: InputStream, output: OutputStream): Long {
        val key = key()
        val magic = ByteArray(4)
        if (readFully(input, magic) != 4 || !magic.contentEquals(MAGIC)) {
            throw IOException("Not a Gallerfix vault file")
        }
        var index = 0L
        var total = 0L
        val lenBytes = ByteArray(4)
        while (true) {
            val got = readFully(input, lenBytes)
            if (got == 0) break
            if (got != 4) throw IOException("Vault file is truncated")
            val length = ByteBuffer.wrap(lenBytes).int
            if (length <= 0 || length > CHUNK + 64) throw IOException("Vault file is damaged")
            val ivLength = input.read()
            if (ivLength < 1 || ivLength > 32) throw IOException("Vault file is damaged")
            val iv = ByteArray(ivLength)
            if (readFully(input, iv) != ivLength) throw IOException("Vault file is truncated")
            val encrypted = ByteArray(length)
            if (readFully(input, encrypted) != length) throw IOException("Vault file is truncated")
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(128, iv))
            cipher.updateAAD(aad(index))
            val plain = cipher.doFinal(encrypted)
            output.write(plain)
            total += plain.size
            index++
        }
        return total
    }
}
