package com.gallerfix.app.ui

import android.os.SystemClock
import android.view.LayoutInflater
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FloatExponentialDecaySpec
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.animateDecay
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.zIndex
import androidx.media3.common.MediaItem as ExoMediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.SeekParameters
import androidx.media3.ui.PlayerView
import coil.ImageLoader
import coil.compose.AsyncImage
import com.gallerfix.app.R
import com.gallerfix.app.data.MediaItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.time.LocalDate
import java.util.Date
import java.util.Locale
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

/** Remembers where you left the dial. Lives in the ViewModel, so switching tabs doesn't lose your place. */
class DialSession {
    var currentId by mutableStateOf<Long?>(null)
    /** 0 = per photo, 1 = per day, 2 = per month */
    var unit by mutableIntStateOf(0)
    /** 0 = all, 1 = photos, 2 = videos */
    var source by mutableIntStateOf(0)
}

private const val DAY_MS = 86_400_000L

/** Degrees of rotation per photo, per day or per month. */
private const val BROWSE_STEP = 12f

/** Degrees between clicks while scrubbing a video, and the three full turns that cover a whole video. */
private const val SCRUB_STEP = 15f
private const val SCRUB_TOTAL = 1080f

private fun buildStarts(list: List<MediaItem>, unit: Int): IntArray {
    if (unit == 0) return IntArray(list.size) { it }
    val out = ArrayList<Int>()
    var previous = Long.MIN_VALUE
    for (i in list.indices) {
        val day = Math.floorDiv(list[i].takenMs, DAY_MS)
        val key = if (unit == 1) {
            day
        } else {
            val date = LocalDate.ofEpochDay(day)
            date.year * 12L + date.monthValue
        }
        if (key != previous) {
            out.add(i)
            previous = key
        }
    }
    return out.toIntArray()
}

private fun isMajor(list: List<MediaItem>, index: Int): Boolean {
    if (index % 10 == 0) return true
    if (index <= 0 || index >= list.size) return false
    return Math.floorDiv(list[index].takenMs, DAY_MS) != Math.floorDiv(list[index - 1].takenMs, DAY_MS)
}

private fun angleDeg(p: Offset, c: Offset): Float =
    Math.toDegrees(atan2((p.y - c.y).toDouble(), (p.x - c.x).toDouble())).toFloat()

private fun clock(ms: Long): String {
    val total = ms / 1000
    return "%d:%02d".format(total / 60, total % 60)
}

@Composable
fun DialScreen(
    photos: List<MediaItem>,
    videos: List<MediaItem>,
    session: DialSession,
    imageLoader: ImageLoader,
    haptics: Haptics,
    hapticLevel: Int,
    onOpen: (List<MediaItem>, MediaItem) -> Unit,
) {
    val level by rememberUpdatedState(hapticLevel)
    val scope = rememberCoroutineScope()
    val accent = MaterialTheme.colorScheme.primary

    val list by produceState(emptyList<MediaItem>(), photos, videos, session.source) {
        value = withContext(Dispatchers.Default) {
            val base = when (session.source) {
                1 -> photos
                2 -> videos
                else -> photos + videos
            }
            base.sortedByDescending { it.takenMs }
        }
    }
    val starts by produceState(IntArray(0), list, session.unit) {
        value = withContext(Dispatchers.Default) { buildStarts(list, session.unit) }
    }

    var rot by remember { mutableFloatStateOf(0f) }
    var pressed by remember { mutableStateOf(false) }
    var scrubbing by remember { mutableStateOf(false) }
    var scrubDurationMs by remember { mutableLongStateOf(0L) }
    var fastSpin by remember { mutableStateOf(false) }
    var spinStamp by remember { mutableLongStateOf(0L) }
    var flingJob by remember { mutableStateOf<Job?>(null) }
    val led = remember { Animatable(0f) }

    val maxRot = if (scrubbing) {
        if (scrubDurationMs > 0L) SCRUB_TOTAL else 0f
    } else {
        (starts.size - 1).coerceAtLeast(0) * BROWSE_STEP
    }
    val maxRotNow by rememberUpdatedState(maxRot)
    val scrubbingNow by rememberUpdatedState(scrubbing)

    val unitIndex by remember {
        derivedStateOf {
            if (scrubbing) 0 else (rot / BROWSE_STEP).roundToInt().coerceIn(0, (starts.size - 1).coerceAtLeast(0))
        }
    }
    val currentItem = list.getOrNull(starts.getOrElse(unitIndex) { 0 })

    // Put the dial back where you left it whenever the list or the unit changes.
    LaunchedEffect(starts, scrubbing) {
        if (!scrubbing && starts.isNotEmpty()) {
            val index = list.indexOfFirst { it.id == session.currentId }.coerceAtLeast(0)
            rot = starts.indexOfLast { it <= index }.coerceAtLeast(0) * BROWSE_STEP
        }
    }

    // One notch of the dial: remember the photo, pulse the light, and give a click.
    LaunchedEffect(starts, list, scrubbing) {
        var previous = -1
        var lastChange = 0L
        snapshotFlow { if (scrubbing) (rot / SCRUB_STEP).roundToInt() else unitIndex }.collect { notch ->
            val now = SystemClock.uptimeMillis()
            if (!scrubbing) {
                val index = starts.getOrElse(notch) { 0 }
                list.getOrNull(index)?.let { session.currentId = it.id }
            }
            if (previous != -1 && previous != notch) {
                val gap = now - lastChange
                lastChange = now
                spinStamp = now
                if (gap < 60) fastSpin = true
                scope.launch {
                    led.snapTo(1f)
                    led.animateTo(0f, tween(170))
                }
                val major = when {
                    scrubbing -> notch % 24 == 0
                    session.unit == 0 -> isMajor(list, starts.getOrElse(notch) { 0 })
                    else -> true
                }
                // Fast spinning: only every third notch (and the firm ones) click, so it never turns into a buzz.
                if (gap >= 90 || major || notch % 3 == 0) haptics.dialTick(level, major)
            }
            previous = notch
        }
    }
    LaunchedEffect(spinStamp) {
        delay(160)
        fastSpin = false
    }

    val release: (Float) -> Unit = { velocity ->
        flingJob?.cancel()
        flingJob = scope.launch {
            val top = maxRotNow
            if (abs(velocity) > 50f) {
                animateDecay(
                    rot,
                    velocity * 0.85f,
                    FloatExponentialDecaySpec(frictionMultiplier = 1.15f, absVelocityThreshold = 30f),
                ) { value, _ -> rot = value.coerceIn(0f, top) }
            }
            if (top > 0f && ((rot <= 0f && velocity < 0f) || (rot >= top && velocity > 0f))) {
                haptics.endStop(level)
            }
            if (!scrubbingNow) {
                val target = ((rot / BROWSE_STEP).roundToInt() * BROWSE_STEP).coerceIn(0f, top)
                animate(rot, target, animationSpec = spring(dampingRatio = 0.55f, stiffness = 420f)) { value, _ ->
                    rot = value
                }
                haptics.settle(level)
            }
        }
    }
    val releaseNow by rememberUpdatedState(release)

    val dateFormat = remember { SimpleDateFormat("d MMM yyyy", Locale.getDefault()) }
    val monthFormat = remember { SimpleDateFormat("MMMM yyyy", Locale.getDefault()) }
    val pressScale by animateFloatAsState(if (pressed) 0.985f else 1f, label = "press")

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val dialSize = (maxHeight * 0.38f).coerceIn(170.dp, 250.dp)
        Column(Modifier.fillMaxSize()) {
            HeaderBar("Dial") {
                if (scrubbing) {
                    TextButton(onClick = {
                        scrubbing = false
                        scrubDurationMs = 0L
                    }) { Text("Back to browsing") }
                } else if (currentItem?.isVideo == true) {
                    TextButton(onClick = {
                        flingJob?.cancel()
                        rot = 0f
                        scrubDurationMs = 0L
                        scrubbing = true
                    }) { Text("Scrub video") }
                }
            }

            if (!scrubbing) {
                Row(
                    Modifier
                        .horizontalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(8.dp),
                ) {
                    listOf("All", "Photos", "Videos").forEachIndexed { index, label ->
                        FilterChip(
                            selected = session.source == index,
                            onClick = { session.source = index },
                            label = { Text(label) },
                        )
                    }
                    listOf("Per photo", "Per day", "Per month").forEachIndexed { index, label ->
                        FilterChip(
                            selected = session.unit == index,
                            onClick = { session.unit = index },
                            label = { Text(label) },
                        )
                    }
                }
            }

            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                when {
                    list.isEmpty() -> MessageState(
                        title = "Nothing to browse yet",
                        body = "Photos and videos will show up here to spin through.",
                    ) {}
                    scrubbing && currentItem != null -> ScrubStage(
                        item = currentItem,
                        rotProvider = { rot },
                        onDuration = { scrubDurationMs = it },
                    )
                    else -> CoverFlow(
                        list = list,
                        starts = starts,
                        centerUnit = unitIndex,
                        rotProvider = { rot },
                        fastSpin = fastSpin,
                        imageLoader = imageLoader,
                        onOpen = { item -> onOpen(list, item) },
                    )
                }
            }

            Text(
                text = when {
                    scrubbing -> "Turn the dial to move through the video"
                    currentItem == null -> ""
                    session.unit == 2 -> monthFormat.format(Date(currentItem.takenMs))
                    else -> dateFormat.format(Date(currentItem.takenMs))
                },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
            )

            Box(Modifier.fillMaxWidth().padding(bottom = 12.dp), contentAlignment = Alignment.Center) {
                Canvas(
                    Modifier
                        .size(dialSize)
                        .graphicsLayer {
                            scaleX = pressScale
                            scaleY = pressScale
                        }
                        .pointerInput(Unit) {
                            awaitEachGesture {
                                val down = awaitFirstDown(requireUnconsumed = false)
                                flingJob?.cancel()
                                pressed = true
                                val center = Offset(size.width / 2f, size.height / 2f)
                                var last = angleDeg(down.position, center)
                                val tracker = VelocityTracker()
                                tracker.addPosition(down.uptimeMillis, Offset(rot, 0f))
                                while (true) {
                                    val event = awaitPointerEvent()
                                    val change = event.changes.firstOrNull { it.id == down.id } ?: break
                                    if (!change.pressed) break
                                    val a = angleDeg(change.position, center)
                                    var d = a - last
                                    if (d > 180f) d -= 360f
                                    if (d < -180f) d += 360f
                                    last = a
                                    rot = (rot + d).coerceIn(0f, maxRotNow)
                                    tracker.addPosition(change.uptimeMillis, Offset(rot, 0f))
                                    change.consume()
                                }
                                pressed = false
                                releaseNow(tracker.calculateVelocity().x)
                            }
                        }
                ) {
                    val c = center
                    val r = size.minDimension / 2f

                    // brushed-metal bezel
                    drawCircle(
                        brush = Brush.sweepGradient(
                            listOf(
                                Color(0xFF5A5F68), Color(0xFF2B2E33), Color(0xFF6A6F78),
                                Color(0xFF26292D), Color(0xFF5A5F68),
                            ),
                            center = c,
                        ),
                        radius = r,
                    )
                    drawCircle(Color(0xFF15171A), radius = r * 0.955f)

                    // knurled edge: turns with your finger, a firm tick every notch
                    val turn = rot
                    for (i in 0 until 90) {
                        val angle = ((i * 4f) + turn) * (PI.toFloat() / 180f)
                        val notch = i % 3 == 0
                        val outer = r * 0.92f
                        val inner = r * (if (notch) 0.79f else 0.85f)
                        drawLine(
                            color = if (notch) Color(0xFFC9CDD4) else Color(0xFF6E737C),
                            start = Offset(c.x + sin(angle) * outer, c.y - cos(angle) * outer),
                            end = Offset(c.x + sin(angle) * inner, c.y - cos(angle) * inner),
                            strokeWidth = if (notch) 3f else 2f,
                            cap = StrokeCap.Round,
                        )
                    }

                    // inner cap with a soft highlight
                    drawCircle(
                        brush = Brush.radialGradient(
                            listOf(Color(0xFF41464E), Color(0xFF1D2024)),
                            center = Offset(c.x, c.y - r * 0.22f),
                            radius = r * 0.85f,
                        ),
                        radius = r * 0.64f,
                    )
                    drawCircle(Color.Black.copy(alpha = 0.45f), radius = r * 0.64f, style = Stroke(3f))
                    drawCircle(Color.White.copy(alpha = 0.06f), radius = r * 0.6f, style = Stroke(2f))

                    // fixed pointer at 12 o'clock that lights up on every notch
                    val glow = led.value
                    drawCircle(accent.copy(alpha = 0.18f * glow), radius = r * 0.5f, center = c)
                    drawCircle(
                        color = if (glow > 0.02f) accent.copy(alpha = 0.55f + 0.45f * glow) else Color(0xFF3A3E45),
                        radius = r * 0.035f,
                        center = Offset(c.x, c.y - r * 0.985f),
                    )
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = if (scrubbing) {
                            val total = if (scrubDurationMs > 0L) scrubDurationMs else 0L
                            clock((rot / SCRUB_TOTAL * total).toLong())
                        } else {
                            "${unitIndex + 1}"
                        },
                        style = MaterialTheme.typography.headlineMedium,
                        color = Color(0xFFE6E8EC),
                    )
                    Text(
                        text = if (scrubbing) {
                            "of ${clock(scrubDurationMs)}"
                        } else {
                            "of ${starts.size}"
                        },
                        style = MaterialTheme.typography.labelMedium,
                        color = Color(0xFF9DA2AB),
                    )
                }
            }
        }
    }
}

@Composable
private fun CoverFlow(
    list: List<MediaItem>,
    starts: IntArray,
    centerUnit: Int,
    rotProvider: () -> Float,
    fastSpin: Boolean,
    imageLoader: ImageLoader,
    onOpen: (MediaItem) -> Unit,
) {
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val cardHeight = (maxHeight * 0.92f).coerceAtMost(maxWidth * 0.8f)
        val cardWidth = cardHeight * 0.78f
        for (u in (centerUnit - 2)..(centerUnit + 2)) {
            if (u < 0 || u >= starts.size) continue
            val item = list.getOrNull(starts[u]) ?: continue
            key(item.id) {
                Box(
                    Modifier
                        .align(Alignment.Center)
                        .size(cardWidth, cardHeight)
                        .zIndex(10f - abs(u - centerUnit))
                        .graphicsLayer {
                            val d = u - rotProvider() / BROWSE_STEP
                            val a = abs(d).coerceIn(0f, 2.2f)
                            translationX = d * size.width * 0.5f
                            rotationY = (-d * 30f).coerceIn(-60f, 60f)
                            cameraDistance = 14f * density
                            val s = 1f - 0.14f * a
                            scaleX = s
                            scaleY = s
                            alpha = (1f - 0.3f * a).coerceIn(0f, 1f)
                        }
                        .clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.surfaceContainerHigh)
                        .clickable(enabled = u == centerUnit) { onOpen(item) }
                ) {
                    // While spinning fast we skip loading pictures, then fill them in the moment it slows.
                    if (!fastSpin || u == centerUnit) {
                        AsyncImage(
                            model = item.uri,
                            imageLoader = imageLoader,
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize(),
                        )
                    }
                    if (item.isVideo) {
                        Text(
                            text = "Video",
                            color = Color.White,
                            style = MaterialTheme.typography.labelSmall,
                            modifier = Modifier
                                .align(Alignment.BottomStart)
                                .padding(8.dp)
                                .background(Color.Black.copy(alpha = 0.55f), RoundedCornerShape(6.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp),
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun ScrubStage(
    item: MediaItem,
    rotProvider: () -> Float,
    onDuration: (Long) -> Unit,
) {
    val context = LocalContext.current
    val exo = remember(item.id) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(ExoMediaItem.fromUri(item.uri))
            setSeekParameters(SeekParameters.CLOSEST_SYNC)
            prepare()
            playWhenReady = false
        }
    }
    DisposableEffect(exo) { onDispose { exo.release() } }

    var duration by remember(item.id) { mutableLongStateOf(0L) }
    LaunchedEffect(exo) {
        while (duration <= 0L) {
            duration = exo.duration.coerceAtLeast(0L)
            if (duration > 0L) onDuration(duration) else delay(100)
        }
    }
    LaunchedEffect(exo, duration) {
        if (duration > 0L) {
            snapshotFlow { rotProvider() }.collectLatest { r ->
                delay(45)
                exo.seekTo((r / SCRUB_TOTAL * duration).toLong())
            }
        }
    }

    AndroidView(
        factory = { ctx ->
            (LayoutInflater.from(ctx).inflate(R.layout.view_player_texture, null, false) as PlayerView)
                .also { it.player = exo }
        },
        update = { it.player = exo },
        modifier = Modifier.fillMaxSize().padding(horizontal = 12.dp).clip(RoundedCornerShape(16.dp)),
    )
}
