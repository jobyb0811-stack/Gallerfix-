package com.gallerfix.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.gallerfix.app.data.MediaItem
import com.gallerfix.app.data.MediaPermissions
import com.gallerfix.app.data.MediaRepository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

sealed interface GalleryState {
    data object Loading : GalleryState
    data object NoPermission : GalleryState
    data object Empty : GalleryState
    data class Content(val items: List<MediaItem>) : GalleryState
}

@OptIn(ExperimentalCoroutinesApi::class)
class GalleryViewModel(app: Application) : AndroidViewModel(app) {

    private val repository = MediaRepository(app)
    private val hasPermission = MutableStateFlow(MediaPermissions.hasAccess(app))

    val state: StateFlow<GalleryState> = hasPermission
        .flatMapLatest { granted ->
            if (!granted) {
                flow<GalleryState> { emit(GalleryState.NoPermission) }
            } else {
                flow<GalleryState> {
                    emit(GalleryState.Loading)
                    emitAll(
                        repository.observeImages().map { items ->
                            if (items.isEmpty()) GalleryState.Empty else GalleryState.Content(items)
                        }
                    )
                }
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), GalleryState.Loading)

    fun refreshPermission() {
        hasPermission.value = MediaPermissions.hasAccess(getApplication())
    }
}
