package com.gallerfix.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.gallerfix.app.data.MediaItem
import com.gallerfix.app.data.MediaKind
import com.gallerfix.app.data.MediaPermissions
import com.gallerfix.app.data.MediaRepository
import com.gallerfix.app.data.SettingsStore
import com.gallerfix.app.data.db.AlbumEntity
import com.gallerfix.app.data.db.AlbumItemEntity
import com.gallerfix.app.data.db.Decision
import com.gallerfix.app.data.db.GallerfixDatabase
import com.gallerfix.app.data.db.TriageEntity
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface GalleryState {
    data object Loading : GalleryState
    data object NoPermission : GalleryState
    data object Empty : GalleryState
    data class Content(val items: List<MediaItem>) : GalleryState
}

data class AlbumUi(val id: Long, val name: String, val items: List<MediaItem>)

data class TriageUi(
    val remaining: List<MediaItem>,
    val queued: List<MediaItem>,
    val loaded: Boolean,
)

fun mediaKey(id: Long, isVideo: Boolean): Long = id * 2 + (if (isVideo) 1L else 0L)

@OptIn(ExperimentalCoroutinesApi::class)
class GalleryViewModel(app: Application) : AndroidViewModel(app) {

    private val repository = MediaRepository(app)
    private val settings = SettingsStore(app)
    private val db = GallerfixDatabase.get(app)
    private val albumDao = db.albumDao()
    private val triageDao = db.triageDao()
    private val hasPermission = MutableStateFlow(MediaPermissions.hasAccess(app))

    val photos: StateFlow<GalleryState> = stateFor { repository.observe(MediaKind.PHOTOS) }
    val videos: StateFlow<GalleryState> = stateFor { repository.observe(MediaKind.VIDEOS) }
    val trash: StateFlow<GalleryState> = stateFor { repository.observeTrash() }

    private val _railOnRight = MutableStateFlow(settings.railOnRight)
    val railOnRight: StateFlow<Boolean> = _railOnRight

    private val _thumbSize = MutableStateFlow(settings.thumbSize)
    val thumbSize: StateFlow<Int> = _thumbSize

    val albums: StateFlow<List<AlbumUi>> = combine(
        albumDao.observeAlbums(),
        albumDao.observeLinks(),
        photos,
        videos,
    ) { albumRows, links, p, v ->
        val index = HashMap<Long, MediaItem>()
        (p as? GalleryState.Content)?.items?.forEach { index[mediaKey(it.id, it.isVideo)] = it }
        (v as? GalleryState.Content)?.items?.forEach { index[mediaKey(it.id, it.isVideo)] = it }
        albumRows.map { a ->
            AlbumUi(
                id = a.id,
                name = a.name,
                items = links
                    .filter { it.albumId == a.id }
                    .sortedByDescending { it.addedAt }
                    .mapNotNull { index[mediaKey(it.mediaId, it.isVideo)] },
            )
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val triage: StateFlow<TriageUi> = combine(
        photos,
        videos,
        triageDao.observeAll(),
    ) { p, v, rows ->
        val all = ((p as? GalleryState.Content)?.items.orEmpty() +
            (v as? GalleryState.Content)?.items.orEmpty())
            .sortedByDescending { it.dateAddedSeconds }
        val decided = HashMap<Long, Int>()
        rows.forEach { decided[mediaKey(it.mediaId, it.isVideo)] = it.decision }
        TriageUi(
            remaining = all.filter { !decided.containsKey(mediaKey(it.id, it.isVideo)) },
            queued = all.filter { decided[mediaKey(it.id, it.isVideo)] == Decision.TRASH },
            loaded = isLoaded(p) && isLoaded(v),
        )
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5_000),
        TriageUi(emptyList(), emptyList(), false),
    )

    private val history = ArrayList<MediaItem>()
    private val _canUndo = MutableStateFlow(false)
    val canUndo: StateFlow<Boolean> = _canUndo

    init {
        // Clean up queued-for-trash rows whose media no longer exists
        // (trashed/deleted elsewhere, or after a crash mid-trash). Only when lists are loaded.
        viewModelScope.launch {
            combine(photos, videos, triageDao.observeAll()) { p, v, rows ->
                if (!isLoaded(p) || !isLoaded(v)) {
                    emptyList()
                } else {
                    val present = HashSet<Long>()
                    (p as? GalleryState.Content)?.items?.forEach { present.add(mediaKey(it.id, it.isVideo)) }
                    (v as? GalleryState.Content)?.items?.forEach { present.add(mediaKey(it.id, it.isVideo)) }
                    rows.filter {
                        it.decision == Decision.TRASH && !present.contains(mediaKey(it.mediaId, it.isVideo))
                    }
                }
            }.collect { stale ->
                stale.forEach { triageDao.delete(it.mediaId, it.isVideo) }
            }
        }
    }

    private fun isLoaded(s: GalleryState): Boolean =
        s is GalleryState.Content || s is GalleryState.Empty

    private fun stateFor(source: () -> Flow<List<MediaItem>>): StateFlow<GalleryState> = hasPermission
        .flatMapLatest { granted ->
            if (!granted) {
                flow<GalleryState> { emit(GalleryState.NoPermission) }
            } else {
                flow<GalleryState> {
                    emit(GalleryState.Loading)
                    emitAll(
                        source().map { items ->
                            if (items.isEmpty()) GalleryState.Empty else GalleryState.Content(items)
                        }
                    )
                }
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), GalleryState.Loading)

    fun refreshPermission() {
        hasPermission.value = MediaPermissions.hasAccess(getApplication())
    }

    // ---- settings ----
    fun setRailOnRight(value: Boolean) {
        settings.railOnRight = value
        _railOnRight.value = value
    }

    fun setThumbSize(value: Int) {
        settings.thumbSize = value
        _thumbSize.value = value
    }

    // ---- albums ----
    fun createAlbum(name: String, items: List<MediaItem> = emptyList()) {
        val clean = name.trim()
        if (clean.isEmpty()) return
        viewModelScope.launch {
            val id = albumDao.insertAlbum(AlbumEntity(name = clean, createdAt = System.currentTimeMillis()))
            if (items.isNotEmpty()) addLinks(id, items)
        }
    }

    fun addToAlbum(albumId: Long, items: List<MediaItem>) {
        viewModelScope.launch { addLinks(albumId, items) }
    }

    private suspend fun addLinks(albumId: Long, items: List<MediaItem>) {
        val now = System.currentTimeMillis()
        albumDao.insertLinks(items.map { AlbumItemEntity(albumId, it.id, it.isVideo, now) })
    }

    fun renameAlbum(albumId: Long, name: String) {
        val clean = name.trim()
        if (clean.isEmpty()) return
        viewModelScope.launch { albumDao.rename(albumId, clean) }
    }

    fun deleteAlbum(albumId: Long) {
        viewModelScope.launch { albumDao.deleteAlbum(albumId) }
    }

    fun removeFromAlbum(albumId: Long, items: List<MediaItem>) {
        viewModelScope.launch {
            items.forEach { albumDao.removeLink(albumId, it.id, it.isVideo) }
        }
    }

    // ---- sort (triage) ----
    fun decide(item: MediaItem, trash: Boolean) {
        history.add(item)
        _canUndo.value = true
        viewModelScope.launch {
            triageDao.upsert(
                TriageEntity(
                    mediaId = item.id,
                    isVideo = item.isVideo,
                    decision = if (trash) Decision.TRASH else Decision.KEEP,
                    decidedAt = System.currentTimeMillis(),
                )
            )
        }
    }

    fun undo() {
        if (history.isEmpty()) return
        val item = history.removeAt(history.lastIndex)
        _canUndo.value = history.isNotEmpty()
        viewModelScope.launch { triageDao.delete(item.id, item.isVideo) }
    }

    /** Called after the user approved the system trash dialog for these items. */
    fun onTrashed(items: List<MediaItem>) {
        viewModelScope.launch { items.forEach { triageDao.delete(it.id, it.isVideo) } }
    }

    fun clearTrashQueue() {
        viewModelScope.launch { triageDao.clearTrashQueue() }
    }

    fun resetSorting() {
        history.clear()
        _canUndo.value = false
        viewModelScope.launch { triageDao.clearAll() }
    }
}
