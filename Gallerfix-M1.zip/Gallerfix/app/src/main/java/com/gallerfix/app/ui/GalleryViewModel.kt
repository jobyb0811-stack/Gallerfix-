package com.gallerfix.app.ui

import android.app.Application
import android.graphics.Bitmap
import android.os.SystemClock
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.gallerfix.app.LockSpec
import com.gallerfix.app.data.MediaItem
import com.gallerfix.app.data.MediaKind
import com.gallerfix.app.data.MediaPermissions
import com.gallerfix.app.data.MediaRepository
import com.gallerfix.app.data.PlaceIndexer
import com.gallerfix.app.data.SmartAlbum
import com.gallerfix.app.data.SmartAlbumBuilder
import com.gallerfix.app.data.SettingsStore
import com.gallerfix.app.data.db.AlbumEntity
import com.gallerfix.app.data.db.AlbumItemEntity
import com.gallerfix.app.data.db.Decision
import com.gallerfix.app.data.db.GallerfixDatabase
import com.gallerfix.app.data.db.PlaceNameEntity
import com.gallerfix.app.data.db.TriageEntity
import com.gallerfix.app.data.db.VaultEntity
import com.gallerfix.app.data.vault.MoveResult
import com.gallerfix.app.data.vault.MovedItem
import com.gallerfix.app.data.vault.VaultStore
import kotlinx.coroutines.async
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

sealed interface GalleryState {
    data object Loading : GalleryState
    data object NoPermission : GalleryState
    data object Empty : GalleryState
    data class Content(val items: List<MediaItem>) : GalleryState
}

data class AlbumUi(val id: Long, val name: String, val items: List<MediaItem>)

data class TriageUi(
    val remaining: List<MediaItem>,
    val queued: List<MediaItem>,
    val loaded: Boolean,
)

fun mediaKey(id: Long, isVideo: Boolean): Long = id * 2 + (if (isVideo) 1L else 0L)

@OptIn(ExperimentalCoroutinesApi::class, FlowPreview::class)
class GalleryViewModel(app: Application) : AndroidViewModel(app) {

    private val repository = MediaRepository(app)
    private val settings = SettingsStore(app)
    private val db = GallerfixDatabase.get(app)
    private val albumDao = db.albumDao()
    private val triageDao = db.triageDao()
    private val hasPermission = MutableStateFlow(MediaPermissions.hasAccess(app))

    private val _showSd = MutableStateFlow(settings.showSd)
    val showSd: StateFlow<Boolean> = _showSd

    val photos: StateFlow<GalleryState> = stateFor { sd -> repository.observe(MediaKind.PHOTOS, sd) }
    val videos: StateFlow<GalleryState> = stateFor { sd -> repository.observe(MediaKind.VIDEOS, sd) }
    val trash: StateFlow<GalleryState> = stateFor { sd -> repository.observeTrash(sd) }

    private val _railOnRight = MutableStateFlow(settings.railOnRight)
    val railOnRight: StateFlow<Boolean> = _railOnRight

    private val _thumbSize = MutableStateFlow(settings.thumbSize)
    val thumbSize: StateFlow<Int> = _thumbSize

    private val _themeMode = MutableStateFlow(settings.themeMode)
    val themeMode: StateFlow<Int> = _themeMode

    private val _palette = MutableStateFlow(settings.palette)
    val palette: StateFlow<Int> = _palette

    private val _amoled = MutableStateFlow(settings.amoled)
    val amoled: StateFlow<Boolean> = _amoled

    val albums: StateFlow<List<AlbumUi>> = combine(
        albumDao.observeAlbums(),
        albumDao.observeLinks(),
        photos,
        videos,
    ) { albumRows, links, p, v ->
        val index = HashMap<Long, MediaItem>()
        (p as? GalleryState.Content)?.items?.forEach { index[mediaKey(it.id, it.isVideo)] = it }
        (v as? GalleryState.Content)?.items?.forEach { index[mediaKey(it.id, it.isVideo)] = it }
        albumRows.map { a ->
            AlbumUi(
                id = a.id,
                name = a.name,
                items = links
                    .filter { it.albumId == a.id }
                    .sortedByDescending { it.addedAt }
                    .mapNotNull { index[mediaKey(it.mediaId, it.isVideo)] },
            )
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val triage: StateFlow<TriageUi> = combine(
        photos,
        videos,
        triageDao.observeAll(),
    ) { p, v, rows ->
        val all = ((p as? GalleryState.Content)?.items.orEmpty() +
            (v as? GalleryState.Content)?.items.orEmpty())
            .sortedByDescending { it.dateAddedSeconds }
        val decided = HashMap<Long, Int>()
        rows.forEach { decided[mediaKey(it.mediaId, it.isVideo)] = it.decision }
        TriageUi(
            remaining = all.filter { !decided.containsKey(mediaKey(it.id, it.isVideo)) },
            queued = all.filter { decided[mediaKey(it.id, it.isVideo)] == Decision.TRASH },
            loaded = isLoaded(p) && isLoaded(v),
        )
    }.stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5_000),
        TriageUi(emptyList(), emptyList(), false),
    )

    private val history = ArrayList<MediaItem>()
    private val _canUndo = MutableStateFlow(false)
    val canUndo: StateFlow<Boolean> = _canUndo

    init {
        // Clean up queued-for-trash rows whose media no longer exists
        // (trashed/deleted elsewhere, or after a crash mid-trash). Only when lists are loaded.
        viewModelScope.launch {
            combine(photos, videos, triageDao.observeAll()) { p, v, rows ->
                if (!isLoaded(p) || !isLoaded(v)) {
                    emptyList()
                } else {
                    val present = HashSet<Long>()
                    (p as? GalleryState.Content)?.items?.forEach { present.add(mediaKey(it.id, it.isVideo)) }
                    (v as? GalleryState.Content)?.items?.forEach { present.add(mediaKey(it.id, it.isVideo)) }
                    rows.filter {
                        it.decision == Decision.TRASH && !present.contains(mediaKey(it.mediaId, it.isVideo))
                    }
                }
            }.collect { stale ->
                stale.forEach { triageDao.delete(it.mediaId, it.isVideo) }
            }
        }
    }

    private fun isLoaded(s: GalleryState): Boolean =
        s is GalleryState.Content || s is GalleryState.Empty

    private fun stateFor(source: (Boolean) -> Flow<List<MediaItem>>): StateFlow<GalleryState> =
        combine(hasPermission, _showSd) { granted, sd -> Pair(granted, sd) }
        .flatMapLatest { (granted, sd) ->
            if (!granted) {
                flow<GalleryState> { emit(GalleryState.NoPermission) }
            } else {
                flow<GalleryState> {
                    emit(GalleryState.Loading)
                    emitAll(
                        source(sd).map { items ->
                            if (items.isEmpty()) GalleryState.Empty else GalleryState.Content(items)
                        }
                    )
                }
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), GalleryState.Loading)

    // ---------------------------------------------------------------- app lock
    private val _lockEnabled = MutableStateFlow(settings.lockEnabled)
    val lockEnabled: StateFlow<Boolean> = _lockEnabled

    private val _lockBiometric = MutableStateFlow(settings.lockBiometric)
    val lockBiometric: StateFlow<Boolean> = _lockBiometric

    private val _lockTaps = MutableStateFlow(settings.lockTaps)
    val lockTaps: StateFlow<Boolean> = _lockTaps

    private val _tapCount = MutableStateFlow(settings.tapCount)
    val tapCount: StateFlow<Int> = _tapCount

    private val _lockGrace = MutableStateFlow(settings.lockGraceSeconds)
    val lockGrace: StateFlow<Int> = _lockGrace

    /** Starts locked on every cold start when app lock is on. */
    private val _locked = MutableStateFlow(settings.lockEnabled)
    val locked: StateFlow<Boolean> = _locked

    private var backgroundedAt = 0L

    fun unlock() {
        _locked.value = false
    }

    fun onBackgrounded() {
        backgroundedAt = SystemClock.elapsedRealtime()
        closeVault()
    }

    fun onForegrounded() {
        val at = backgroundedAt
        backgroundedAt = 0L
        if (at != 0L && _lockEnabled.value &&
            SystemClock.elapsedRealtime() - at >= _lockGrace.value * 1000L
        ) {
            _locked.value = true
        }
    }

    fun setLockEnabled(value: Boolean) {
        settings.lockEnabled = value
        _lockEnabled.value = value
        if (!value) _locked.value = false
    }

    /** At least one unlock method must stay on, otherwise the app could lock you out. */
    fun setLockBiometric(value: Boolean) {
        if (!value && !_lockTaps.value) return
        settings.lockBiometric = value
        _lockBiometric.value = value
    }

    fun setLockTaps(value: Boolean) {
        if (!value && !_lockBiometric.value) return
        settings.lockTaps = value
        _lockTaps.value = value
    }

    fun setTapCount(value: Int) {
        val clean = value.coerceIn(LockSpec.MIN_TAPS, LockSpec.MAX_TAPS)
        settings.tapCount = clean
        _tapCount.value = clean
    }

    fun setLockGrace(seconds: Int) {
        settings.lockGraceSeconds = seconds
        _lockGrace.value = seconds
    }

    // ---------------------------------------------------------------- private library
    private val vaultDao = db.vaultDao()
    private val vaultStore = VaultStore(app, vaultDao)

    val vaultItems: StateFlow<List<VaultEntity>> = vaultDao.observeAll()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    private val _vaultOpen = MutableStateFlow(false)
    val vaultOpen: StateFlow<Boolean> = _vaultOpen

    private val _vaultBusy = MutableStateFlow<String?>(null)
    val vaultBusy: StateFlow<String?> = _vaultBusy

    private val _vaultMessage = MutableStateFlow<String?>(null)
    val vaultMessage: StateFlow<String?> = _vaultMessage

    /** Hides previews in the app switcher and blocks screenshots while locking or the library is on. */
    val secureWindow: StateFlow<Boolean> = combine(_lockEnabled, _vaultOpen) { lock, vault -> lock || vault }
        .stateIn(viewModelScope, SharingStarted.Eagerly, settings.lockEnabled)

    init {
        // Recover from a crash: drop half-written files and any decrypted video left in the cache.
        viewModelScope.launch {
            vaultStore.cleanupOrphans()
            vaultStore.clearTemp()
        }
    }

    fun openVault() {
        _vaultMessage.value = null
        _vaultOpen.value = true
        viewModelScope.launch {
            vaultStore.cleanupOrphans()
            vaultStore.reconcile()
        }
    }

    fun closeVault() {
        _vaultOpen.value = false
        _vaultBusy.value = null
        vaultStore.clearTemp()
        vaultStore.clearThumbs()
    }

    fun dismissVaultMessage() {
        _vaultMessage.value = null
    }

    /** Encrypts copies into the library. Originals are untouched until the caller gets the user's approval. */
    suspend fun moveToVault(items: List<MediaItem>): MoveResult = viewModelScope.async {
        _vaultBusy.value = "Encrypting…"
        try {
            val result = vaultStore.moveIn(items) { done, total ->
                _vaultBusy.value = "Encrypting $done of $total…"
            }
            _vaultMessage.value = when {
                result.lowStorage ->
                    "Not enough free storage. " +
                        (if (result.moved.isEmpty()) "Nothing was moved" else "Only ${result.moved.size} item(s) were copied") +
                        " and your originals are untouched."
                result.failed > 0 ->
                    "${result.failed} item(s) couldn't be copied and were left in your gallery."
                result.moved.isEmpty() && result.skipped > 0 ->
                    "Those items are already in your private library."
                else -> null
            }
            result
        } finally {
            _vaultBusy.value = null
        }
    }.await()

    fun onVaultOriginalsRemoved(ids: List<Long>) {
        viewModelScope.launch {
            vaultStore.markSafe(ids)
            _vaultMessage.value = "Done. The originals were removed from your gallery."
        }
    }

    fun onVaultOriginalsKept() {
        _vaultMessage.value = "The copies are safe here, but the originals are still in your gallery."
    }

    /** Originals that still need the user's approval to be removed. */
    suspend fun vaultPendingOriginals(): List<MovedItem> = vaultStore.reconcile()

    fun undoPendingVault() {
        viewModelScope.launch {
            vaultStore.undoPending()
            _vaultMessage.value = "Undone. Nothing changed in your gallery."
        }
    }

    fun restoreFromVault(items: List<VaultEntity>) {
        viewModelScope.launch {
            _vaultBusy.value = "Restoring…"
            try {
                val result = vaultStore.restore(items) { done, total ->
                    _vaultBusy.value = "Restoring $done of $total…"
                }
                _vaultMessage.value = when {
                    result.lowStorage -> "Not enough free storage. Items that weren't restored are still safe here."
                    result.failed > 0 -> "${result.failed} item(s) couldn't be restored and are still safe here."
                    else -> "Restored ${result.restored} item(s) to Pictures/Restored or Movies/Restored."
                }
            } finally {
                _vaultBusy.value = null
            }
        }
    }

    fun deleteFromVault(items: List<VaultEntity>) {
        viewModelScope.launch {
            vaultStore.deleteForever(items)
            _vaultMessage.value = "Deleted ${items.size} item(s) permanently."
        }
    }

    suspend fun vaultThumb(entity: VaultEntity): Bitmap? = vaultStore.thumbnail(entity)
    suspend fun vaultImage(entity: VaultEntity): Bitmap? = vaultStore.image(entity)
    suspend fun vaultVideo(entity: VaultEntity): File? = vaultStore.videoTemp(entity)

    // ---------------------------------------------------------------- smart albums & places
    private val geoDao = db.geoDao()
    private val placeIndexer = PlaceIndexer(app, geoDao)

    private val _locationGranted = MutableStateFlow(MediaPermissions.hasLocation(app))
    val locationGranted: StateFlow<Boolean> = _locationGranted

    private val _placesProgress = MutableStateFlow<String?>(null)
    val placesProgress: StateFlow<String?> = _placesProgress

    /** Built only from information already on this phone. Nothing is uploaded or looked up. */
    val smartAlbums: StateFlow<List<SmartAlbum>> = combine(
        photos,
        videos,
        geoDao.observeAll().debounce(600),
        geoDao.observeNames(),
    ) { p, v, geoRows, names ->
        val all = (p as? GalleryState.Content)?.items.orEmpty() +
            (v as? GalleryState.Content)?.items.orEmpty()
        SmartAlbumBuilder.build(
            all = all,
            geo = geoRows,
            placeNames = names.associate { it.cell to it.name },
            nowMs = System.currentTimeMillis(),
        )
    }
        .flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    init {
        // Read GPS info from photos in the background (only once you've allowed it).
        viewModelScope.launch {
            combine(photos, _locationGranted) { p, granted -> Pair(p, granted) }
                .collectLatest { (p, granted) ->
                    if (granted && p is GalleryState.Content) {
                        try {
                            placeIndexer.index(p.items) { done, total ->
                                _placesProgress.value =
                                    if (done < total) "Finding places… $done of $total" else null
                            }
                        } finally {
                            _placesProgress.value = null
                        }
                    }
                }
        }
    }

    fun renamePlace(cell: String, name: String) {
        val clean = name.trim()
        if (cell.isEmpty() || clean.isEmpty()) return
        viewModelScope.launch { geoDao.setName(PlaceNameEntity(cell, clean)) }
    }

    fun refreshPermission() {
        hasPermission.value = MediaPermissions.hasAccess(getApplication())
        _locationGranted.value = MediaPermissions.hasLocation(getApplication())
    }

    // ---- settings ----
    fun setRailOnRight(value: Boolean) {
        settings.railOnRight = value
        _railOnRight.value = value
    }

    fun setShowSd(value: Boolean) {
        settings.showSd = value
        _showSd.value = value
    }

    fun setThemeMode(value: Int) {
        settings.themeMode = value
        _themeMode.value = value
    }

    fun setPalette(value: Int) {
        settings.palette = value
        _palette.value = value
    }

    fun setAmoled(value: Boolean) {
        settings.amoled = value
        _amoled.value = value
    }

    fun setThumbSize(value: Int) {
        settings.thumbSize = value
        _thumbSize.value = value
    }

    // ---- albums ----
    fun createAlbum(name: String, items: List<MediaItem> = emptyList()) {
        val clean = name.trim()
        if (clean.isEmpty()) return
        viewModelScope.launch {
            val id = albumDao.insertAlbum(AlbumEntity(name = clean, createdAt = System.currentTimeMillis()))
            if (items.isNotEmpty()) addLinks(id, items)
        }
    }

    fun addToAlbum(albumId: Long, items: List<MediaItem>) {
        viewModelScope.launch { addLinks(albumId, items) }
    }

    private suspend fun addLinks(albumId: Long, items: List<MediaItem>) {
        val now = System.currentTimeMillis()
        albumDao.insertLinks(items.map { AlbumItemEntity(albumId, it.id, it.isVideo, now) })
    }

    fun renameAlbum(albumId: Long, name: String) {
        val clean = name.trim()
        if (clean.isEmpty()) return
        viewModelScope.launch { albumDao.rename(albumId, clean) }
    }

    fun deleteAlbum(albumId: Long) {
        viewModelScope.launch { albumDao.deleteAlbum(albumId) }
    }

    fun removeFromAlbum(albumId: Long, items: List<MediaItem>) {
        viewModelScope.launch {
            items.forEach { albumDao.removeLink(albumId, it.id, it.isVideo) }
        }
    }

    // ---- sort (triage) ----
    fun decide(item: MediaItem, trash: Boolean) {
        history.add(item)
        _canUndo.value = true
        viewModelScope.launch {
            triageDao.upsert(
                TriageEntity(
                    mediaId = item.id,
                    isVideo = item.isVideo,
                    decision = if (trash) Decision.TRASH else Decision.KEEP,
                    decidedAt = System.currentTimeMillis(),
                )
            )
        }
    }

    fun undo() {
        if (history.isEmpty()) return
        val item = history.removeAt(history.lastIndex)
        _canUndo.value = history.isNotEmpty()
        viewModelScope.launch { triageDao.delete(item.id, item.isVideo) }
    }

    /** Called after the user approved the system trash dialog for these items. */
    fun onTrashed(items: List<MediaItem>) {
        viewModelScope.launch { items.forEach { triageDao.delete(it.id, it.isVideo) } }
    }

    fun clearTrashQueue() {
        viewModelScope.launch { triageDao.clearTrashQueue() }
    }

    fun resetSorting() {
        history.clear()
        _canUndo.value = false
        viewModelScope.launch { triageDao.clearAll() }
    }
}
