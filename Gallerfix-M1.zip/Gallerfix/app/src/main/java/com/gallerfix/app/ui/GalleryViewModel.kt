package com.gallerfix.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.gallerfix.app.data.MediaItem
import com.gallerfix.app.data.MediaKind
import com.gallerfix.app.data.MediaPermissions
import com.gallerfix.app.data.MediaRepository
import com.gallerfix.app.data.SettingsStore
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.emitAll
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn

sealed interface GalleryState {
    data object Loading : GalleryState
    data object NoPermission : GalleryState
    data object Empty : GalleryState
    data class Content(val items: List<MediaItem>) : GalleryState
}

@OptIn(ExperimentalCoroutinesApi::class)
class GalleryViewModel(app: Application) : AndroidViewModel(app) {

    private val repository = MediaRepository(app)
    private val settings = SettingsStore(app)
    private val hasPermission = MutableStateFlow(MediaPermissions.hasAccess(app))

    val photos: StateFlow<GalleryState> = stateFor(MediaKind.PHOTOS)
    val videos: StateFlow<GalleryState> = stateFor(MediaKind.VIDEOS)

    private val _railOnRight = MutableStateFlow(settings.railOnRight)
    val railOnRight: StateFlow<Boolean> = _railOnRight

    private fun stateFor(kind: MediaKind): StateFlow<GalleryState> = hasPermission
        .flatMapLatest { granted ->
            if (!granted) {
                flow<GalleryState> { emit(GalleryState.NoPermission) }
            } else {
                flow<GalleryState> {
                    emit(GalleryState.Loading)
                    emitAll(
                        repository.observe(kind).map { items ->
                            if (items.isEmpty()) GalleryState.Empty else GalleryState.Content(items)
                        }
                    )
                }
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), GalleryState.Loading)

    fun refreshPermission() {
        hasPermission.value = MediaPermissions.hasAccess(getApplication())
    }

    fun setRailOnRight(value: Boolean) {
        settings.railOnRight = value
        _railOnRight.value = value
    }
}
