package com.gallerfix.app.data

import android.content.Context
import android.provider.MediaStore
import androidx.exifinterface.media.ExifInterface
import com.gallerfix.app.data.db.GeoDao
import com.gallerfix.app.data.db.GeoEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext

/** Reads GPS coordinates from each photo's own metadata, on this phone only, and remembers them. */
class PlaceIndexer(private val context: Context, private val dao: GeoDao) {

    suspend fun index(photos: List<MediaItem>, onProgress: (done: Int, total: Int) -> Unit) =
        withContext(Dispatchers.IO) {
            val known = dao.indexedIds().toHashSet()
            val todo = photos.filter { !it.isVideo && it.id !in known }
            if (todo.isEmpty()) return@withContext
            val batch = ArrayList<GeoEntity>()
            var done = 0
            for (item in todo) {
                ensureActive()
                val row = read(item)
                done++
                if (row != null) batch.add(row)
                if (batch.size >= BATCH) {
                    dao.insertAll(ArrayList(batch))
                    batch.clear()
                    onProgress(done, todo.size)
                }
            }
            if (batch.isNotEmpty()) dao.insertAll(ArrayList(batch))
            onProgress(done, todo.size)
        }

    /** Returns null when the file couldn't be read right now, so it is tried again next time. */
    private fun read(item: MediaItem): GeoEntity? {
        return try {
            val uri = MediaStore.setRequireOriginal(item.uri)
            val stream = context.contentResolver.openInputStream(uri) ?: return null
            stream.use { input ->
                val latLong = ExifInterface(input).latLong
                if (latLong != null) {
                    GeoEntity(item.id, latLong[0], latLong[1])
                } else {
                    GeoEntity(item.id, null, null)
                }
            }
        } catch (e: SecurityException) {
            null
        } catch (e: UnsupportedOperationException) {
            null
        } catch (e: java.io.FileNotFoundException) {
            null
        } catch (e: Exception) {
            // Not a format that carries GPS data: remember that, so it isn't re-read every time.
            GeoEntity(item.id, null, null)
        }
    }

    private companion object {
        const val BATCH = 100
    }
}
