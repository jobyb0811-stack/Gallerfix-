package com.gallerfix.app.data.vault

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import android.provider.BaseColumns
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.util.LruCache
import android.util.Size
import com.gallerfix.app.data.MediaItem
import com.gallerfix.app.data.db.VaultDao
import com.gallerfix.app.data.db.VaultEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.nio.ByteBuffer
import java.util.UUID
import kotlin.math.max

data class MovedItem(val entityId: Long, val original: Uri)

data class MoveResult(
    val moved: List<MovedItem>,
    val skipped: Int,
    val failed: Int,
    val lowStorage: Boolean,
)

data class RestoreResult(val restored: Int, val failed: Int, val lowStorage: Boolean)

/**
 * Moving in is a two-step journal so nothing is ever lost or duplicated by a crash:
 *  1. Encrypt a copy into private storage and record it with state 0 (original untouched).
 *  2. After the user approves deleting the originals, flip the state to 1.
 * If the app dies between the steps, the copy is still there and the original is still there;
 * the library offers to finish or undo.
 */
class VaultStore(private val context: Context, private val dao: VaultDao) {

    private val dir = File(context.filesDir, "vault")
    private val tempDir = File(context.cacheDir, "vault_tmp")
    private val thumbCache = LruCache<Long, Bitmap>(48)

    init {
        dir.mkdirs()
    }

    // ---------------------------------------------------------------- move in

    suspend fun moveIn(
        items: List<MediaItem>,
        onProgress: (done: Int, total: Int) -> Unit,
    ): MoveResult = withContext(Dispatchers.IO) {
        val moved = ArrayList<MovedItem>()
        var skipped = 0
        var failed = 0
        var low = false
        val known = dao.originalUris().toHashSet()

        for ((index, item) in items.withIndex()) {
            if (low) break
            onProgress(index + 1, items.size)

            if (known.contains(item.uri.toString())) {
                skipped++
                continue
            }
            val size = sizeOf(item.uri)
            // Abort cleanly (keeping the original) if there isn't room for the encrypted copy.
            if (size > 0 && dir.usableSpace < size + size / 20 + MIN_FREE_BYTES) {
                low = true
                break
            }

            val name = UUID.randomUUID().toString()
            val blob = File(dir, "$name.bin")
            val part = File(dir, "$name.bin.part")
            val thumb = File(dir, "$name.thumb")
            try {
                val input = context.contentResolver.openInputStream(item.uri)
                    ?: throw IOException("Could not open the original")
                var written = 0L
                input.use { source ->
                    FileOutputStream(part).use { out ->
                        written = VaultCrypto.encrypt(source, out)
                        out.flush()
                        out.fd.sync()
                    }
                }
                if (size > 0 && written != size) throw IOException("Copy was incomplete")
                if (!part.renameTo(blob)) throw IOException("Could not finish the copy")

                val thumbName = writeThumb(item, thumb)
                val id = dao.insert(
                    VaultEntity(
                        displayName = item.displayName,
                        mimeType = context.contentResolver.getType(item.uri)
                            ?: if (item.isVideo) "video/mp4" else "image/jpeg",
                        isVideo = item.isVideo,
                        sizeBytes = written,
                        dateAdded = item.dateAddedSeconds,
                        durationMs = item.durationMs,
                        blobName = blob.name,
                        thumbName = thumbName,
                        state = 0,
                        originalUri = item.uri.toString(),
                        createdAt = System.currentTimeMillis(),
                    )
                )
                moved.add(MovedItem(id, item.uri))
            } catch (e: Exception) {
                part.delete()
                blob.delete()
                thumb.delete()
                if (isNoSpace(e)) low = true else failed++
            }
        }
        MoveResult(moved, skipped, failed, low)
    }

    private fun sizeOf(uri: Uri): Long {
        try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.SIZE), null, null, null)?.use { c ->
                if (c.moveToFirst() && !c.isNull(0)) return c.getLong(0)
            }
        } catch (e: Exception) {
            // fall through
        }
        return -1L
    }

    private fun isNoSpace(e: Exception): Boolean {
        val m = e.message ?: return false
        return m.contains("ENOSPC", ignoreCase = true) || m.contains("No space", ignoreCase = true)
    }

    private fun writeThumb(item: MediaItem, file: File): String {
        try {
            val bitmap: Bitmap = if (item.isVideo) {
                context.contentResolver.loadThumbnail(item.uri, Size(THUMB, THUMB), null)
            } else {
                ImageDecoder.decodeBitmap(
                    ImageDecoder.createSource(context.contentResolver, item.uri)
                ) { decoder, info, _ ->
                    decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                    decoder.setTargetSampleSize(
                        max(1, max(info.size.width, info.size.height) / THUMB)
                    )
                }
            }
            val jpeg = ByteArrayOutputStream()
            bitmap.compress(Bitmap.CompressFormat.JPEG, 80, jpeg)
            FileOutputStream(file).use { out ->
                VaultCrypto.encrypt(ByteArrayInputStream(jpeg.toByteArray()), out)
            }
            return file.name
        } catch (e: Exception) {
            file.delete()
            return ""
        }
    }

    // ---------------------------------------------------------------- journal

    suspend fun markSafe(ids: List<Long>) = withContext(Dispatchers.IO) {
        if (ids.isNotEmpty()) dao.markSafe(ids)
    }

    /**
     * Marks copies whose originals are already gone as safe, and returns the ones whose originals
     * are still in the gallery (their removal still needs the user's approval).
     */
    suspend fun reconcile(): List<MovedItem> = withContext(Dispatchers.IO) {
        val remaining = ArrayList<MovedItem>()
        val safe = ArrayList<Long>()
        for (item in dao.getAll().filter { it.state == 0 }) {
            val uri = Uri.parse(item.originalUri)
            if (originalExists(uri)) remaining.add(MovedItem(item.id, uri)) else safe.add(item.id)
        }
        if (safe.isNotEmpty()) dao.markSafe(safe)
        remaining
    }

    private fun originalExists(uri: Uri): Boolean = try {
        context.contentResolver.query(uri, arrayOf(BaseColumns._ID), null, null, null)
            ?.use { it.count > 0 } ?: false
    } catch (e: Exception) {
        false
    }

    /** Cancels a move: removes the encrypted copies whose originals are still in the gallery. */
    suspend fun undoPending() = withContext(Dispatchers.IO) {
        val stillOriginal = reconcile().map { it.entityId }.toSet()
        val doomed = dao.getAll().filter { it.state == 0 && it.id in stillOriginal }
        removeFiles(doomed)
        if (doomed.isNotEmpty()) dao.deleteByIds(doomed.map { it.id })
    }

    /** Removes leftovers from a crash (half-written copies, files with no record). */
    suspend fun cleanupOrphans() = withContext(Dispatchers.IO) {
        val referenced = HashSet<String>()
        for (item in dao.getAll()) {
            referenced.add(item.blobName)
            if (item.thumbName.isNotEmpty()) referenced.add(item.thumbName)
        }
        dir.listFiles()?.forEach { file ->
            if (file.name !in referenced) file.delete()
        }
    }

    // ---------------------------------------------------------------- reading

    suspend fun thumbnail(entity: VaultEntity): Bitmap? = withContext(Dispatchers.IO) {
        val cached = thumbCache.get(entity.id)
        if (cached != null) return@withContext cached
        if (entity.thumbName.isEmpty()) return@withContext null
        try {
            val bytes = decryptToBytes(File(dir, entity.thumbName))
            val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
            if (bitmap != null) thumbCache.put(entity.id, bitmap)
            bitmap
        } catch (e: Exception) {
            null
        }
    }

    /** Decrypts a photo in memory (never written to disk), scaled to at most ~2560 px. */
    suspend fun image(entity: VaultEntity): Bitmap? = withContext(Dispatchers.IO) {
        if (entity.sizeBytes > MAX_IN_MEMORY) return@withContext null
        try {
            val bytes = decryptToBytes(File(dir, entity.blobName))
            ImageDecoder.decodeBitmap(ImageDecoder.createSource(ByteBuffer.wrap(bytes))) { decoder, info, _ ->
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                decoder.setTargetSampleSize(
                    max(1, max(info.size.width, info.size.height) / 2560)
                )
            }
        } catch (e: Exception) {
            null
        }
    }

    /** Videos need a file to play from: decrypted into the cache, wiped when the library closes. */
    suspend fun videoTemp(entity: VaultEntity): File? = withContext(Dispatchers.IO) {
        tempDir.mkdirs()
        val target = File(tempDir, entity.blobName.removeSuffix(".bin") + ".mp4")
        if (target.exists() && target.length() > 0) return@withContext target
        try {
            FileInputStream(File(dir, entity.blobName)).use { input ->
                FileOutputStream(target).use { out -> VaultCrypto.decrypt(input, out) }
            }
            target
        } catch (e: Exception) {
            target.delete()
            null
        }
    }

    private fun decryptToBytes(file: File): ByteArray {
        val out = ByteArrayOutputStream()
        FileInputStream(file).use { VaultCrypto.decrypt(it, out) }
        return out.toByteArray()
    }

    fun clearTemp() {
        tempDir.listFiles()?.forEach { it.delete() }
    }

    fun clearThumbs() {
        thumbCache.evictAll()
    }

    // ---------------------------------------------------------------- move out

    /** Decrypts back into the gallery. The encrypted copy is only deleted after the new file is complete. */
    suspend fun restore(
        items: List<VaultEntity>,
        onProgress: (done: Int, total: Int) -> Unit,
    ): RestoreResult = withContext(Dispatchers.IO) {
        var restored = 0
        var failed = 0
        var low = false
        val resolver = context.contentResolver
        val done = ArrayList<VaultEntity>()

        for ((index, item) in items.withIndex()) {
            if (low) break
            onProgress(index + 1, items.size)
            val collection = if (item.isVideo) {
                MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            } else {
                MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            }
            val values = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, item.displayName)
                put(MediaStore.MediaColumns.MIME_TYPE, item.mimeType)
                put(
                    MediaStore.MediaColumns.RELATIVE_PATH,
                    if (item.isVideo) "Movies/Restored" else "Pictures/Restored",
                )
                put(MediaStore.MediaColumns.DATE_TAKEN, item.dateAdded * 1000L)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val target = resolver.insert(collection, values)
            if (target == null) {
                failed++
                continue
            }
            try {
                val out = resolver.openOutputStream(target) ?: throw IOException("Could not open the new file")
                var written = 0L
                out.use { stream ->
                    FileInputStream(File(dir, item.blobName)).use { input ->
                        written = VaultCrypto.decrypt(input, stream)
                    }
                }
                if (written != item.sizeBytes) throw IOException("Restored file was incomplete")
                values.clear()
                values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                resolver.update(target, values, null, null)
                done.add(item)
                restored++
            } catch (e: Exception) {
                // The encrypted copy is kept; just remove the half-written new file.
                resolver.delete(target, null, null)
                if (isNoSpace(e)) low = true else failed++
            }
        }
        removeFiles(done)
        if (done.isNotEmpty()) dao.deleteByIds(done.map { it.id })
        RestoreResult(restored, failed, low)
    }

    suspend fun deleteForever(items: List<VaultEntity>) = withContext(Dispatchers.IO) {
        removeFiles(items)
        if (items.isNotEmpty()) dao.deleteByIds(items.map { it.id })
        items.forEach { thumbCache.remove(it.id) }
    }

    private fun removeFiles(items: List<VaultEntity>) {
        for (item in items) {
            File(dir, item.blobName).delete()
            if (item.thumbName.isNotEmpty()) File(dir, item.thumbName).delete()
            File(tempDir, item.blobName.removeSuffix(".bin") + ".mp4").delete()
        }
    }

    private companion object {
        const val THUMB = 320
        const val MIN_FREE_BYTES = 16L * 1024 * 1024
        const val MAX_IN_MEMORY = 80L * 1024 * 1024
    }
}
