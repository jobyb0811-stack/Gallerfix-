package com.gallerfix.app.data

import android.content.Context

/** Tiny on-device settings store (SharedPreferences). */
class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("gallerfix_prefs", Context.MODE_PRIVATE)

    var railOnRight: Boolean
        get() = prefs.getBoolean(KEY_RAIL_RIGHT, false)
        set(value) {
            prefs.edit().putBoolean(KEY_RAIL_RIGHT, value).apply()
        }

    private companion object {
        const val KEY_RAIL_RIGHT = "rail_on_right"
    }
}
