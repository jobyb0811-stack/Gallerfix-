package com.gallerfix.app.data

import android.content.Context

/** Tiny on-device settings store (SharedPreferences). */
class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("gallerfix_prefs", Context.MODE_PRIVATE)

    var railOnRight: Boolean
        get() = prefs.getBoolean(KEY_RAIL_RIGHT, false)
        set(value) {
            prefs.edit().putBoolean(KEY_RAIL_RIGHT, value).apply()
        }

    /** 0 = small, 1 = medium, 2 = large thumbnails. */
    var thumbSize: Int
        get() = prefs.getInt(KEY_THUMB, 1)
        set(value) {
            prefs.edit().putInt(KEY_THUMB, value).apply()
        }

    private companion object {
        const val KEY_RAIL_RIGHT = "rail_on_right"
        const val KEY_THUMB = "thumb_size"
    }
}
