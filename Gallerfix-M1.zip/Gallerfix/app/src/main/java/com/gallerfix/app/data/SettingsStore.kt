package com.gallerfix.app.data

import android.content.Context
import com.gallerfix.app.LockSpec

/** Tiny on-device settings store (SharedPreferences). */
class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("gallerfix_prefs", Context.MODE_PRIVATE)

    var railOnRight: Boolean
        get() = prefs.getBoolean(KEY_RAIL_RIGHT, false)
        set(value) {
            prefs.edit().putBoolean(KEY_RAIL_RIGHT, value).apply()
        }

    /** 0 = small, 1 = medium, 2 = large thumbnails. */
    var thumbSize: Int
        get() = prefs.getInt(KEY_THUMB, 1)
        set(value) {
            prefs.edit().putInt(KEY_THUMB, value).apply()
        }

    /** Show photos and videos stored on a memory card. */
    var showSd: Boolean
        get() = prefs.getBoolean(KEY_SHOW_SD, true)
        set(value) {
            prefs.edit().putBoolean(KEY_SHOW_SD, value).apply()
        }

    /** 0 = follow system, 1 = light, 2 = dark. */
    var themeMode: Int
        get() = prefs.getInt(KEY_THEME_MODE, 0)
        set(value) {
            prefs.edit().putInt(KEY_THEME_MODE, value).apply()
        }

    /** Index into the palette list (0 = wallpaper colors). */
    var palette: Int
        get() = prefs.getInt(KEY_PALETTE, 0)
        set(value) {
            prefs.edit().putInt(KEY_PALETTE, value).apply()
        }

    var amoled: Boolean
        get() = prefs.getBoolean(KEY_AMOLED, false)
        set(value) {
            prefs.edit().putBoolean(KEY_AMOLED, value).apply()
        }

    var lockEnabled: Boolean
        get() = prefs.getBoolean(KEY_LOCK, false)
        set(value) {
            prefs.edit().putBoolean(KEY_LOCK, value).apply()
        }

    /** Fingerprint / face / screen lock via the system prompt. */
    var lockBiometric: Boolean
        get() = prefs.getBoolean(KEY_LOCK_BIO, true)
        set(value) {
            prefs.edit().putBoolean(KEY_LOCK_BIO, value).apply()
        }

    /** Second biometric step (face). */
    var lockFace: Boolean
        get() = prefs.getBoolean(KEY_LOCK_FACE, true)
        set(value) {
            prefs.edit().putBoolean(KEY_LOCK_FACE, value).apply()
        }

    /** true = every step, in order. false = any one method is enough. */
    var lockSequential: Boolean
        get() = prefs.getBoolean(KEY_LOCK_SEQ, true)
        set(value) {
            prefs.edit().putBoolean(KEY_LOCK_SEQ, value).apply()
        }

    /** Let the phone's screen lock stand in for the tap step if the tap code is forgotten. */
    var lockRecovery: Boolean
        get() = prefs.getBoolean(KEY_LOCK_RECOVERY, true)
        set(value) {
            prefs.edit().putBoolean(KEY_LOCK_RECOVERY, value).apply()
        }

    var lockTaps: Boolean
        get() = prefs.getBoolean(KEY_LOCK_TAPS, false)
        set(value) {
            prefs.edit().putBoolean(KEY_LOCK_TAPS, value).apply()
        }

    var tapCount: Int
        get() = prefs.getInt(KEY_TAP_COUNT, LockSpec.DEFAULT_TAPS)
        set(value) {
            prefs.edit().putInt(KEY_TAP_COUNT, value).apply()
        }

    var lockGraceSeconds: Int
        get() = prefs.getInt(KEY_GRACE, LockSpec.DEFAULT_GRACE_SECONDS)
        set(value) {
            prefs.edit().putInt(KEY_GRACE, value).apply()
        }

    private companion object {
        const val KEY_RAIL_RIGHT = "rail_on_right"
        const val KEY_THUMB = "thumb_size"
        const val KEY_SHOW_SD = "show_sd"
        const val KEY_THEME_MODE = "theme_mode"
        const val KEY_PALETTE = "palette"
        const val KEY_AMOLED = "amoled"
        const val KEY_LOCK = "lock_enabled"
        const val KEY_LOCK_BIO = "lock_biometric"
        const val KEY_LOCK_TAPS = "lock_taps"
        const val KEY_LOCK_FACE = "lock_face"
        const val KEY_LOCK_SEQ = "lock_sequential"
        const val KEY_LOCK_RECOVERY = "lock_recovery"
        const val KEY_TAP_COUNT = "lock_tap_count"
        const val KEY_GRACE = "lock_grace_seconds"
    }
}
