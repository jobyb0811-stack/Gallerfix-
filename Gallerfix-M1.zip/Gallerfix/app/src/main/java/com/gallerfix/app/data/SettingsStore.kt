package com.gallerfix.app.data

import android.content.Context

/** Tiny on-device settings store (SharedPreferences). */
class SettingsStore(context: Context) {
    private val prefs = context.getSharedPreferences("gallerfix_prefs", Context.MODE_PRIVATE)

    var railOnRight: Boolean
        get() = prefs.getBoolean(KEY_RAIL_RIGHT, false)
        set(value) {
            prefs.edit().putBoolean(KEY_RAIL_RIGHT, value).apply()
        }

    /** 0 = small, 1 = medium, 2 = large thumbnails. */
    var thumbSize: Int
        get() = prefs.getInt(KEY_THUMB, 1)
        set(value) {
            prefs.edit().putInt(KEY_THUMB, value).apply()
        }

    /** Show photos and videos stored on a memory card. */
    var showSd: Boolean
        get() = prefs.getBoolean(KEY_SHOW_SD, true)
        set(value) {
            prefs.edit().putBoolean(KEY_SHOW_SD, value).apply()
        }

    /** 0 = follow system, 1 = light, 2 = dark. */
    var themeMode: Int
        get() = prefs.getInt(KEY_THEME_MODE, 0)
        set(value) {
            prefs.edit().putInt(KEY_THEME_MODE, value).apply()
        }

    /** Index into the palette list (0 = wallpaper colors). */
    var palette: Int
        get() = prefs.getInt(KEY_PALETTE, 0)
        set(value) {
            prefs.edit().putInt(KEY_PALETTE, value).apply()
        }

    var amoled: Boolean
        get() = prefs.getBoolean(KEY_AMOLED, false)
        set(value) {
            prefs.edit().putBoolean(KEY_AMOLED, value).apply()
        }

    private companion object {
        const val KEY_RAIL_RIGHT = "rail_on_right"
        const val KEY_THUMB = "thumb_size"
        const val KEY_SHOW_SD = "show_sd"
        const val KEY_THEME_MODE = "theme_mode"
        const val KEY_PALETTE = "palette"
        const val KEY_AMOLED = "amoled"
    }
}
