package com.gallerfix.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import coil.ImageLoader
import coil.compose.AsyncImage
import com.gallerfix.app.data.CollageLayout
import com.gallerfix.app.data.CollageRenderer
import com.gallerfix.app.data.MediaItem
import com.gallerfix.app.data.cellRect
import com.gallerfix.app.data.layoutsFor
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

private const val MAX_PHOTOS = 6

private val ASPECTS: List<Pair<String, Float>> = listOf(
    "Square" to 1f,
    "4:5" to 0.8f,
    "9:16" to 0.5625f,
    "16:9" to 1.7778f,
)

private val BACKGROUNDS: List<Color> = listOf(
    Color(0xFFFFFFFF),
    Color(0xFF000000),
    Color(0xFFF3E9DC),
    Color(0xFF2B2F36),
    Color(0xFFD7E3F4),
)

@Composable
fun CollageScreen(
    state: GalleryState,
    imageLoader: ImageLoader,
    minSize: Dp,
) {
    var step by rememberSaveable { mutableStateOf(0) }
    var picked by rememberSaveable { mutableStateOf<List<Long>>(emptyList()) }

    when (state) {
        GalleryState.Loading ->
            Box(Modifier.fillMaxSize()) {
                CircularProgressIndicator(Modifier.align(Alignment.Center))
            }

        GalleryState.NoPermission ->
            MessageState(
                title = "Allow access first",
                body = "Open the Photos tab and grant access to make collages.",
            ) {}

        GalleryState.Empty ->
            MessageState(
                title = "No photos yet",
                body = "Add some photos to your phone to start making collages.",
            ) {}

        is GalleryState.Content -> {
            val chosen = picked.mapNotNull { id -> state.items.firstOrNull { it.id == id } }
            if (step == 1 && chosen.size >= 2) {
                CollageEditor(
                    items = chosen,
                    imageLoader = imageLoader,
                    onBack = { step = 0 },
                )
            } else {
                Column(Modifier.fillMaxSize()) {
                    HeaderBar("Collage") {
                        TextButton(onClick = { step = 1 }, enabled = picked.size >= 2) {
                            Text("Next")
                        }
                    }
                    Text(
                        text = "Pick 2 to $MAX_PHOTOS photos (${picked.size}/$MAX_PHOTOS)",
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp),
                    )
                    val toggle: (MediaItem) -> Unit = { item ->
                        picked = if (item.id in picked) {
                            picked - item.id
                        } else if (picked.size < MAX_PHOTOS) {
                            picked + item.id
                        } else {
                            picked
                        }
                    }
                    MediaGrid(
                        items = state.items,
                        imageLoader = imageLoader,
                        minSize = minSize,
                        selectedIds = picked.toSet(),
                        onItemClick = toggle,
                        onItemLongClick = toggle,
                    )
                }
            }
        }
    }
}

@Composable
private fun CollageEditor(
    items: List<MediaItem>,
    imageLoader: ImageLoader,
    onBack: () -> Unit,
) {
    BackHandler(onBack = onBack)

    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current

    var layoutIndex by rememberSaveable { mutableStateOf(0) }
    var aspectIndex by rememberSaveable { mutableStateOf(0) }
    var gap by rememberSaveable { mutableStateOf(0.35f) }
    var radius by rememberSaveable { mutableStateOf(0.25f) }
    var bgIndex by rememberSaveable { mutableStateOf(0) }
    var saving by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }

    val layouts = remember(items.size) { layoutsFor(items.size) }
    val layout = layouts[layoutIndex.coerceIn(0, layouts.lastIndex)]
    val aspect = ASPECTS[aspectIndex].second
    val gapFrac = gap * 0.04f
    val radiusFrac = radius * 0.06f
    val bg = BACKGROUNDS[bgIndex]

    Column(Modifier.fillMaxSize()) {
        HeaderBar("Collage") {
            TextButton(onClick = onBack) { Text("Back") }
            Button(
                enabled = !saving,
                onClick = {
                    saving = true
                    message = null
                    scope.launch {
                        val result = CollageRenderer.render(
                            context = context,
                            items = items,
                            layout = layout,
                            gapFrac = gapFrac,
                            radiusFrac = radiusFrac,
                            background = bg.toArgb(),
                            aspect = aspect,
                        )
                        saving = false
                        message = if (result.isSuccess) {
                            "Saved to Pictures/Gallerfix"
                        } else {
                            "Couldn't save the collage: ${result.exceptionOrNull()?.message ?: "unknown error"}. Your photos are untouched."
                        }
                    }
                },
            ) { Text(if (saving) "Saving…" else "Save") }
        }

        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp)
        ) {
            if (message != null) {
                Text(
                    text = message ?: "",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.padding(vertical = 4.dp),
                )
            }

            // Preview
            Box(Modifier.fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                BoxWithConstraints(
                    Modifier
                        .heightIn(max = 380.dp)
                        .aspectRatio(aspect)
                        .background(bg)
                ) {
                    val wPx = constraints.maxWidth.toFloat()
                    val hPx = constraints.maxHeight.toFloat()
                    val cornerDp = with(density) { (wPx * radiusFrac).toDp() }
                    layout.rects.forEachIndexed { i, r ->
                        val item = items.getOrNull(i)
                        if (item != null) {
                            val c = cellRect(r, wPx, hPx, gapFrac)
                            Box(
                                Modifier
                                    .offset { IntOffset(c.x.roundToInt(), c.y.roundToInt()) }
                                    .size(
                                        with(density) { c.w.toDp() },
                                        with(density) { c.h.toDp() },
                                    )
                                    .clip(RoundedCornerShape(cornerDp))
                            ) {
                                AsyncImage(
                                    model = item.uri,
                                    imageLoader = imageLoader,
                                    contentDescription = null,
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize(),
                                )
                            }
                        }
                    }
                }
            }

            SectionLabel("Layout")
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                layouts.forEachIndexed { index, l ->
                    LayoutThumb(l, selected = index == layoutIndex) { layoutIndex = index }
                }
            }

            SectionLabel("Shape")
            Row(
                Modifier.horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                ASPECTS.forEachIndexed { index, pair ->
                    FilterChip(
                        selected = index == aspectIndex,
                        onClick = { aspectIndex = index },
                        label = { Text(pair.first) },
                    )
                }
            }

            SectionLabel("Spacing")
            Slider(value = gap, onValueChange = { gap = it }, valueRange = 0f..1f)

            SectionLabel("Rounded corners")
            Slider(value = radius, onValueChange = { radius = it }, valueRange = 0f..1f)

            SectionLabel("Background")
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                BACKGROUNDS.forEachIndexed { index, color ->
                    val selected = index == bgIndex
                    Box(
                        Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(color)
                            .border(
                                width = if (selected) 3.dp else 1.dp,
                                color = if (selected) {
                                    MaterialTheme.colorScheme.primary
                                } else {
                                    MaterialTheme.colorScheme.outlineVariant
                                },
                                shape = CircleShape,
                            )
                            .clickable { bgIndex = index }
                    )
                }
            }
            Spacer(Modifier.height(32.dp))
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.titleSmall,
        modifier = Modifier.padding(top = 16.dp, bottom = 8.dp),
    )
}

@Composable
private fun LayoutThumb(layout: CollageLayout, selected: Boolean, onClick: () -> Unit) {
    val primary = MaterialTheme.colorScheme.primary
    val neutral = MaterialTheme.colorScheme.onSurfaceVariant
    val outline = MaterialTheme.colorScheme.outlineVariant
    Canvas(
        Modifier
            .size(52.dp)
            .clip(RoundedCornerShape(12.dp))
            .border(
                width = if (selected) 2.dp else 1.dp,
                color = if (selected) primary else outline,
                shape = RoundedCornerShape(12.dp),
            )
            .clickable(onClick = onClick)
            .padding(7.dp)
    ) {
        layout.rects.forEach { r ->
            val c = cellRect(r, size.width, size.height, 0.08f)
            drawRoundRect(
                color = if (selected) primary else neutral,
                topLeft = Offset(c.x, c.y),
                size = Size(c.w, c.h),
                cornerRadius = CornerRadius(3f, 3f),
            )
        }
    }
}
