package com.gallerfix.app.ui

import android.content.Context
import android.os.Build
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.HapticFeedbackConstants
import android.view.View
import java.util.concurrent.Executors

/**
 * Proper vibration clicks for the dial and the table.
 *
 * - Uses the phone's own tuned effects (tick, click, heavy click), which feel much crisper than a generic buzz.
 * - Runs on its own thread, so vibrating can never make the screen stutter.
 * - Rate-limited, so spinning fast gives a few clean clicks instead of a continuous buzz.
 *
 * level: 0 = off, 1 = soft, 2 = strong
 */
class Haptics(context: Context, private val view: View) {

    private val vibrator: Vibrator? =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            context.getSystemService(VibratorManager::class.java)?.defaultVibrator
        } else {
            context.getSystemService(Vibrator::class.java)
        }

    private val executor = Executors.newSingleThreadExecutor()

    @Volatile
    private var lastMs = 0L

    private fun play(effect: Int) {
        val v = vibrator
        if (v == null || !v.hasVibrator()) {
            view.performHapticFeedback(HapticFeedbackConstants.CLOCK_TICK)
            return
        }
        try {
            executor.execute {
                try {
                    v.vibrate(VibrationEffect.createPredefined(effect))
                } catch (e: Exception) {
                    // the phone refused: nothing to do
                }
            }
        } catch (e: Exception) {
            // executor already closed
        }
    }

    private fun open(minGapMs: Long): Boolean {
        val now = SystemClock.uptimeMillis()
        if (now - lastMs < minGapMs) return false
        lastMs = now
        return true
    }

    /** One step of the dial. [major] steps (new day, every tenth photo) get a firmer click. */
    fun dialTick(level: Int, major: Boolean) {
        if (level == 0 || !open(MIN_GAP_MS)) return
        play(
            if (major) {
                if (level == 2) VibrationEffect.EFFECT_HEAVY_CLICK else VibrationEffect.EFFECT_CLICK
            } else {
                if (level == 2) VibrationEffect.EFFECT_CLICK else VibrationEffect.EFFECT_TICK
            }
        )
    }

    /** The dial dropping into its final notch. */
    fun settle(level: Int) {
        if (level == 0) return
        lastMs = SystemClock.uptimeMillis()
        play(if (level == 2) VibrationEffect.EFFECT_HEAVY_CLICK else VibrationEffect.EFFECT_CLICK)
    }

    /** Hitting the first or last photo. */
    fun endStop(level: Int) {
        if (level == 0) return
        lastMs = SystemClock.uptimeMillis()
        play(VibrationEffect.EFFECT_DOUBLE_CLICK)
    }

    /** A photo is hovering over an album. */
    fun hover(level: Int) {
        if (level == 0 || !open(60)) return
        play(VibrationEffect.EFFECT_TICK)
    }

    /** A photo dropping into an album. */
    fun drop(level: Int) {
        if (level == 0) return
        lastMs = SystemClock.uptimeMillis()
        play(if (level == 2) VibrationEffect.EFFECT_HEAVY_CLICK else VibrationEffect.EFFECT_CLICK)
    }

    fun close() {
        try {
            executor.shutdown()
        } catch (e: Exception) {
            // ignore
        }
    }

    private companion object {
        /** Never more than about 22 clicks a second, however fast you spin. */
        const val MIN_GAP_MS = 45L
    }
}
