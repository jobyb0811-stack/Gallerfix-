package com.gallerfix.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun SettingsScreen(
    railOnRight: Boolean,
    onRailOnRightChange: (Boolean) -> Unit,
    thumbSize: Int,
    onThumbSizeChange: (Int) -> Unit,
    onResetSorting: () -> Unit,
) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("Settings", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(16.dp))

        Row(
            Modifier.fillMaxWidth().padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text("Navigation rail on the right", style = MaterialTheme.typography.titleMedium)
                Text(
                    "Easier to reach with your right thumb.",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
            Switch(checked = railOnRight, onCheckedChange = onRailOnRightChange)
        }

        Spacer(Modifier.height(16.dp))
        Text("Thumbnail size", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Small", "Medium", "Large").forEachIndexed { index, label ->
                FilterChip(
                    selected = thumbSize == index,
                    onClick = { onThumbSizeChange(index) },
                    label = { Text(label) },
                )
            }
        }

        Spacer(Modifier.height(24.dp))
        Text("Sort history", style = MaterialTheme.typography.titleMedium)
        Text(
            "Start over so every photo shows up in Sort again. Your photos are not changed.",
            style = MaterialTheme.typography.bodySmall,
        )
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = onResetSorting) { Text("Reset sort history") }
    }
}
