package com.gallerfix.app.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.gallerfix.app.ui.theme.PALETTES

@Composable
fun SettingsScreen(
    railOnRight: Boolean,
    onRailOnRightChange: (Boolean) -> Unit,
    thumbSize: Int,
    onThumbSizeChange: (Int) -> Unit,
    showSd: Boolean,
    sdPresent: Boolean,
    onShowSdChange: (Boolean) -> Unit,
    themeMode: Int,
    onThemeModeChange: (Int) -> Unit,
    palette: Int,
    onPaletteChange: (Int) -> Unit,
    amoled: Boolean,
    onAmoledChange: (Boolean) -> Unit,
    lockEnabled: Boolean,
    onLockEnabledChange: (Boolean) -> Unit,
    lockBiometric: Boolean,
    onLockBiometricChange: (Boolean) -> Unit,
    lockTaps: Boolean,
    onLockTapsChange: (Boolean) -> Unit,
    tapCount: Int,
    onTapCountChange: (Int) -> Unit,
    lockGraceSeconds: Int,
    onLockGraceChange: (Int) -> Unit,
    onResetSorting: () -> Unit,
) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("Settings", style = MaterialTheme.typography.headlineSmall)

        Heading("Storage")
        SwitchRow(
            title = "Show memory card (SD) items",
            subtitle = if (sdPresent) {
                "Turn off to hide everything stored on your SD card."
            } else {
                "No SD card detected right now. This applies as soon as one is inserted."
            },
            checked = showSd,
            onChange = onShowSdChange,
        )

        Heading("Layout")
        SwitchRow(
            title = "Navigation rail on the right",
            subtitle = "Easier to reach with your right thumb.",
            checked = railOnRight,
            onChange = onRailOnRightChange,
        )
        Spacer(Modifier.height(8.dp))
        Text("Thumbnail size", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        ChipRow(listOf("Small", "Medium", "Large"), thumbSize, onThumbSizeChange)

        Heading("Theme")
        Text("Mode", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        ChipRow(listOf("System", "Light", "Dark"), themeMode, onThemeModeChange)
        Spacer(Modifier.height(12.dp))
        Text("Colors", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        ChipRow(PALETTES.map { it.name }, palette, onPaletteChange)
        Spacer(Modifier.height(8.dp))
        SwitchRow(
            title = "Pure black in dark mode",
            subtitle = "Saves battery on OLED screens.",
            checked = amoled,
            onChange = onAmoledChange,
        )

        Heading("App lock")
        SwitchRow(
            title = "Lock Gallerfix",
            subtitle = "Ask to unlock whenever you open the app. Also hides the app in the recent-apps screen and blocks screenshots.",
            checked = lockEnabled,
            onChange = onLockEnabledChange,
        )
        SwitchRow(
            title = "Fingerprint, face or screen lock",
            subtitle = "Android shows the fingerprint or face prompt your phone supports. Your PIN, pattern or password is the backup.",
            checked = lockBiometric,
            onChange = onLockBiometricChange,
        )
        SwitchRow(
            title = "Secret taps",
            subtitle = "On the lock screen, tap anywhere the number of times you choose, then pause. Nothing on screen gives it away.",
            checked = lockTaps,
            onChange = onLockTapsChange,
        )
        if (lockTaps) {
            Spacer(Modifier.height(8.dp))
            Text("Number of taps", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedButton(onClick = { onTapCountChange(tapCount - 1) }) { Text("−") }
                Text(
                    "$tapCount taps",
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(horizontal = 16.dp),
                )
                OutlinedButton(onClick = { onTapCountChange(tapCount + 1) }) { Text("+") }
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("Lock after leaving the app", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        val graceOptions = listOf(0, 30, 300)
        ChipRow(
            options = listOf("Immediately", "30 seconds", "5 minutes"),
            selectedIndex = graceOptions.indexOf(lockGraceSeconds).coerceAtLeast(0),
            onSelect = { onLockGraceChange(graceOptions[it]) },
        )

        Heading("Sort history")
        Text(
            "Start over so every photo shows up in Sort again. Your photos are not changed.",
            style = MaterialTheme.typography.bodySmall,
        )
        Spacer(Modifier.height(8.dp))
        OutlinedButton(onClick = onResetSorting) { Text("Reset sort history") }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun Heading(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 24.dp, bottom = 8.dp),
    )
}

@Composable
private fun SwitchRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit,
) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(subtitle, style = MaterialTheme.typography.bodySmall)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun ChipRow(options: List<String>, selectedIndex: Int, onSelect: (Int) -> Unit) {
    Row(
        Modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        options.forEachIndexed { index, label ->
            FilterChip(
                selected = selectedIndex == index,
                onClick = { onSelect(index) },
                label = { Text(label) },
            )
        }
    }
}
