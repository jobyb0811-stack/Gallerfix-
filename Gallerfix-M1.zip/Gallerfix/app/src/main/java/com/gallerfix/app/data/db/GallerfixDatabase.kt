package com.gallerfix.app.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [AlbumEntity::class, AlbumItemEntity::class, TriageEntity::class],
    version = 1,
    exportSchema = false,
)
abstract class GallerfixDatabase : RoomDatabase() {
    abstract fun albumDao(): AlbumDao
    abstract fun triageDao(): TriageDao

    companion object {
        @Volatile
        private var instance: GallerfixDatabase? = null

        fun get(context: Context): GallerfixDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    GallerfixDatabase::class.java,
                    "gallerfix.db",
                ).build().also { instance = it }
            }
    }
}
