package com.gallerfix.app.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        AlbumEntity::class,
        AlbumItemEntity::class,
        TriageEntity::class,
        VaultEntity::class,
        GeoEntity::class,
        PlaceNameEntity::class,
        FavoriteEntity::class,
    ],
    version = 4,
    exportSchema = false,
)
abstract class GallerfixDatabase : RoomDatabase() {
    abstract fun albumDao(): AlbumDao
    abstract fun triageDao(): TriageDao
    abstract fun vaultDao(): VaultDao
    abstract fun geoDao(): GeoDao
    abstract fun favoriteDao(): FavoriteDao

    companion object {
        @Volatile
        private var instance: GallerfixDatabase? = null

        /** Adds the private library table. Albums and sort history are kept. */
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `vault_items` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`displayName` TEXT NOT NULL, " +
                        "`mimeType` TEXT NOT NULL, " +
                        "`isVideo` INTEGER NOT NULL, " +
                        "`sizeBytes` INTEGER NOT NULL, " +
                        "`dateAdded` INTEGER NOT NULL, " +
                        "`durationMs` INTEGER NOT NULL, " +
                        "`blobName` TEXT NOT NULL, " +
                        "`thumbName` TEXT NOT NULL, " +
                        "`state` INTEGER NOT NULL, " +
                        "`originalUri` TEXT NOT NULL, " +
                        "`createdAt` INTEGER NOT NULL)"
                )
            }
        }

        /** Adds the place index for Smart albums. Everything else is kept. */
        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `geo_index` (" +
                        "`mediaId` INTEGER NOT NULL, `lat` REAL, `lon` REAL, PRIMARY KEY(`mediaId`))"
                )
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `place_names` (" +
                        "`cell` TEXT NOT NULL, `name` TEXT NOT NULL, PRIMARY KEY(`cell`))"
                )
            }
        }

        /** Adds favourites. Everything else is kept. */
        private val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `favorites` (`mediaId` INTEGER NOT NULL, PRIMARY KEY(`mediaId`))"
                )
            }
        }

        fun get(context: Context): GallerfixDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    GallerfixDatabase::class.java,
                    "gallerfix.db",
                )
                    .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4)
                    .build()
                    .also { instance = it }
            }
    }
}
