package com.gallerfix.app.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface AlbumDao {
    @Query("SELECT * FROM albums ORDER BY createdAt DESC")
    fun observeAlbums(): Flow<List<AlbumEntity>>

    @Query("SELECT * FROM album_items")
    fun observeLinks(): Flow<List<AlbumItemEntity>>

    @Insert
    suspend fun insertAlbum(album: AlbumEntity): Long

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertLinks(links: List<AlbumItemEntity>)

    @Query("UPDATE albums SET name = :name WHERE id = :id")
    suspend fun rename(id: Long, name: String)

    @Query("DELETE FROM albums WHERE id = :id")
    suspend fun deleteAlbum(id: Long)

    @Query("DELETE FROM album_items WHERE albumId = :albumId AND mediaId = :mediaId AND isVideo = :isVideo")
    suspend fun removeLink(albumId: Long, mediaId: Long, isVideo: Boolean)
}

@Dao
interface TriageDao {
    @Query("SELECT * FROM triage")
    fun observeAll(): Flow<List<TriageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(row: TriageEntity)

    @Query("DELETE FROM triage WHERE mediaId = :mediaId AND isVideo = :isVideo")
    suspend fun delete(mediaId: Long, isVideo: Boolean)

    @Query("SELECT * FROM triage ORDER BY decidedAt DESC LIMIT 1")
    suspend fun latest(): TriageEntity?

    @Query("DELETE FROM triage WHERE decision = 1")
    suspend fun clearTrashQueue()

    @Query("DELETE FROM triage")
    suspend fun clearAll()
}

@Dao
interface VaultDao {
    @Query("SELECT * FROM vault_items ORDER BY dateAdded DESC")
    fun observeAll(): Flow<List<VaultEntity>>

    @Query("SELECT * FROM vault_items")
    suspend fun getAll(): List<VaultEntity>

    @Query("SELECT originalUri FROM vault_items")
    suspend fun originalUris(): List<String>

    @Insert
    suspend fun insert(item: VaultEntity): Long

    @Query("UPDATE vault_items SET state = 1 WHERE id IN (:ids)")
    suspend fun markSafe(ids: List<Long>)

    @Query("DELETE FROM vault_items WHERE id IN (:ids)")
    suspend fun deleteByIds(ids: List<Long>)
}

@Dao
interface GeoDao {
    @Query("SELECT * FROM geo_index")
    fun observeAll(): Flow<List<GeoEntity>>

    @Query("SELECT mediaId FROM geo_index")
    suspend fun indexedIds(): List<Long>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(rows: List<GeoEntity>)

    @Query("SELECT * FROM place_names")
    fun observeNames(): Flow<List<PlaceNameEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun setName(row: PlaceNameEntity)
}

@Dao
interface FavoriteDao {
    @Query("SELECT * FROM favorites")
    fun observeAll(): Flow<List<FavoriteEntity>>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(rows: List<FavoriteEntity>)

    @Query("DELETE FROM favorites WHERE mediaId IN (:ids)")
    suspend fun deleteByIds(ids: List<Long>)
}
